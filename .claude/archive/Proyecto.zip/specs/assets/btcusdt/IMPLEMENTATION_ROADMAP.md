# BTC/USDT — Roadmap de Implementación (por fases, con gate)

> Construye por fases; no avances sin pasar el gate (tests verdes) de la anterior. Combina el
> **onboarding del activo** (stages A–F del playbook) con las **fases de modelado** de `design/`
> (SPEC-00 §7). El gate honesto final: S3 solo se promueve si le gana a **ambos** baselines OOS en
> Calmar Y Sortino, con DSR positivo (conteo completo de trials).

| Fase | Bloque | Entregable | Gate |
|---|---|---|---|
| **0** | Onboarding A | `config/assets/btcusdt.yaml` (AssetProfile) + migración 052 + test A1/B1 | **A1, B1 verdes** ✅ |
| **1** | Onboarding B (datos) | Extractor Binance/CCXT (5-min+daily) → seeds; extractores cripto-native (BGeo/funding/Farside/DefiLlama) → tablas 052 | **A2, A3, A4, C1 verdes** (seed en rango, 288 bars/día, UTC, fin de semana presente) |
| **2** | design SPEC-10 | Baselines **B1** (HODL vol-targeted) y **B2** (cripto reglas) — ANTES de todo lo demás | B1/B2 backtesteados con CostModel (SPEC-07) — sin benchmark no hay gate |
| **3** | design SPEC-01 | Régimen HMM 4-estados fit-congelado sobre on-chain | H-REG-01, H-REG-02 |
| **4** | design SPEC-02 | Posicionamiento (`z_funding`) | H-POS-01 |
| **5** | design SPEC-03 | Combinación en riesgo `R=0.7·z_ciclo+0.3·z_funding` | H-CMB-01, H-CMB-02 (ortogonalidad) |
| **6** | design SPEC-04 | Gate de liquidez `M_liquidez∈[0.5,1.25]` | H-LIQ-01, H-LIQ-02 |
| **7** | design SPEC-06 = **S3** | Motor de exposición (vol-target √365 + bandas ±12.5% + cap portafolio) | **H-ENG-01, H-ENG-02 (le gana a B1 y B2 en Calmar OOS)** |
| **8** | design SPEC-05 | Gate de eventos `G` (LLM + vol-spike breaker) | H-EVT-01, H-EVT-02 |
| **9** | design SPEC-08 = **S4** | Meta-labeling (XGBoost, solo frena) | H-MET-01, H-MET-02 |
| **10** | design SPEC-09 = **S5** | RL táctico PPO (±10% NAV, opcional, 5 seeds) | H-RL-01 |
| **F** | Onboarding F | Publica bundle → `registry.json` (activo `btcusdt`) → visible en `/dashboard` (chart BTCUSDT) | Selector arma solo, sin regresión COP/Gold |
| **11** | design SPEC-12 | Retiro + shadow + monitores de drift | Protocolo §14 firmado |

## Ruta realista más rápida (recomendada)

Igual que el Oro: **paper + visibilidad web primero**, evitando `forecast_h5_*` y el OMS live.
Orden mínimo para "BTC visible en el dashboard con un baseline honesto":

```
Fase 0 (hecha) → Fase 1 (datos) → Fase 2 (B1/B2) → Fase 7 (S3) → Fase F (publicar bundle)
```

Las fases 3–6, 8–11 refinan S3; se construyen solo si el activo justifica la inversión (S3 debe batir
los baselines primero). Live (D6) queda diferido hasta validar en paper una semana.

## Decisiones que requieren al operador antes de producción

- **D5** — schedule de ingesta 24/7 (la fábrica debe emitir un DAG cripto, no reusar la ventana COP 8-12).
- **D6** — ejecución live (spot en exchange cripto vs paper). Ver SPEC-13 §5.
- **Keys** — provisionar `BGEOMETRICS_API_KEY`, `CRYPTOCOMPARE_API_KEY` (free-tier) en `.env`/Vault.
