--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: timescaledb; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS timescaledb WITH SCHEMA public;


--
-- Name: EXTENSION timescaledb; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION timescaledb IS 'Enables scalable inserts and complex queries for time-series data (Community Edition)';


--
-- Name: config; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA config;


--
-- Name: SCHEMA config; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA config IS 'Configuration tables for models, features, and system settings';


--
-- Name: dw; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA dw;


--
-- Name: events; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA events;


--
-- Name: SCHEMA events; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA events IS 'Event streaming and audit trail for compliance';


--
-- Name: metrics; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA metrics;


--
-- Name: SCHEMA metrics; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA metrics IS 'Performance metrics and aggregated statistics';


--
-- Name: trading; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA trading;


--
-- Name: SCHEMA trading; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA trading IS 'Trading operations: inferences, trades, positions';


--
-- Name: is_user_locked(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_user_locked(p_username text) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM users 
    WHERE username = p_username 
    AND locked_until IS NOT NULL 
    AND locked_until > NOW()
  );
END;
$$;


--
-- Name: record_failed_login(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.record_failed_login(p_username text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  UPDATE users 
  SET failed_login_attempts = COALESCE(failed_login_attempts, 0) + 1
  WHERE username = p_username;
END;
$$;


--
-- Name: record_successful_login(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.record_successful_login(p_username text) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  UPDATE users 
  SET last_login_at = NOW(), 
      failed_login_attempts = 0,
      locked_until = NULL
  WHERE username = p_username;
END;
$$;


--
-- Name: refresh_inference_features(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.refresh_inference_features() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    REFRESH MATERIALIZED VIEW CONCURRENTLY inference_features_5m;
END;
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


--
-- Name: close_trade(bigint, numeric, character varying, numeric, bigint, numeric); Type: FUNCTION; Schema: trading; Owner: -
--

CREATE FUNCTION trading.close_trade(p_trade_id bigint, p_exit_price numeric, p_exit_reason character varying DEFAULT 'signal'::character varying, p_exit_confidence numeric DEFAULT NULL::numeric, p_inference_id bigint DEFAULT NULL::bigint, p_transaction_costs numeric DEFAULT 0) RETURNS TABLE(pnl numeric, pnl_pct numeric, duration_minutes integer)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_trade RECORD;
    v_pnl NUMERIC(12, 4);
    v_pnl_pct NUMERIC(12, 6);
    v_gross_pnl NUMERIC(12, 4);
    v_duration INTEGER;
BEGIN
    -- Get trade details
    SELECT * INTO v_trade FROM trading.model_trades WHERE trade_id = p_trade_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Trade % not found', p_trade_id;
    END IF;

    IF v_trade.status != 'open' THEN
        RAISE EXCEPTION 'Trade % is not open (status: %)', p_trade_id, v_trade.status;
    END IF;

    -- Calculate PnL
    IF v_trade.signal = 'LONG' THEN
        v_gross_pnl := (p_exit_price - v_trade.entry_price) * v_trade.position_size;
    ELSE
        v_gross_pnl := (v_trade.entry_price - p_exit_price) * v_trade.position_size;
    END IF;

    v_pnl := v_gross_pnl - p_transaction_costs;
    v_pnl_pct := v_pnl / v_trade.entry_price;
    v_duration := EXTRACT(EPOCH FROM (NOW() - v_trade.open_time)) / 60;

    -- Update trade
    UPDATE trading.model_trades SET
        close_time = NOW(),
        exit_price = p_exit_price,
        pnl = v_pnl,
        pnl_pct = v_pnl_pct,
        gross_pnl = v_gross_pnl,
        duration_minutes = v_duration,
        duration_bars = v_duration / 5,
        status = 'closed',
        exit_reason = p_exit_reason,
        exit_confidence = p_exit_confidence,
        exit_inference_id = p_inference_id,
        transaction_costs = p_transaction_costs,
        updated_at = NOW()
    WHERE trade_id = p_trade_id;

    -- Log trade close event
    INSERT INTO events.signals_stream (event_type, event_subtype, model_id, payload, price_at_event)
    VALUES ('TRADE_CLOSE', p_exit_reason, v_trade.model_id,
            jsonb_build_object('trade_id', p_trade_id, 'exit_price', p_exit_price, 'pnl', v_pnl, 'pnl_pct', v_pnl_pct),
            p_exit_price);

    RETURN QUERY SELECT v_pnl, v_pnl_pct, v_duration;
END;
$$;


--
-- Name: FUNCTION close_trade(p_trade_id bigint, p_exit_price numeric, p_exit_reason character varying, p_exit_confidence numeric, p_inference_id bigint, p_transaction_costs numeric); Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON FUNCTION trading.close_trade(p_trade_id bigint, p_exit_price numeric, p_exit_reason character varying, p_exit_confidence numeric, p_inference_id bigint, p_transaction_costs numeric) IS 'Closes an open trade with PnL calculation and event logging';


--
-- Name: get_model_state(character varying); Type: FUNCTION; Schema: trading; Owner: -
--

CREATE FUNCTION trading.get_model_state(p_model_id character varying) RETURNS TABLE(model_name character varying, current_position double precision, last_signal character varying, last_signal_time timestamp with time zone, open_trades integer, daily_pnl numeric, daily_trades integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        m.name,
        COALESCE(
            (SELECT i.current_position FROM trading.model_inferences i
             WHERE i.model_id = p_model_id ORDER BY timestamp_utc DESC LIMIT 1), 0.0
        ),
        (SELECT i.action_discretized FROM trading.model_inferences i
         WHERE i.model_id = p_model_id ORDER BY timestamp_utc DESC LIMIT 1),
        (SELECT i.timestamp_utc FROM trading.model_inferences i
         WHERE i.model_id = p_model_id ORDER BY timestamp_utc DESC LIMIT 1),
        (SELECT COUNT(*)::INTEGER FROM trading.model_trades t
         WHERE t.model_id = p_model_id AND t.status = 'open'),
        COALESCE(
            (SELECT SUM(t.pnl) FROM trading.model_trades t
             WHERE t.model_id = p_model_id AND t.close_time::date = CURRENT_DATE), 0
        ),
        (SELECT COUNT(*)::INTEGER FROM trading.model_trades t
         WHERE t.model_id = p_model_id AND t.close_time::date = CURRENT_DATE)
    FROM config.models m
    WHERE m.model_id = p_model_id;
END;
$$;


--
-- Name: FUNCTION get_model_state(p_model_id character varying); Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON FUNCTION trading.get_model_state(p_model_id character varying) IS 'Returns current state for a model including position, signals, and daily PnL';


--
-- Name: open_trade(character varying, character varying, numeric, numeric, numeric, bigint); Type: FUNCTION; Schema: trading; Owner: -
--

CREATE FUNCTION trading.open_trade(p_model_id character varying, p_signal character varying, p_entry_price numeric, p_position_size numeric DEFAULT 1.0, p_confidence numeric DEFAULT NULL::numeric, p_inference_id bigint DEFAULT NULL::bigint) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_trade_id BIGINT;
BEGIN
    INSERT INTO trading.model_trades (
        model_id, open_time, signal, entry_price,
        position_size, entry_confidence, entry_inference_id, status
    ) VALUES (
        p_model_id, NOW(), p_signal, p_entry_price,
        p_position_size, p_confidence, p_inference_id, 'open'
    ) RETURNING trade_id INTO v_trade_id;

    -- Log trade open event
    INSERT INTO events.signals_stream (event_type, event_subtype, model_id, payload, price_at_event)
    VALUES ('TRADE_OPEN', p_signal, p_model_id,
            jsonb_build_object('trade_id', v_trade_id, 'entry_price', p_entry_price, 'size', p_position_size),
            p_entry_price);

    RETURN v_trade_id;
END;
$$;


--
-- Name: FUNCTION open_trade(p_model_id character varying, p_signal character varying, p_entry_price numeric, p_position_size numeric, p_confidence numeric, p_inference_id bigint); Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON FUNCTION trading.open_trade(p_model_id character varying, p_signal character varying, p_entry_price numeric, p_position_size numeric, p_confidence numeric, p_inference_id bigint) IS 'Opens a new trade and logs the event';


--
-- Name: record_inference(character varying, double precision, character varying, double precision, numeric, jsonb, integer, double precision, integer, character varying); Type: FUNCTION; Schema: trading; Owner: -
--

CREATE FUNCTION trading.record_inference(p_model_id character varying, p_action_raw double precision, p_action_discretized character varying, p_confidence double precision, p_price numeric, p_features jsonb, p_latency_ms integer, p_position double precision DEFAULT 0.0, p_bar_number integer DEFAULT NULL::integer, p_session_id character varying DEFAULT NULL::character varying) RETURNS bigint
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_inference_id BIGINT;
BEGIN
    INSERT INTO trading.model_inferences (
        timestamp_utc, model_id, action_raw, action_discretized,
        confidence, price_at_inference, features_snapshot,
        latency_ms, current_position, bar_number, session_id
    ) VALUES (
        NOW(), p_model_id, p_action_raw, p_action_discretized,
        p_confidence, p_price, p_features,
        p_latency_ms, p_position, p_bar_number, p_session_id
    ) RETURNING inference_id INTO v_inference_id;

    RETURN v_inference_id;
END;
$$;


--
-- Name: FUNCTION record_inference(p_model_id character varying, p_action_raw double precision, p_action_discretized character varying, p_confidence double precision, p_price numeric, p_features jsonb, p_latency_ms integer, p_position double precision, p_bar_number integer, p_session_id character varying); Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON FUNCTION trading.record_inference(p_model_id character varying, p_action_raw double precision, p_action_discretized character varying, p_confidence double precision, p_price numeric, p_features jsonb, p_latency_ms integer, p_position double precision, p_bar_number integer, p_session_id character varying) IS 'Records a model inference with all associated data';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: usdcop_m5_ohlcv; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usdcop_m5_ohlcv (
    "time" timestamp with time zone NOT NULL,
    symbol text DEFAULT 'USD/COP'::text NOT NULL,
    open numeric(12,6) NOT NULL,
    high numeric(12,6) NOT NULL,
    low numeric(12,6) NOT NULL,
    close numeric(12,6) NOT NULL,
    volume bigint DEFAULT 0,
    source text DEFAULT 'twelvedata'::text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT chk_high_gte_close CHECK ((high >= close)),
    CONSTRAINT chk_high_gte_low CHECK ((high >= low)),
    CONSTRAINT chk_high_gte_open CHECK ((high >= open)),
    CONSTRAINT chk_low_lte_close CHECK ((low <= close)),
    CONSTRAINT chk_low_lte_open CHECK ((low <= open)),
    CONSTRAINT chk_prices_positive CHECK (((open > (0)::numeric) AND (high > (0)::numeric) AND (low > (0)::numeric) AND (close > (0)::numeric))),
    CONSTRAINT chk_volume_non_negative CHECK ((volume >= 0))
);


--
-- Name: _hyper_1_100_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_100_chunk (
    CONSTRAINT constraint_100 CHECK ((("time" >= '2021-11-18 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-11-25 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_101_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_101_chunk (
    CONSTRAINT constraint_101 CHECK ((("time" >= '2021-11-25 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-12-02 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_102_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_102_chunk (
    CONSTRAINT constraint_102 CHECK ((("time" >= '2021-12-02 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-12-09 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_103_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_103_chunk (
    CONSTRAINT constraint_103 CHECK ((("time" >= '2021-12-09 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-12-16 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_104_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_104_chunk (
    CONSTRAINT constraint_104 CHECK ((("time" >= '2021-12-16 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-12-23 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_105_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_105_chunk (
    CONSTRAINT constraint_105 CHECK ((("time" >= '2021-12-23 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-12-30 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_106_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_106_chunk (
    CONSTRAINT constraint_106 CHECK ((("time" >= '2021-12-30 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-01-06 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_107_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_107_chunk (
    CONSTRAINT constraint_107 CHECK ((("time" >= '2022-01-06 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-01-13 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_108_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_108_chunk (
    CONSTRAINT constraint_108 CHECK ((("time" >= '2022-01-13 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-01-20 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_109_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_109_chunk (
    CONSTRAINT constraint_109 CHECK ((("time" >= '2022-01-20 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-01-27 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_10_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_10_chunk (
    CONSTRAINT constraint_10 CHECK ((("time" >= '2020-02-27 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-03-05 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_110_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_110_chunk (
    CONSTRAINT constraint_110 CHECK ((("time" >= '2022-01-27 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-02-03 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_111_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_111_chunk (
    CONSTRAINT constraint_111 CHECK ((("time" >= '2022-02-03 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-02-10 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_112_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_112_chunk (
    CONSTRAINT constraint_112 CHECK ((("time" >= '2022-02-10 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-02-17 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_113_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_113_chunk (
    CONSTRAINT constraint_113 CHECK ((("time" >= '2022-02-17 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-02-24 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_114_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_114_chunk (
    CONSTRAINT constraint_114 CHECK ((("time" >= '2022-02-24 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-03-03 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_115_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_115_chunk (
    CONSTRAINT constraint_115 CHECK ((("time" >= '2022-03-03 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-03-10 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_116_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_116_chunk (
    CONSTRAINT constraint_116 CHECK ((("time" >= '2022-03-10 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-03-17 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_117_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_117_chunk (
    CONSTRAINT constraint_117 CHECK ((("time" >= '2022-03-17 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-03-24 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_118_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_118_chunk (
    CONSTRAINT constraint_118 CHECK ((("time" >= '2022-03-24 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-03-31 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_119_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_119_chunk (
    CONSTRAINT constraint_119 CHECK ((("time" >= '2022-03-31 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-04-07 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_11_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_11_chunk (
    CONSTRAINT constraint_11 CHECK ((("time" >= '2020-03-05 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-03-12 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_120_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_120_chunk (
    CONSTRAINT constraint_120 CHECK ((("time" >= '2022-04-07 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-04-14 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_121_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_121_chunk (
    CONSTRAINT constraint_121 CHECK ((("time" >= '2022-04-14 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-04-21 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_122_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_122_chunk (
    CONSTRAINT constraint_122 CHECK ((("time" >= '2022-04-21 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-04-28 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_123_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_123_chunk (
    CONSTRAINT constraint_123 CHECK ((("time" >= '2022-04-28 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-05-05 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_124_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_124_chunk (
    CONSTRAINT constraint_124 CHECK ((("time" >= '2022-05-05 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-05-12 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_125_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_125_chunk (
    CONSTRAINT constraint_125 CHECK ((("time" >= '2022-05-12 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-05-19 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_126_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_126_chunk (
    CONSTRAINT constraint_126 CHECK ((("time" >= '2022-05-19 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-05-26 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_127_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_127_chunk (
    CONSTRAINT constraint_127 CHECK ((("time" >= '2022-05-26 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-06-02 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_128_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_128_chunk (
    CONSTRAINT constraint_128 CHECK ((("time" >= '2022-06-02 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-06-09 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_129_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_129_chunk (
    CONSTRAINT constraint_129 CHECK ((("time" >= '2022-06-09 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-06-16 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_12_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_12_chunk (
    CONSTRAINT constraint_12 CHECK ((("time" >= '2020-03-12 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-03-19 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_130_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_130_chunk (
    CONSTRAINT constraint_130 CHECK ((("time" >= '2022-06-16 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-06-23 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_131_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_131_chunk (
    CONSTRAINT constraint_131 CHECK ((("time" >= '2022-06-23 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-06-30 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_132_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_132_chunk (
    CONSTRAINT constraint_132 CHECK ((("time" >= '2022-06-30 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-07-07 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_133_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_133_chunk (
    CONSTRAINT constraint_133 CHECK ((("time" >= '2022-07-07 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-07-14 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_134_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_134_chunk (
    CONSTRAINT constraint_134 CHECK ((("time" >= '2022-07-14 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-07-21 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_135_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_135_chunk (
    CONSTRAINT constraint_135 CHECK ((("time" >= '2022-07-21 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-07-28 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_136_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_136_chunk (
    CONSTRAINT constraint_136 CHECK ((("time" >= '2022-07-28 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-08-04 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_137_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_137_chunk (
    CONSTRAINT constraint_137 CHECK ((("time" >= '2022-08-04 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-08-11 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_138_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_138_chunk (
    CONSTRAINT constraint_138 CHECK ((("time" >= '2022-08-11 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-08-18 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_139_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_139_chunk (
    CONSTRAINT constraint_139 CHECK ((("time" >= '2022-08-18 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-08-25 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_13_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_13_chunk (
    CONSTRAINT constraint_13 CHECK ((("time" >= '2020-03-19 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-03-26 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_140_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_140_chunk (
    CONSTRAINT constraint_140 CHECK ((("time" >= '2022-08-25 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-09-01 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_141_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_141_chunk (
    CONSTRAINT constraint_141 CHECK ((("time" >= '2022-09-01 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-09-08 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_142_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_142_chunk (
    CONSTRAINT constraint_142 CHECK ((("time" >= '2022-09-08 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-09-15 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_143_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_143_chunk (
    CONSTRAINT constraint_143 CHECK ((("time" >= '2022-09-15 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-09-22 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_144_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_144_chunk (
    CONSTRAINT constraint_144 CHECK ((("time" >= '2022-09-22 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-09-29 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_145_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_145_chunk (
    CONSTRAINT constraint_145 CHECK ((("time" >= '2022-09-29 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-10-06 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_146_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_146_chunk (
    CONSTRAINT constraint_146 CHECK ((("time" >= '2022-10-06 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-10-13 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_147_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_147_chunk (
    CONSTRAINT constraint_147 CHECK ((("time" >= '2022-10-13 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-10-20 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_148_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_148_chunk (
    CONSTRAINT constraint_148 CHECK ((("time" >= '2022-10-20 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-10-27 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_149_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_149_chunk (
    CONSTRAINT constraint_149 CHECK ((("time" >= '2022-10-27 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-11-03 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_14_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_14_chunk (
    CONSTRAINT constraint_14 CHECK ((("time" >= '2020-03-26 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-04-02 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_150_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_150_chunk (
    CONSTRAINT constraint_150 CHECK ((("time" >= '2022-11-03 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-11-10 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_151_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_151_chunk (
    CONSTRAINT constraint_151 CHECK ((("time" >= '2022-11-10 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-11-17 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_152_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_152_chunk (
    CONSTRAINT constraint_152 CHECK ((("time" >= '2022-11-17 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-11-24 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_153_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_153_chunk (
    CONSTRAINT constraint_153 CHECK ((("time" >= '2022-11-24 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-12-01 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_154_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_154_chunk (
    CONSTRAINT constraint_154 CHECK ((("time" >= '2022-12-01 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-12-08 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_155_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_155_chunk (
    CONSTRAINT constraint_155 CHECK ((("time" >= '2022-12-08 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-12-15 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_156_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_156_chunk (
    CONSTRAINT constraint_156 CHECK ((("time" >= '2022-12-15 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-12-22 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_157_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_157_chunk (
    CONSTRAINT constraint_157 CHECK ((("time" >= '2022-12-22 00:00:00+00'::timestamp with time zone) AND ("time" < '2022-12-29 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_158_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_158_chunk (
    CONSTRAINT constraint_158 CHECK ((("time" >= '2022-12-29 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-01-05 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_159_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_159_chunk (
    CONSTRAINT constraint_159 CHECK ((("time" >= '2023-01-05 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-01-12 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_15_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_15_chunk (
    CONSTRAINT constraint_15 CHECK ((("time" >= '2020-04-02 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-04-09 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_160_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_160_chunk (
    CONSTRAINT constraint_160 CHECK ((("time" >= '2023-01-12 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-01-19 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_161_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_161_chunk (
    CONSTRAINT constraint_161 CHECK ((("time" >= '2023-01-19 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-01-26 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_162_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_162_chunk (
    CONSTRAINT constraint_162 CHECK ((("time" >= '2023-01-26 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-02-02 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_163_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_163_chunk (
    CONSTRAINT constraint_163 CHECK ((("time" >= '2023-02-02 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-02-09 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_164_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_164_chunk (
    CONSTRAINT constraint_164 CHECK ((("time" >= '2023-02-09 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-02-16 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_165_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_165_chunk (
    CONSTRAINT constraint_165 CHECK ((("time" >= '2023-02-16 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-02-23 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_166_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_166_chunk (
    CONSTRAINT constraint_166 CHECK ((("time" >= '2023-02-23 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-03-02 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_167_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_167_chunk (
    CONSTRAINT constraint_167 CHECK ((("time" >= '2023-03-02 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-03-09 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_168_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_168_chunk (
    CONSTRAINT constraint_168 CHECK ((("time" >= '2023-03-09 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-03-16 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_169_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_169_chunk (
    CONSTRAINT constraint_169 CHECK ((("time" >= '2023-03-16 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-03-23 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_16_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_16_chunk (
    CONSTRAINT constraint_16 CHECK ((("time" >= '2020-04-09 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-04-16 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_170_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_170_chunk (
    CONSTRAINT constraint_170 CHECK ((("time" >= '2023-03-23 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-03-30 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_171_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_171_chunk (
    CONSTRAINT constraint_171 CHECK ((("time" >= '2023-03-30 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-04-06 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_172_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_172_chunk (
    CONSTRAINT constraint_172 CHECK ((("time" >= '2023-04-06 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-04-13 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_173_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_173_chunk (
    CONSTRAINT constraint_173 CHECK ((("time" >= '2023-04-13 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-04-20 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_174_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_174_chunk (
    CONSTRAINT constraint_174 CHECK ((("time" >= '2023-04-20 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-04-27 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_175_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_175_chunk (
    CONSTRAINT constraint_175 CHECK ((("time" >= '2023-04-27 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-05-04 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_176_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_176_chunk (
    CONSTRAINT constraint_176 CHECK ((("time" >= '2023-05-04 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-05-11 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_177_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_177_chunk (
    CONSTRAINT constraint_177 CHECK ((("time" >= '2023-05-11 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-05-18 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_178_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_178_chunk (
    CONSTRAINT constraint_178 CHECK ((("time" >= '2023-05-18 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-05-25 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_179_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_179_chunk (
    CONSTRAINT constraint_179 CHECK ((("time" >= '2023-05-25 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-06-01 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_17_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_17_chunk (
    CONSTRAINT constraint_17 CHECK ((("time" >= '2020-04-16 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-04-23 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_180_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_180_chunk (
    CONSTRAINT constraint_180 CHECK ((("time" >= '2023-06-01 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-06-08 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_181_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_181_chunk (
    CONSTRAINT constraint_181 CHECK ((("time" >= '2023-06-08 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-06-15 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_182_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_182_chunk (
    CONSTRAINT constraint_182 CHECK ((("time" >= '2023-06-15 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-06-22 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_183_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_183_chunk (
    CONSTRAINT constraint_183 CHECK ((("time" >= '2023-06-22 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-06-29 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_184_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_184_chunk (
    CONSTRAINT constraint_184 CHECK ((("time" >= '2023-06-29 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-07-06 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_185_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_185_chunk (
    CONSTRAINT constraint_185 CHECK ((("time" >= '2023-07-06 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-07-13 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_186_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_186_chunk (
    CONSTRAINT constraint_186 CHECK ((("time" >= '2023-07-13 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-07-20 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_187_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_187_chunk (
    CONSTRAINT constraint_187 CHECK ((("time" >= '2023-07-20 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-07-27 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_188_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_188_chunk (
    CONSTRAINT constraint_188 CHECK ((("time" >= '2023-07-27 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-08-03 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_189_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_189_chunk (
    CONSTRAINT constraint_189 CHECK ((("time" >= '2023-08-03 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-08-10 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_18_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_18_chunk (
    CONSTRAINT constraint_18 CHECK ((("time" >= '2020-04-23 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-04-30 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_190_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_190_chunk (
    CONSTRAINT constraint_190 CHECK ((("time" >= '2023-08-10 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-08-17 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_191_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_191_chunk (
    CONSTRAINT constraint_191 CHECK ((("time" >= '2023-08-17 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-08-24 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_192_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_192_chunk (
    CONSTRAINT constraint_192 CHECK ((("time" >= '2023-08-24 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-08-31 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_193_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_193_chunk (
    CONSTRAINT constraint_193 CHECK ((("time" >= '2023-08-31 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-09-07 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_194_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_194_chunk (
    CONSTRAINT constraint_194 CHECK ((("time" >= '2023-09-07 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-09-14 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_195_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_195_chunk (
    CONSTRAINT constraint_195 CHECK ((("time" >= '2023-09-14 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-09-21 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_196_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_196_chunk (
    CONSTRAINT constraint_196 CHECK ((("time" >= '2023-09-21 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-09-28 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_197_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_197_chunk (
    CONSTRAINT constraint_197 CHECK ((("time" >= '2023-09-28 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-10-05 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_198_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_198_chunk (
    CONSTRAINT constraint_198 CHECK ((("time" >= '2023-10-05 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-10-12 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_199_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_199_chunk (
    CONSTRAINT constraint_199 CHECK ((("time" >= '2023-10-12 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-10-19 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_19_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_19_chunk (
    CONSTRAINT constraint_19 CHECK ((("time" >= '2020-04-30 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-05-07 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_200_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_200_chunk (
    CONSTRAINT constraint_200 CHECK ((("time" >= '2023-10-19 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-10-26 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_201_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_201_chunk (
    CONSTRAINT constraint_201 CHECK ((("time" >= '2023-10-26 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-11-02 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_202_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_202_chunk (
    CONSTRAINT constraint_202 CHECK ((("time" >= '2023-11-02 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-11-09 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_203_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_203_chunk (
    CONSTRAINT constraint_203 CHECK ((("time" >= '2023-11-09 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-11-16 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_204_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_204_chunk (
    CONSTRAINT constraint_204 CHECK ((("time" >= '2023-11-16 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-11-23 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_205_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_205_chunk (
    CONSTRAINT constraint_205 CHECK ((("time" >= '2023-11-23 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-11-30 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_206_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_206_chunk (
    CONSTRAINT constraint_206 CHECK ((("time" >= '2023-11-30 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-12-07 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_207_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_207_chunk (
    CONSTRAINT constraint_207 CHECK ((("time" >= '2023-12-07 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-12-14 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_208_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_208_chunk (
    CONSTRAINT constraint_208 CHECK ((("time" >= '2023-12-14 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-12-21 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_209_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_209_chunk (
    CONSTRAINT constraint_209 CHECK ((("time" >= '2023-12-21 00:00:00+00'::timestamp with time zone) AND ("time" < '2023-12-28 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_20_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_20_chunk (
    CONSTRAINT constraint_20 CHECK ((("time" >= '2020-05-07 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-05-14 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_210_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_210_chunk (
    CONSTRAINT constraint_210 CHECK ((("time" >= '2023-12-28 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-01-04 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_211_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_211_chunk (
    CONSTRAINT constraint_211 CHECK ((("time" >= '2024-01-04 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-01-11 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_212_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_212_chunk (
    CONSTRAINT constraint_212 CHECK ((("time" >= '2024-01-11 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-01-18 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_213_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_213_chunk (
    CONSTRAINT constraint_213 CHECK ((("time" >= '2024-01-18 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-01-25 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_214_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_214_chunk (
    CONSTRAINT constraint_214 CHECK ((("time" >= '2024-01-25 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-02-01 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_215_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_215_chunk (
    CONSTRAINT constraint_215 CHECK ((("time" >= '2024-02-01 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-02-08 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_216_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_216_chunk (
    CONSTRAINT constraint_216 CHECK ((("time" >= '2024-02-08 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-02-15 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_217_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_217_chunk (
    CONSTRAINT constraint_217 CHECK ((("time" >= '2024-02-15 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-02-22 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_218_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_218_chunk (
    CONSTRAINT constraint_218 CHECK ((("time" >= '2024-02-22 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-02-29 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_219_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_219_chunk (
    CONSTRAINT constraint_219 CHECK ((("time" >= '2024-02-29 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-03-07 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_21_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_21_chunk (
    CONSTRAINT constraint_21 CHECK ((("time" >= '2020-05-14 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-05-21 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_220_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_220_chunk (
    CONSTRAINT constraint_220 CHECK ((("time" >= '2024-03-07 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-03-14 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_221_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_221_chunk (
    CONSTRAINT constraint_221 CHECK ((("time" >= '2024-03-14 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-03-21 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_222_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_222_chunk (
    CONSTRAINT constraint_222 CHECK ((("time" >= '2024-03-21 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-03-28 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_223_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_223_chunk (
    CONSTRAINT constraint_223 CHECK ((("time" >= '2024-03-28 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-04-04 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_224_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_224_chunk (
    CONSTRAINT constraint_224 CHECK ((("time" >= '2024-04-04 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-04-11 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_225_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_225_chunk (
    CONSTRAINT constraint_225 CHECK ((("time" >= '2024-04-11 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-04-18 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_226_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_226_chunk (
    CONSTRAINT constraint_226 CHECK ((("time" >= '2024-04-18 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-04-25 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_227_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_227_chunk (
    CONSTRAINT constraint_227 CHECK ((("time" >= '2024-04-25 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-05-02 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_228_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_228_chunk (
    CONSTRAINT constraint_228 CHECK ((("time" >= '2024-05-02 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-05-09 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_229_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_229_chunk (
    CONSTRAINT constraint_229 CHECK ((("time" >= '2024-05-09 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-05-16 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_22_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_22_chunk (
    CONSTRAINT constraint_22 CHECK ((("time" >= '2020-05-21 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-05-28 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_230_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_230_chunk (
    CONSTRAINT constraint_230 CHECK ((("time" >= '2024-05-16 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-05-23 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_231_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_231_chunk (
    CONSTRAINT constraint_231 CHECK ((("time" >= '2024-05-23 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-05-30 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_232_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_232_chunk (
    CONSTRAINT constraint_232 CHECK ((("time" >= '2024-05-30 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-06-06 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_233_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_233_chunk (
    CONSTRAINT constraint_233 CHECK ((("time" >= '2024-06-06 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-06-13 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_234_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_234_chunk (
    CONSTRAINT constraint_234 CHECK ((("time" >= '2024-06-13 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-06-20 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_235_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_235_chunk (
    CONSTRAINT constraint_235 CHECK ((("time" >= '2024-06-20 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-06-27 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_236_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_236_chunk (
    CONSTRAINT constraint_236 CHECK ((("time" >= '2024-06-27 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-07-04 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_237_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_237_chunk (
    CONSTRAINT constraint_237 CHECK ((("time" >= '2024-07-04 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-07-11 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_238_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_238_chunk (
    CONSTRAINT constraint_238 CHECK ((("time" >= '2024-07-11 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-07-18 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_239_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_239_chunk (
    CONSTRAINT constraint_239 CHECK ((("time" >= '2024-07-18 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-07-25 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_23_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_23_chunk (
    CONSTRAINT constraint_23 CHECK ((("time" >= '2020-05-28 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-06-04 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_240_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_240_chunk (
    CONSTRAINT constraint_240 CHECK ((("time" >= '2024-07-25 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-08-01 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_241_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_241_chunk (
    CONSTRAINT constraint_241 CHECK ((("time" >= '2024-08-01 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-08-08 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_242_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_242_chunk (
    CONSTRAINT constraint_242 CHECK ((("time" >= '2024-08-08 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-08-15 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_243_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_243_chunk (
    CONSTRAINT constraint_243 CHECK ((("time" >= '2024-08-15 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-08-22 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_244_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_244_chunk (
    CONSTRAINT constraint_244 CHECK ((("time" >= '2024-08-22 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-08-29 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_245_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_245_chunk (
    CONSTRAINT constraint_245 CHECK ((("time" >= '2024-08-29 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-09-05 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_246_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_246_chunk (
    CONSTRAINT constraint_246 CHECK ((("time" >= '2024-09-05 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-09-12 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_247_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_247_chunk (
    CONSTRAINT constraint_247 CHECK ((("time" >= '2024-09-12 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-09-19 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_248_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_248_chunk (
    CONSTRAINT constraint_248 CHECK ((("time" >= '2024-09-19 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-09-26 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_249_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_249_chunk (
    CONSTRAINT constraint_249 CHECK ((("time" >= '2024-09-26 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-10-03 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_24_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_24_chunk (
    CONSTRAINT constraint_24 CHECK ((("time" >= '2020-06-04 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-06-11 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_250_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_250_chunk (
    CONSTRAINT constraint_250 CHECK ((("time" >= '2024-10-03 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-10-10 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_251_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_251_chunk (
    CONSTRAINT constraint_251 CHECK ((("time" >= '2024-10-10 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-10-17 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_252_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_252_chunk (
    CONSTRAINT constraint_252 CHECK ((("time" >= '2024-10-17 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-10-24 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_253_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_253_chunk (
    CONSTRAINT constraint_253 CHECK ((("time" >= '2024-10-24 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-10-31 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_254_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_254_chunk (
    CONSTRAINT constraint_254 CHECK ((("time" >= '2024-10-31 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-11-07 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_255_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_255_chunk (
    CONSTRAINT constraint_255 CHECK ((("time" >= '2024-11-07 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-11-14 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_256_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_256_chunk (
    CONSTRAINT constraint_256 CHECK ((("time" >= '2024-11-14 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-11-21 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_257_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_257_chunk (
    CONSTRAINT constraint_257 CHECK ((("time" >= '2024-11-21 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-11-28 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_258_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_258_chunk (
    CONSTRAINT constraint_258 CHECK ((("time" >= '2024-11-28 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-12-05 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_259_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_259_chunk (
    CONSTRAINT constraint_259 CHECK ((("time" >= '2024-12-05 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-12-12 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_25_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_25_chunk (
    CONSTRAINT constraint_25 CHECK ((("time" >= '2020-06-11 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-06-18 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_260_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_260_chunk (
    CONSTRAINT constraint_260 CHECK ((("time" >= '2024-12-12 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-12-19 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_261_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_261_chunk (
    CONSTRAINT constraint_261 CHECK ((("time" >= '2024-12-19 00:00:00+00'::timestamp with time zone) AND ("time" < '2024-12-26 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_262_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_262_chunk (
    CONSTRAINT constraint_262 CHECK ((("time" >= '2024-12-26 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-01-02 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_263_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_263_chunk (
    CONSTRAINT constraint_263 CHECK ((("time" >= '2025-01-02 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-01-09 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_264_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_264_chunk (
    CONSTRAINT constraint_264 CHECK ((("time" >= '2025-01-09 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-01-16 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_265_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_265_chunk (
    CONSTRAINT constraint_265 CHECK ((("time" >= '2025-01-16 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-01-23 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_266_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_266_chunk (
    CONSTRAINT constraint_266 CHECK ((("time" >= '2025-01-23 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-01-30 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_267_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_267_chunk (
    CONSTRAINT constraint_267 CHECK ((("time" >= '2025-01-30 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-02-06 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_268_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_268_chunk (
    CONSTRAINT constraint_268 CHECK ((("time" >= '2025-02-06 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-02-13 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_269_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_269_chunk (
    CONSTRAINT constraint_269 CHECK ((("time" >= '2025-02-13 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-02-20 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_26_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_26_chunk (
    CONSTRAINT constraint_26 CHECK ((("time" >= '2020-06-18 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-06-25 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_270_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_270_chunk (
    CONSTRAINT constraint_270 CHECK ((("time" >= '2025-02-20 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-02-27 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_271_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_271_chunk (
    CONSTRAINT constraint_271 CHECK ((("time" >= '2025-02-27 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-03-06 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_272_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_272_chunk (
    CONSTRAINT constraint_272 CHECK ((("time" >= '2025-03-06 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-03-13 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_273_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_273_chunk (
    CONSTRAINT constraint_273 CHECK ((("time" >= '2025-03-13 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-03-20 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_274_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_274_chunk (
    CONSTRAINT constraint_274 CHECK ((("time" >= '2025-03-20 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-03-27 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_275_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_275_chunk (
    CONSTRAINT constraint_275 CHECK ((("time" >= '2025-03-27 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-04-03 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_276_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_276_chunk (
    CONSTRAINT constraint_276 CHECK ((("time" >= '2025-04-03 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-04-10 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_277_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_277_chunk (
    CONSTRAINT constraint_277 CHECK ((("time" >= '2025-04-10 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-04-17 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_278_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_278_chunk (
    CONSTRAINT constraint_278 CHECK ((("time" >= '2025-04-17 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-04-24 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_279_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_279_chunk (
    CONSTRAINT constraint_279 CHECK ((("time" >= '2025-04-24 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-05-01 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_27_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_27_chunk (
    CONSTRAINT constraint_27 CHECK ((("time" >= '2020-06-25 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-07-02 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_280_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_280_chunk (
    CONSTRAINT constraint_280 CHECK ((("time" >= '2025-05-01 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-05-08 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_281_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_281_chunk (
    CONSTRAINT constraint_281 CHECK ((("time" >= '2025-05-08 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-05-15 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_282_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_282_chunk (
    CONSTRAINT constraint_282 CHECK ((("time" >= '2025-05-15 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-05-22 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_283_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_283_chunk (
    CONSTRAINT constraint_283 CHECK ((("time" >= '2025-05-22 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-05-29 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_284_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_284_chunk (
    CONSTRAINT constraint_284 CHECK ((("time" >= '2025-05-29 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-06-05 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_285_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_285_chunk (
    CONSTRAINT constraint_285 CHECK ((("time" >= '2025-06-05 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-06-12 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_286_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_286_chunk (
    CONSTRAINT constraint_286 CHECK ((("time" >= '2025-06-12 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-06-19 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_287_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_287_chunk (
    CONSTRAINT constraint_287 CHECK ((("time" >= '2025-06-19 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-06-26 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_288_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_288_chunk (
    CONSTRAINT constraint_288 CHECK ((("time" >= '2025-06-26 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-07-03 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_289_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_289_chunk (
    CONSTRAINT constraint_289 CHECK ((("time" >= '2025-07-03 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-07-10 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_28_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_28_chunk (
    CONSTRAINT constraint_28 CHECK ((("time" >= '2020-07-02 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-07-09 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_290_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_290_chunk (
    CONSTRAINT constraint_290 CHECK ((("time" >= '2025-07-10 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-07-17 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_291_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_291_chunk (
    CONSTRAINT constraint_291 CHECK ((("time" >= '2025-07-17 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-07-24 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_292_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_292_chunk (
    CONSTRAINT constraint_292 CHECK ((("time" >= '2025-07-24 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-07-31 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_293_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_293_chunk (
    CONSTRAINT constraint_293 CHECK ((("time" >= '2025-07-31 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-08-07 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_294_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_294_chunk (
    CONSTRAINT constraint_294 CHECK ((("time" >= '2025-08-07 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-08-14 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_295_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_295_chunk (
    CONSTRAINT constraint_295 CHECK ((("time" >= '2025-08-14 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-08-21 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_296_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_296_chunk (
    CONSTRAINT constraint_296 CHECK ((("time" >= '2025-08-21 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-08-28 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_297_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_297_chunk (
    CONSTRAINT constraint_297 CHECK ((("time" >= '2025-08-28 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-09-04 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_298_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_298_chunk (
    CONSTRAINT constraint_298 CHECK ((("time" >= '2025-09-04 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-09-11 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_299_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_299_chunk (
    CONSTRAINT constraint_299 CHECK ((("time" >= '2025-09-11 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-09-18 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_29_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_29_chunk (
    CONSTRAINT constraint_29 CHECK ((("time" >= '2020-07-09 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-07-16 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_2_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_2_chunk (
    CONSTRAINT constraint_2 CHECK ((("time" >= '2020-01-02 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-01-09 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_300_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_300_chunk (
    CONSTRAINT constraint_300 CHECK ((("time" >= '2025-09-18 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-09-25 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_301_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_301_chunk (
    CONSTRAINT constraint_301 CHECK ((("time" >= '2025-09-25 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-10-02 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_302_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_302_chunk (
    CONSTRAINT constraint_302 CHECK ((("time" >= '2025-10-02 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-10-09 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_303_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_303_chunk (
    CONSTRAINT constraint_303 CHECK ((("time" >= '2025-10-09 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-10-16 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_304_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_304_chunk (
    CONSTRAINT constraint_304 CHECK ((("time" >= '2025-10-16 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-10-23 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_305_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_305_chunk (
    CONSTRAINT constraint_305 CHECK ((("time" >= '2025-10-23 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-10-30 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_306_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_306_chunk (
    CONSTRAINT constraint_306 CHECK ((("time" >= '2025-10-30 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-11-06 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_307_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_307_chunk (
    CONSTRAINT constraint_307 CHECK ((("time" >= '2025-11-06 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-11-13 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_308_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_308_chunk (
    CONSTRAINT constraint_308 CHECK ((("time" >= '2025-12-04 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-12-11 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_309_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_309_chunk (
    CONSTRAINT constraint_309 CHECK ((("time" >= '2025-12-11 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-12-18 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_30_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_30_chunk (
    CONSTRAINT constraint_30 CHECK ((("time" >= '2020-07-16 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-07-23 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_310_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_310_chunk (
    CONSTRAINT constraint_310 CHECK ((("time" >= '2025-12-25 00:00:00+00'::timestamp with time zone) AND ("time" < '2026-01-01 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_311_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_311_chunk (
    CONSTRAINT constraint_311 CHECK ((("time" >= '2026-01-01 00:00:00+00'::timestamp with time zone) AND ("time" < '2026-01-08 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_312_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_312_chunk (
    CONSTRAINT constraint_312 CHECK ((("time" >= '2025-12-18 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-12-25 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_313_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_313_chunk (
    CONSTRAINT constraint_313 CHECK ((("time" >= '2026-01-08 00:00:00+00'::timestamp with time zone) AND ("time" < '2026-01-15 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_314_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_314_chunk (
    CONSTRAINT constraint_314 CHECK ((("time" >= '2025-11-13 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-11-20 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_315_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_315_chunk (
    CONSTRAINT constraint_315 CHECK ((("time" >= '2025-11-27 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-12-04 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_316_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_316_chunk (
    CONSTRAINT constraint_316 CHECK ((("time" >= '2025-11-20 00:00:00+00'::timestamp with time zone) AND ("time" < '2025-11-27 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_31_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_31_chunk (
    CONSTRAINT constraint_31 CHECK ((("time" >= '2020-07-23 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-07-30 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_32_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_32_chunk (
    CONSTRAINT constraint_32 CHECK ((("time" >= '2020-07-30 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-08-06 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_33_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_33_chunk (
    CONSTRAINT constraint_33 CHECK ((("time" >= '2020-08-06 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-08-13 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_34_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_34_chunk (
    CONSTRAINT constraint_34 CHECK ((("time" >= '2020-08-13 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-08-20 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_35_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_35_chunk (
    CONSTRAINT constraint_35 CHECK ((("time" >= '2020-08-20 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-08-27 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_36_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_36_chunk (
    CONSTRAINT constraint_36 CHECK ((("time" >= '2020-08-27 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-09-03 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_37_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_37_chunk (
    CONSTRAINT constraint_37 CHECK ((("time" >= '2020-09-03 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-09-10 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_38_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_38_chunk (
    CONSTRAINT constraint_38 CHECK ((("time" >= '2020-09-10 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-09-17 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_39_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_39_chunk (
    CONSTRAINT constraint_39 CHECK ((("time" >= '2020-09-17 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-09-24 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_3_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_3_chunk (
    CONSTRAINT constraint_3 CHECK ((("time" >= '2020-01-09 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-01-16 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_40_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_40_chunk (
    CONSTRAINT constraint_40 CHECK ((("time" >= '2020-09-24 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-10-01 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_41_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_41_chunk (
    CONSTRAINT constraint_41 CHECK ((("time" >= '2020-10-01 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-10-08 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_42_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_42_chunk (
    CONSTRAINT constraint_42 CHECK ((("time" >= '2020-10-08 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-10-15 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_43_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_43_chunk (
    CONSTRAINT constraint_43 CHECK ((("time" >= '2020-10-15 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-10-22 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_44_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_44_chunk (
    CONSTRAINT constraint_44 CHECK ((("time" >= '2020-10-22 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-10-29 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_45_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_45_chunk (
    CONSTRAINT constraint_45 CHECK ((("time" >= '2020-10-29 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-11-05 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_46_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_46_chunk (
    CONSTRAINT constraint_46 CHECK ((("time" >= '2020-11-05 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-11-12 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_47_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_47_chunk (
    CONSTRAINT constraint_47 CHECK ((("time" >= '2020-11-12 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-11-19 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_48_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_48_chunk (
    CONSTRAINT constraint_48 CHECK ((("time" >= '2020-11-19 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-11-26 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_49_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_49_chunk (
    CONSTRAINT constraint_49 CHECK ((("time" >= '2020-11-26 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-12-03 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_4_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_4_chunk (
    CONSTRAINT constraint_4 CHECK ((("time" >= '2020-01-16 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-01-23 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_50_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_50_chunk (
    CONSTRAINT constraint_50 CHECK ((("time" >= '2020-12-03 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-12-10 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_51_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_51_chunk (
    CONSTRAINT constraint_51 CHECK ((("time" >= '2020-12-10 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-12-17 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_52_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_52_chunk (
    CONSTRAINT constraint_52 CHECK ((("time" >= '2020-12-17 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-12-24 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_53_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_53_chunk (
    CONSTRAINT constraint_53 CHECK ((("time" >= '2020-12-24 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-12-31 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_54_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_54_chunk (
    CONSTRAINT constraint_54 CHECK ((("time" >= '2020-12-31 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-01-07 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_55_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_55_chunk (
    CONSTRAINT constraint_55 CHECK ((("time" >= '2021-01-07 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-01-14 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_56_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_56_chunk (
    CONSTRAINT constraint_56 CHECK ((("time" >= '2021-01-14 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-01-21 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_57_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_57_chunk (
    CONSTRAINT constraint_57 CHECK ((("time" >= '2021-01-21 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-01-28 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_58_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_58_chunk (
    CONSTRAINT constraint_58 CHECK ((("time" >= '2021-01-28 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-02-04 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_59_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_59_chunk (
    CONSTRAINT constraint_59 CHECK ((("time" >= '2021-02-04 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-02-11 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_5_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_5_chunk (
    CONSTRAINT constraint_5 CHECK ((("time" >= '2020-01-23 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-01-30 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_60_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_60_chunk (
    CONSTRAINT constraint_60 CHECK ((("time" >= '2021-02-11 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-02-18 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_61_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_61_chunk (
    CONSTRAINT constraint_61 CHECK ((("time" >= '2021-02-18 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-02-25 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_62_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_62_chunk (
    CONSTRAINT constraint_62 CHECK ((("time" >= '2021-02-25 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-03-04 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_63_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_63_chunk (
    CONSTRAINT constraint_63 CHECK ((("time" >= '2021-03-04 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-03-11 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_64_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_64_chunk (
    CONSTRAINT constraint_64 CHECK ((("time" >= '2021-03-11 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-03-18 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_65_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_65_chunk (
    CONSTRAINT constraint_65 CHECK ((("time" >= '2021-03-18 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-03-25 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_66_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_66_chunk (
    CONSTRAINT constraint_66 CHECK ((("time" >= '2021-03-25 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-04-01 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_67_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_67_chunk (
    CONSTRAINT constraint_67 CHECK ((("time" >= '2021-04-01 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-04-08 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_68_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_68_chunk (
    CONSTRAINT constraint_68 CHECK ((("time" >= '2021-04-08 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-04-15 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_69_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_69_chunk (
    CONSTRAINT constraint_69 CHECK ((("time" >= '2021-04-15 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-04-22 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_6_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_6_chunk (
    CONSTRAINT constraint_6 CHECK ((("time" >= '2020-01-30 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-02-06 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_70_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_70_chunk (
    CONSTRAINT constraint_70 CHECK ((("time" >= '2021-04-22 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-04-29 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_71_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_71_chunk (
    CONSTRAINT constraint_71 CHECK ((("time" >= '2021-04-29 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-05-06 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_72_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_72_chunk (
    CONSTRAINT constraint_72 CHECK ((("time" >= '2021-05-06 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-05-13 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_73_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_73_chunk (
    CONSTRAINT constraint_73 CHECK ((("time" >= '2021-05-13 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-05-20 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_74_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_74_chunk (
    CONSTRAINT constraint_74 CHECK ((("time" >= '2021-05-20 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-05-27 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_75_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_75_chunk (
    CONSTRAINT constraint_75 CHECK ((("time" >= '2021-05-27 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-06-03 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_76_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_76_chunk (
    CONSTRAINT constraint_76 CHECK ((("time" >= '2021-06-03 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-06-10 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_77_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_77_chunk (
    CONSTRAINT constraint_77 CHECK ((("time" >= '2021-06-10 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-06-17 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_78_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_78_chunk (
    CONSTRAINT constraint_78 CHECK ((("time" >= '2021-06-17 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-06-24 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_79_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_79_chunk (
    CONSTRAINT constraint_79 CHECK ((("time" >= '2021-06-24 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-07-01 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_7_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_7_chunk (
    CONSTRAINT constraint_7 CHECK ((("time" >= '2020-02-06 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-02-13 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_80_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_80_chunk (
    CONSTRAINT constraint_80 CHECK ((("time" >= '2021-07-01 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-07-08 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_81_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_81_chunk (
    CONSTRAINT constraint_81 CHECK ((("time" >= '2021-07-08 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-07-15 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_82_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_82_chunk (
    CONSTRAINT constraint_82 CHECK ((("time" >= '2021-07-15 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-07-22 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_83_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_83_chunk (
    CONSTRAINT constraint_83 CHECK ((("time" >= '2021-07-22 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-07-29 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_84_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_84_chunk (
    CONSTRAINT constraint_84 CHECK ((("time" >= '2021-07-29 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-08-05 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_85_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_85_chunk (
    CONSTRAINT constraint_85 CHECK ((("time" >= '2021-08-05 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-08-12 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_86_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_86_chunk (
    CONSTRAINT constraint_86 CHECK ((("time" >= '2021-08-12 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-08-19 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_87_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_87_chunk (
    CONSTRAINT constraint_87 CHECK ((("time" >= '2021-08-19 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-08-26 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_88_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_88_chunk (
    CONSTRAINT constraint_88 CHECK ((("time" >= '2021-08-26 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-09-02 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_89_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_89_chunk (
    CONSTRAINT constraint_89 CHECK ((("time" >= '2021-09-02 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-09-09 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_8_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_8_chunk (
    CONSTRAINT constraint_8 CHECK ((("time" >= '2020-02-13 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-02-20 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_90_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_90_chunk (
    CONSTRAINT constraint_90 CHECK ((("time" >= '2021-09-09 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-09-16 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_91_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_91_chunk (
    CONSTRAINT constraint_91 CHECK ((("time" >= '2021-09-16 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-09-23 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_92_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_92_chunk (
    CONSTRAINT constraint_92 CHECK ((("time" >= '2021-09-23 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-09-30 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_93_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_93_chunk (
    CONSTRAINT constraint_93 CHECK ((("time" >= '2021-09-30 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-10-07 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_94_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_94_chunk (
    CONSTRAINT constraint_94 CHECK ((("time" >= '2021-10-07 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-10-14 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_95_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_95_chunk (
    CONSTRAINT constraint_95 CHECK ((("time" >= '2021-10-14 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-10-21 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_96_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_96_chunk (
    CONSTRAINT constraint_96 CHECK ((("time" >= '2021-10-21 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-10-28 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_97_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_97_chunk (
    CONSTRAINT constraint_97 CHECK ((("time" >= '2021-10-28 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-11-04 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_98_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_98_chunk (
    CONSTRAINT constraint_98 CHECK ((("time" >= '2021-11-04 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-11-11 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_99_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_99_chunk (
    CONSTRAINT constraint_99 CHECK ((("time" >= '2021-11-11 00:00:00+00'::timestamp with time zone) AND ("time" < '2021-11-18 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: _hyper_1_9_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: -
--

CREATE TABLE _timescaledb_internal._hyper_1_9_chunk (
    CONSTRAINT constraint_9 CHECK ((("time" >= '2020-02-20 00:00:00+00'::timestamp with time zone) AND ("time" < '2020-02-27 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.usdcop_m5_ohlcv);


--
-- Name: feature_definitions; Type: TABLE; Schema: config; Owner: -
--

CREATE TABLE config.feature_definitions (
    feature_id integer NOT NULL,
    feature_name character varying(100) NOT NULL,
    feature_group character varying(50) NOT NULL,
    normalization_mean double precision,
    normalization_std double precision,
    clip_min double precision,
    clip_max double precision,
    source_table character varying(100),
    source_column character varying(100),
    transformation character varying(200),
    observation_order integer NOT NULL,
    compute_location character varying(20) DEFAULT 'sql'::character varying,
    python_function character varying(200),
    sql_formula text,
    lookback_bars integer DEFAULT 1,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT chk_compute_location CHECK (((compute_location)::text = ANY ((ARRAY['sql'::character varying, 'python'::character varying, 'hybrid'::character varying])::text[]))),
    CONSTRAINT chk_feature_group CHECK (((feature_group)::text = ANY ((ARRAY['price_returns'::character varying, 'momentum'::character varying, 'volatility'::character varying, 'trend'::character varying, 'macro_zscore'::character varying, 'macro_changes'::character varying, 'macro_derived'::character varying, 'macro_momentum'::character varying, 'macro_volatility'::character varying, 'temporal'::character varying, 'regime'::character varying, 'state'::character varying])::text[])))
);


--
-- Name: TABLE feature_definitions; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON TABLE config.feature_definitions IS 'Feature definitions with normalization statistics for observation space. Order matches model training.';


--
-- Name: COLUMN feature_definitions.feature_name; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON COLUMN config.feature_definitions.feature_name IS 'Unique feature identifier (e.g., log_ret_5m, rsi_9)';


--
-- Name: COLUMN feature_definitions.feature_group; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON COLUMN config.feature_definitions.feature_group IS 'Category: price_returns, momentum, volatility, trend, macro_zscore, macro_changes, macro_derived, regime, state';


--
-- Name: COLUMN feature_definitions.normalization_mean; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON COLUMN config.feature_definitions.normalization_mean IS 'Mean value from training dataset for z-score normalization';


--
-- Name: COLUMN feature_definitions.normalization_std; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON COLUMN config.feature_definitions.normalization_std IS 'Standard deviation from training dataset for z-score normalization';


--
-- Name: COLUMN feature_definitions.clip_min; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON COLUMN config.feature_definitions.clip_min IS 'Minimum clip value after transformation';


--
-- Name: COLUMN feature_definitions.clip_max; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON COLUMN config.feature_definitions.clip_max IS 'Maximum clip value after transformation';


--
-- Name: COLUMN feature_definitions.source_table; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON COLUMN config.feature_definitions.source_table IS 'Source database table (usdcop_m5_ohlcv, macro_indicators_daily)';


--
-- Name: COLUMN feature_definitions.source_column; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON COLUMN config.feature_definitions.source_column IS 'Source column name in the table';


--
-- Name: COLUMN feature_definitions.transformation; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON COLUMN config.feature_definitions.transformation IS 'Transformation type: zscore, pct_change, raw, etc.';


--
-- Name: COLUMN feature_definitions.observation_order; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON COLUMN config.feature_definitions.observation_order IS 'Position in observation vector (0-indexed, must match model training)';


--
-- Name: COLUMN feature_definitions.compute_location; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON COLUMN config.feature_definitions.compute_location IS 'Where feature is computed: sql, python, hybrid';


--
-- Name: COLUMN feature_definitions.python_function; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON COLUMN config.feature_definitions.python_function IS 'Python function name if compute_location is python';


--
-- Name: COLUMN feature_definitions.sql_formula; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON COLUMN config.feature_definitions.sql_formula IS 'SQL formula if compute_location is sql';


--
-- Name: COLUMN feature_definitions.lookback_bars; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON COLUMN config.feature_definitions.lookback_bars IS 'Number of historical bars needed for computation';


--
-- Name: COLUMN feature_definitions.is_active; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON COLUMN config.feature_definitions.is_active IS 'Whether feature is currently used in production';


--
-- Name: feature_definitions_feature_id_seq; Type: SEQUENCE; Schema: config; Owner: -
--

CREATE SEQUENCE config.feature_definitions_feature_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: feature_definitions_feature_id_seq; Type: SEQUENCE OWNED BY; Schema: config; Owner: -
--

ALTER SEQUENCE config.feature_definitions_feature_id_seq OWNED BY config.feature_definitions.feature_id;


--
-- Name: models; Type: TABLE; Schema: config; Owner: -
--

CREATE TABLE config.models (
    model_id character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    algorithm character varying(20) NOT NULL,
    version character varying(20) NOT NULL,
    status character varying(20) DEFAULT 'inactive'::character varying,
    color character varying(7) DEFAULT '#3B82F6'::character varying,
    hyperparameters jsonb DEFAULT '{}'::jsonb NOT NULL,
    policy_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    environment_config jsonb DEFAULT '{}'::jsonb NOT NULL,
    backtest_metrics jsonb DEFAULT '{}'::jsonb,
    model_path character varying(500),
    framework character varying(50) DEFAULT 'stable-baselines3'::character varying,
    description text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT chk_model_algorithm CHECK (((algorithm)::text = ANY ((ARRAY['PPO'::character varying, 'SAC'::character varying, 'TD3'::character varying, 'A2C'::character varying, 'DQN'::character varying, 'DDPG'::character varying])::text[]))),
    CONSTRAINT chk_model_color CHECK (((color)::text ~ '^#[0-9A-Fa-f]{6}$'::text)),
    CONSTRAINT chk_model_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying, 'training'::character varying, 'deprecated'::character varying, 'testing'::character varying])::text[])))
);


--
-- Name: TABLE models; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON TABLE config.models IS 'Configuration for all RL trading models including hyperparameters, policy architecture, and performance metrics';


--
-- Name: COLUMN models.model_id; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON COLUMN config.models.model_id IS 'Unique identifier for the model (e.g., ppo_v19_model_b)';


--
-- Name: COLUMN models.name; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON COLUMN config.models.name IS 'Human-readable model name (e.g., Model B Aggressive)';


--
-- Name: COLUMN models.algorithm; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON COLUMN config.models.algorithm IS 'RL algorithm: PPO, SAC, TD3, A2C, DQN, DDPG';


--
-- Name: COLUMN models.version; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON COLUMN config.models.version IS 'Model version string (e.g., V19, V20)';


--
-- Name: COLUMN models.status; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON COLUMN config.models.status IS 'Current status: active, inactive, training, deprecated, testing';


--
-- Name: COLUMN models.color; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON COLUMN config.models.color IS 'Hex color code for UI visualization';


--
-- Name: COLUMN models.hyperparameters; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON COLUMN config.models.hyperparameters IS 'JSON with learning_rate, n_steps, batch_size, n_epochs, gamma, ent_coef, clip_range, gae_lambda, max_grad_norm, vf_coef';


--
-- Name: COLUMN models.policy_config; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON COLUMN config.models.policy_config IS 'JSON with net_arch, activation_fn, policy type';


--
-- Name: COLUMN models.environment_config; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON COLUMN config.models.environment_config IS 'JSON with episode_length, max_position, bars_per_day, initial_balance';


--
-- Name: COLUMN models.backtest_metrics; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON COLUMN config.models.backtest_metrics IS 'JSON with sharpe_ratio, max_drawdown, win_rate, hold_pct, total_return';


--
-- Name: COLUMN models.model_path; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON COLUMN config.models.model_path IS 'Path to model artifact file (.zip)';


--
-- Name: COLUMN models.framework; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON COLUMN config.models.framework IS 'ML framework used (stable-baselines3, rllib, etc.)';


--
-- Name: vw_feature_summary; Type: VIEW; Schema: config; Owner: -
--

CREATE VIEW config.vw_feature_summary AS
 SELECT f.observation_order,
    f.feature_name,
    f.feature_group,
    f.compute_location,
    COALESCE((f.normalization_mean)::text, 'N/A'::text) AS norm_mean,
    COALESCE((f.normalization_std)::text, 'N/A'::text) AS norm_std,
    COALESCE((((f.clip_min)::text || ' to '::text) || (f.clip_max)::text), 'No clip'::text) AS clip_range,
    f.lookback_bars,
    f.is_active
   FROM config.feature_definitions f
  WHERE (f.is_active = true)
  ORDER BY f.observation_order;


--
-- Name: VIEW vw_feature_summary; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON VIEW config.vw_feature_summary IS 'Active features in observation order with normalization stats';


--
-- Name: vw_model_comparison; Type: VIEW; Schema: config; Owner: -
--

CREATE VIEW config.vw_model_comparison AS
 SELECT m.model_id,
    m.name,
    m.algorithm,
    m.version,
    m.color,
    (m.hyperparameters ->> 'learning_rate'::text) AS learning_rate,
    (m.hyperparameters ->> 'n_steps'::text) AS n_steps,
    (m.hyperparameters ->> 'batch_size'::text) AS batch_size,
    (m.policy_config ->> 'net_arch'::text) AS net_arch,
    (m.policy_config ->> 'activation_fn'::text) AS activation_fn,
    COALESCE(((m.backtest_metrics ->> 'sharpe_ratio'::text))::numeric, (0)::numeric) AS sharpe_ratio,
    COALESCE(((m.backtest_metrics ->> 'max_drawdown'::text))::numeric, (0)::numeric) AS max_drawdown,
    COALESCE(((m.backtest_metrics ->> 'win_rate'::text))::numeric, (0)::numeric) AS win_rate,
    m.status,
    m.updated_at
   FROM config.models m
  ORDER BY
        CASE
            WHEN ((m.status)::text = 'active'::text) THEN 0
            ELSE 1
        END, COALESCE(((m.backtest_metrics ->> 'sharpe_ratio'::text))::numeric, (0)::numeric) DESC;


--
-- Name: VIEW vw_model_comparison; Type: COMMENT; Schema: config; Owner: -
--

COMMENT ON VIEW config.vw_model_comparison IS 'Side-by-side comparison of all models with key hyperparameters and metrics';


--
-- Name: dim_strategy; Type: VIEW; Schema: dw; Owner: -
--

CREATE VIEW dw.dim_strategy AS
 SELECT models.model_id AS strategy_id,
    models.model_id AS strategy_code,
    models.name AS strategy_name,
    models.algorithm AS model_type,
    models.version,
    models.color,
        CASE
            WHEN ((models.status)::text = 'active'::text) THEN true
            ELSE false
        END AS is_active,
    ((models.backtest_metrics ->> 'sharpe_ratio'::text))::numeric AS sharpe_ratio,
    ((models.backtest_metrics ->> 'max_drawdown'::text))::numeric AS max_drawdown,
    ((models.backtest_metrics ->> 'win_rate'::text))::numeric AS win_rate,
    models.description
   FROM config.models;


--
-- Name: VIEW dim_strategy; Type: COMMENT; Schema: dw; Owner: -
--

COMMENT ON VIEW dw.dim_strategy IS 'Compatibility view for legacy API code';


--
-- Name: fact_agent_actions; Type: TABLE; Schema: dw; Owner: -
--

CREATE TABLE dw.fact_agent_actions (
    id bigint NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    bar_number integer,
    action double precision,
    "position" double precision DEFAULT 0.0,
    model_version text,
    created_at timestamp with time zone DEFAULT now(),
    timestamp_utc timestamp with time zone DEFAULT now(),
    marker_type character varying(20) DEFAULT 'dot'::character varying,
    marker_color character varying(20) DEFAULT '#888'::character varying,
    reason_code character varying(50),
    model_id character varying(50)
);


--
-- Name: fact_agent_actions_id_seq; Type: SEQUENCE; Schema: dw; Owner: -
--

CREATE SEQUENCE dw.fact_agent_actions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fact_agent_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: dw; Owner: -
--

ALTER SEQUENCE dw.fact_agent_actions_id_seq OWNED BY dw.fact_agent_actions.id;


--
-- Name: fact_equity_curve_realtime; Type: TABLE; Schema: dw; Owner: -
--

CREATE TABLE dw.fact_equity_curve_realtime (
    id integer NOT NULL,
    session_date date,
    bar_number integer,
    timestamp_cot timestamp with time zone,
    equity_value numeric(15,2),
    return_daily_pct numeric(8,4),
    current_drawdown_pct numeric(8,4),
    current_position numeric(6,4),
    position_side character varying(10),
    market_price numeric(12,5)
);


--
-- Name: fact_equity_curve_realtime_id_seq; Type: SEQUENCE; Schema: dw; Owner: -
--

CREATE SEQUENCE dw.fact_equity_curve_realtime_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fact_equity_curve_realtime_id_seq; Type: SEQUENCE OWNED BY; Schema: dw; Owner: -
--

ALTER SEQUENCE dw.fact_equity_curve_realtime_id_seq OWNED BY dw.fact_equity_curve_realtime.id;


--
-- Name: fact_inference_alerts; Type: TABLE; Schema: dw; Owner: -
--

CREATE TABLE dw.fact_inference_alerts (
    alert_id integer NOT NULL,
    session_date date,
    alert_type character varying(50),
    severity character varying(20),
    message text,
    timestamp_utc timestamp with time zone DEFAULT now(),
    resolved boolean DEFAULT false
);


--
-- Name: fact_inference_alerts_alert_id_seq; Type: SEQUENCE; Schema: dw; Owner: -
--

CREATE SEQUENCE dw.fact_inference_alerts_alert_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fact_inference_alerts_alert_id_seq; Type: SEQUENCE OWNED BY; Schema: dw; Owner: -
--

ALTER SEQUENCE dw.fact_inference_alerts_alert_id_seq OWNED BY dw.fact_inference_alerts.alert_id;


--
-- Name: fact_rl_inference; Type: TABLE; Schema: dw; Owner: -
--

CREATE TABLE dw.fact_rl_inference (
    id bigint NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    bar_number integer,
    action double precision,
    observation jsonb,
    model_version text,
    inference_time_ms double precision,
    inference_id bigint,
    timestamp_utc timestamp with time zone DEFAULT now(),
    action_discretized character varying(10) DEFAULT 'HOLD'::character varying,
    confidence numeric(5,4) DEFAULT 0.5,
    price_at_inference numeric(12,4) DEFAULT 0,
    action_raw numeric(10,6) DEFAULT 0,
    model_id character varying(50) DEFAULT 'ppo_v1'::character varying
);


--
-- Name: fact_rl_inference_id_seq; Type: SEQUENCE; Schema: dw; Owner: -
--

CREATE SEQUENCE dw.fact_rl_inference_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fact_rl_inference_id_seq; Type: SEQUENCE OWNED BY; Schema: dw; Owner: -
--

ALTER SEQUENCE dw.fact_rl_inference_id_seq OWNED BY dw.fact_rl_inference.id;


--
-- Name: fact_session_performance; Type: TABLE; Schema: dw; Owner: -
--

CREATE TABLE dw.fact_session_performance (
    session_date date NOT NULL,
    total_bars integer DEFAULT 0,
    total_trades integer DEFAULT 0,
    winning_trades integer DEFAULT 0,
    losing_trades integer DEFAULT 0,
    win_rate numeric(5,4),
    profit_factor numeric(10,4),
    daily_pnl numeric(15,2) DEFAULT 0,
    daily_return_pct numeric(8,4) DEFAULT 0,
    starting_equity numeric(15,2),
    ending_equity numeric(15,2),
    max_drawdown_intraday_pct numeric(8,4),
    intraday_sharpe numeric(8,4),
    total_long_bars integer DEFAULT 0,
    total_short_bars integer DEFAULT 0,
    total_flat_bars integer DEFAULT 0,
    status character varying(20) DEFAULT 'PENDING'::character varying,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: fact_strategy_performance; Type: TABLE; Schema: dw; Owner: -
--

CREATE TABLE dw.fact_strategy_performance (
    id integer NOT NULL,
    strategy_id character varying(50) NOT NULL,
    strategy_code character varying(50) NOT NULL,
    date_cot date NOT NULL,
    as_of_date timestamp without time zone DEFAULT now(),
    daily_return numeric(10,4) DEFAULT 0,
    pnl_usd numeric(14,4) DEFAULT 0,
    gross_profit numeric(14,4) DEFAULT 0,
    gross_loss numeric(14,4) DEFAULT 0,
    net_profit numeric(14,4) DEFAULT 0,
    total_fees numeric(10,4) DEFAULT 0,
    avg_trade_pnl numeric(10,4) DEFAULT 0,
    n_trades integer DEFAULT 0,
    total_trades integer DEFAULT 0,
    n_wins integer DEFAULT 0,
    n_losses integer DEFAULT 0,
    sharpe_ratio numeric(10,4) DEFAULT 2.91,
    sortino_ratio numeric(10,4) DEFAULT 2.5,
    calmar_ratio numeric(10,4) DEFAULT 3.0,
    profit_factor numeric(10,4) DEFAULT 1.5,
    win_rate numeric(10,4) DEFAULT 0.4485,
    win_rate_pct numeric(10,4) DEFAULT 44.85,
    max_drawdown_pct numeric(10,4) DEFAULT 0.68,
    hold_pct numeric(10,4) DEFAULT 0.4,
    avg_hold_time_minutes numeric(10,2) DEFAULT 25,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: fact_strategy_performance_id_seq; Type: SEQUENCE; Schema: dw; Owner: -
--

CREATE SEQUENCE dw.fact_strategy_performance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fact_strategy_performance_id_seq; Type: SEQUENCE OWNED BY; Schema: dw; Owner: -
--

ALTER SEQUENCE dw.fact_strategy_performance_id_seq OWNED BY dw.fact_strategy_performance.id;


--
-- Name: fact_strategy_positions; Type: TABLE; Schema: dw; Owner: -
--

CREATE TABLE dw.fact_strategy_positions (
    id integer NOT NULL,
    strategy_id character varying(50) NOT NULL,
    side character varying(10) NOT NULL,
    entry_price numeric(12,4),
    entry_time timestamp with time zone,
    status character varying(20) DEFAULT 'open'::character varying,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: fact_strategy_positions_id_seq; Type: SEQUENCE; Schema: dw; Owner: -
--

CREATE SEQUENCE dw.fact_strategy_positions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fact_strategy_positions_id_seq; Type: SEQUENCE OWNED BY; Schema: dw; Owner: -
--

ALTER SEQUENCE dw.fact_strategy_positions_id_seq OWNED BY dw.fact_strategy_positions.id;


--
-- Name: model_inferences; Type: TABLE; Schema: trading; Owner: -
--

CREATE TABLE trading.model_inferences (
    inference_id bigint NOT NULL,
    timestamp_utc timestamp with time zone NOT NULL,
    model_id character varying(50) NOT NULL,
    action_raw double precision NOT NULL,
    action_discretized character varying(10) NOT NULL,
    confidence double precision,
    price_at_inference numeric(12,4) NOT NULL,
    spread_pips numeric(8,2),
    features_snapshot jsonb,
    latency_ms integer,
    preprocessing_ms integer,
    inference_ms integer,
    current_position double precision DEFAULT 0.0,
    time_normalized double precision,
    bar_number integer,
    session_id character varying(50),
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT chk_action_discretized CHECK (((action_discretized)::text = ANY ((ARRAY['LONG'::character varying, 'SHORT'::character varying, 'HOLD'::character varying, 'CLOSE'::character varying])::text[]))),
    CONSTRAINT chk_confidence CHECK (((confidence IS NULL) OR ((confidence >= (0)::double precision) AND (confidence <= (1)::double precision)))),
    CONSTRAINT chk_position CHECK (((current_position >= ('-1'::integer)::double precision) AND (current_position <= (1)::double precision)))
);


--
-- Name: TABLE model_inferences; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON TABLE trading.model_inferences IS 'Real-time inference results from all models. Partitioned by timestamp for efficient querying.';


--
-- Name: COLUMN model_inferences.inference_id; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_inferences.inference_id IS 'Auto-incrementing inference identifier';


--
-- Name: COLUMN model_inferences.timestamp_utc; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_inferences.timestamp_utc IS 'UTC timestamp of inference execution';


--
-- Name: COLUMN model_inferences.model_id; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_inferences.model_id IS 'Reference to config.models';


--
-- Name: COLUMN model_inferences.action_raw; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_inferences.action_raw IS 'Raw continuous action output from model [-1, 1]';


--
-- Name: COLUMN model_inferences.action_discretized; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_inferences.action_discretized IS 'Discretized action: LONG, SHORT, HOLD, CLOSE';


--
-- Name: COLUMN model_inferences.confidence; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_inferences.confidence IS 'Model confidence in action (0-1), derived from action magnitude or ensemble agreement';


--
-- Name: COLUMN model_inferences.price_at_inference; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_inferences.price_at_inference IS 'USD/COP price at inference time';


--
-- Name: COLUMN model_inferences.spread_pips; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_inferences.spread_pips IS 'Bid-ask spread in pips';


--
-- Name: COLUMN model_inferences.features_snapshot; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_inferences.features_snapshot IS 'JSON snapshot of all 13 features for audit and debugging';


--
-- Name: COLUMN model_inferences.latency_ms; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_inferences.latency_ms IS 'Total end-to-end latency in milliseconds';


--
-- Name: COLUMN model_inferences.preprocessing_ms; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_inferences.preprocessing_ms IS 'Feature preprocessing time in milliseconds';


--
-- Name: COLUMN model_inferences.inference_ms; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_inferences.inference_ms IS 'Model inference time in milliseconds';


--
-- Name: COLUMN model_inferences.current_position; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_inferences.current_position IS 'Position state at inference: -1 (short) to 1 (long)';


--
-- Name: COLUMN model_inferences.time_normalized; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_inferences.time_normalized IS 'Normalized time within episode (0 to ~0.983)';


--
-- Name: COLUMN model_inferences.bar_number; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_inferences.bar_number IS 'Bar number within trading session';


--
-- Name: COLUMN model_inferences.session_id; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_inferences.session_id IS 'Trading session identifier for grouping';


--
-- Name: fact_strategy_signals; Type: VIEW; Schema: dw; Owner: -
--

CREATE VIEW dw.fact_strategy_signals AS
 SELECT model_inferences.inference_id AS signal_id,
    model_inferences.model_id AS strategy_id,
    model_inferences.model_id AS strategy_code,
    model_inferences.timestamp_utc,
    model_inferences.action_discretized AS signal,
        CASE
            WHEN ((model_inferences.action_discretized)::text = 'LONG'::text) THEN 'long'::text
            WHEN ((model_inferences.action_discretized)::text = 'SHORT'::text) THEN 'short'::text
            ELSE 'flat'::text
        END AS side,
    COALESCE(model_inferences.confidence, (0.5)::double precision) AS confidence,
    1.0 AS size,
    model_inferences.price_at_inference AS entry_price,
    (model_inferences.price_at_inference * 0.995) AS stop_loss,
    (model_inferences.price_at_inference * 1.01) AS take_profit,
    100.0 AS risk_usd,
    ('Generated by '::text || (model_inferences.model_id)::text) AS reasoning,
    model_inferences.created_at
   FROM trading.model_inferences;


--
-- Name: VIEW fact_strategy_signals; Type: COMMENT; Schema: dw; Owner: -
--

COMMENT ON VIEW dw.fact_strategy_signals IS 'Compatibility view for legacy API code';


--
-- Name: v_agent_actions; Type: VIEW; Schema: dw; Owner: -
--

CREATE VIEW dw.v_agent_actions AS
 SELECT fact_agent_actions.id AS action_id,
    fact_agent_actions."timestamp" AS timestamp_cot,
    fact_agent_actions."timestamp" AS timestamp_utc,
    date(fact_agent_actions."timestamp") AS session_date,
    fact_agent_actions.bar_number,
        CASE
            WHEN (fact_agent_actions.action > (0.3)::double precision) THEN 'BUY'::text
            WHEN (fact_agent_actions.action < ('-0.3'::numeric)::double precision) THEN 'SELL'::text
            ELSE 'HOLD'::text
        END AS action_type,
        CASE
            WHEN (fact_agent_actions."position" > (0.1)::double precision) THEN 'LONG'::text
            WHEN (fact_agent_actions."position" < ('-0.1'::numeric)::double precision) THEN 'SHORT'::text
            ELSE NULL::text
        END AS side,
    0.0 AS price_at_action,
    lag(fact_agent_actions."position") OVER (ORDER BY fact_agent_actions."timestamp") AS position_before,
    fact_agent_actions."position" AS position_after,
    (fact_agent_actions."position" - COALESCE(lag(fact_agent_actions."position") OVER (ORDER BY fact_agent_actions."timestamp"), (0)::double precision)) AS position_change,
    NULL::numeric AS pnl_action,
    NULL::numeric AS pnl_daily,
    0.5 AS model_confidence,
    COALESCE(fact_agent_actions.marker_type, 'dot'::character varying) AS marker_type,
    COALESCE(fact_agent_actions.marker_color, '#888'::character varying) AS marker_color,
    fact_agent_actions.reason_code
   FROM dw.fact_agent_actions;


--
-- Name: VIEW v_agent_actions; Type: COMMENT; Schema: dw; Owner: -
--

COMMENT ON VIEW dw.v_agent_actions IS 'Compatibility view for agent actions API';


--
-- Name: signals_stream; Type: TABLE; Schema: events; Owner: -
--

CREATE TABLE events.signals_stream (
    stream_id bigint NOT NULL,
    timestamp_utc timestamp with time zone DEFAULT now() NOT NULL,
    event_type character varying(50) NOT NULL,
    event_subtype character varying(50),
    model_id character varying(50),
    source_system character varying(50) DEFAULT 'trading_system'::character varying,
    payload jsonb NOT NULL,
    price_at_event numeric(12,4),
    position_at_event double precision,
    correlation_id character varying(100),
    trace_id character varying(100),
    processed boolean DEFAULT false,
    processed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT chk_event_type CHECK (((event_type)::text = ANY ((ARRAY['INFERENCE'::character varying, 'SIGNAL'::character varying, 'TRADE_OPEN'::character varying, 'TRADE_CLOSE'::character varying, 'POSITION_CHANGE'::character varying, 'RISK_ALERT'::character varying, 'SYSTEM_EVENT'::character varying, 'MODEL_LOAD'::character varying, 'MODEL_ERROR'::character varying, 'DATA_QUALITY'::character varying, 'HEARTBEAT'::character varying])::text[])))
);


--
-- Name: TABLE signals_stream; Type: COMMENT; Schema: events; Owner: -
--

COMMENT ON TABLE events.signals_stream IS 'Immutable event stream for audit trail and real-time streaming. Supports compliance and debugging.';


--
-- Name: COLUMN signals_stream.stream_id; Type: COMMENT; Schema: events; Owner: -
--

COMMENT ON COLUMN events.signals_stream.stream_id IS 'Auto-incrementing stream identifier';


--
-- Name: COLUMN signals_stream.timestamp_utc; Type: COMMENT; Schema: events; Owner: -
--

COMMENT ON COLUMN events.signals_stream.timestamp_utc IS 'UTC timestamp of event';


--
-- Name: COLUMN signals_stream.event_type; Type: COMMENT; Schema: events; Owner: -
--

COMMENT ON COLUMN events.signals_stream.event_type IS 'Event category: INFERENCE, SIGNAL, TRADE_OPEN, TRADE_CLOSE, POSITION_CHANGE, RISK_ALERT, SYSTEM_EVENT, MODEL_LOAD, MODEL_ERROR, DATA_QUALITY, HEARTBEAT';


--
-- Name: COLUMN signals_stream.event_subtype; Type: COMMENT; Schema: events; Owner: -
--

COMMENT ON COLUMN events.signals_stream.event_subtype IS 'Event subcategory for filtering';


--
-- Name: COLUMN signals_stream.model_id; Type: COMMENT; Schema: events; Owner: -
--

COMMENT ON COLUMN events.signals_stream.model_id IS 'Associated model (if applicable)';


--
-- Name: COLUMN signals_stream.source_system; Type: COMMENT; Schema: events; Owner: -
--

COMMENT ON COLUMN events.signals_stream.source_system IS 'System that generated the event';


--
-- Name: COLUMN signals_stream.payload; Type: COMMENT; Schema: events; Owner: -
--

COMMENT ON COLUMN events.signals_stream.payload IS 'Full event payload as JSON';


--
-- Name: COLUMN signals_stream.price_at_event; Type: COMMENT; Schema: events; Owner: -
--

COMMENT ON COLUMN events.signals_stream.price_at_event IS 'USD/COP price at event time';


--
-- Name: COLUMN signals_stream.position_at_event; Type: COMMENT; Schema: events; Owner: -
--

COMMENT ON COLUMN events.signals_stream.position_at_event IS 'Position state at event time';


--
-- Name: COLUMN signals_stream.correlation_id; Type: COMMENT; Schema: events; Owner: -
--

COMMENT ON COLUMN events.signals_stream.correlation_id IS 'ID for correlating related events';


--
-- Name: COLUMN signals_stream.trace_id; Type: COMMENT; Schema: events; Owner: -
--

COMMENT ON COLUMN events.signals_stream.trace_id IS 'Distributed tracing ID';


--
-- Name: COLUMN signals_stream.processed; Type: COMMENT; Schema: events; Owner: -
--

COMMENT ON COLUMN events.signals_stream.processed IS 'Whether event has been processed by downstream systems';


--
-- Name: COLUMN signals_stream.processed_at; Type: COMMENT; Schema: events; Owner: -
--

COMMENT ON COLUMN events.signals_stream.processed_at IS 'When event was processed';


--
-- Name: signals_stream_stream_id_seq; Type: SEQUENCE; Schema: events; Owner: -
--

CREATE SEQUENCE events.signals_stream_stream_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: signals_stream_stream_id_seq; Type: SEQUENCE OWNED BY; Schema: events; Owner: -
--

ALTER SEQUENCE events.signals_stream_stream_id_seq OWNED BY events.signals_stream.stream_id;


--
-- Name: vw_recent_events; Type: VIEW; Schema: events; Owner: -
--

CREATE VIEW events.vw_recent_events AS
 SELECT e.stream_id,
    e.timestamp_utc,
    e.event_type,
    e.event_subtype,
    e.model_id,
    m.name AS model_name,
    e.price_at_event,
    e.position_at_event,
    e.payload,
    e.processed
   FROM (events.signals_stream e
     LEFT JOIN config.models m ON (((e.model_id)::text = (m.model_id)::text)))
  WHERE (e.timestamp_utc >= (now() - '24:00:00'::interval))
  ORDER BY e.timestamp_utc DESC;


--
-- Name: VIEW vw_recent_events; Type: COMMENT; Schema: events; Owner: -
--

COMMENT ON VIEW events.vw_recent_events IS 'Events from the last 24 hours for monitoring and debugging';


--
-- Name: model_performance; Type: TABLE; Schema: metrics; Owner: -
--

CREATE TABLE metrics.model_performance (
    perf_id bigint NOT NULL,
    period_start timestamp with time zone NOT NULL,
    period_end timestamp with time zone NOT NULL,
    aggregation_type character varying(20) DEFAULT 'daily'::character varying NOT NULL,
    model_id character varying(50) NOT NULL,
    pnl_cumulative numeric(12,4),
    pnl_period numeric(12,4),
    return_pct numeric(8,4),
    return_cumulative_pct numeric(10,4),
    sharpe_ratio numeric(8,4),
    sortino_ratio numeric(8,4),
    calmar_ratio numeric(8,4),
    max_drawdown numeric(8,4),
    current_drawdown numeric(8,4),
    volatility numeric(8,4),
    total_trades integer DEFAULT 0,
    winning_trades integer DEFAULT 0,
    losing_trades integer DEFAULT 0,
    win_rate numeric(5,4),
    avg_trade_pnl numeric(12,4),
    avg_win numeric(12,4),
    avg_loss numeric(12,4),
    profit_factor numeric(8,4),
    avg_position_size numeric(8,4),
    hold_percentage numeric(5,4),
    avg_trade_duration_minutes numeric(10,2),
    total_inferences integer DEFAULT 0,
    avg_latency_ms numeric(8,2),
    total_transaction_costs numeric(12,4),
    total_slippage numeric(12,4),
    starting_equity numeric(15,2),
    ending_equity numeric(15,2),
    peak_equity numeric(15,2),
    calculated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT chk_aggregation CHECK (((aggregation_type)::text = ANY ((ARRAY['hourly'::character varying, 'daily'::character varying, 'weekly'::character varying, 'monthly'::character varying])::text[]))),
    CONSTRAINT chk_hold_pct CHECK (((hold_percentage IS NULL) OR ((hold_percentage >= (0)::numeric) AND (hold_percentage <= (1)::numeric)))),
    CONSTRAINT chk_win_rate CHECK (((win_rate IS NULL) OR ((win_rate >= (0)::numeric) AND (win_rate <= (1)::numeric))))
);


--
-- Name: TABLE model_performance; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON TABLE metrics.model_performance IS 'Aggregated performance metrics per model at different time granularities (hourly, daily, weekly, monthly)';


--
-- Name: COLUMN model_performance.perf_id; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.perf_id IS 'Auto-incrementing performance record identifier';


--
-- Name: COLUMN model_performance.period_start; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.period_start IS 'Start of aggregation period';


--
-- Name: COLUMN model_performance.period_end; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.period_end IS 'End of aggregation period';


--
-- Name: COLUMN model_performance.aggregation_type; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.aggregation_type IS 'Time granularity: hourly, daily, weekly, monthly';


--
-- Name: COLUMN model_performance.model_id; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.model_id IS 'Reference to config.models';


--
-- Name: COLUMN model_performance.pnl_cumulative; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.pnl_cumulative IS 'Cumulative PnL since model inception';


--
-- Name: COLUMN model_performance.pnl_period; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.pnl_period IS 'PnL for this period';


--
-- Name: COLUMN model_performance.return_pct; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.return_pct IS 'Return percentage for this period';


--
-- Name: COLUMN model_performance.return_cumulative_pct; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.return_cumulative_pct IS 'Cumulative return percentage';


--
-- Name: COLUMN model_performance.sharpe_ratio; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.sharpe_ratio IS 'Sharpe ratio (risk-adjusted return)';


--
-- Name: COLUMN model_performance.sortino_ratio; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.sortino_ratio IS 'Sortino ratio (downside risk-adjusted return)';


--
-- Name: COLUMN model_performance.calmar_ratio; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.calmar_ratio IS 'Calmar ratio (return / max drawdown)';


--
-- Name: COLUMN model_performance.max_drawdown; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.max_drawdown IS 'Maximum drawdown as decimal (e.g., 0.05 = 5%)';


--
-- Name: COLUMN model_performance.current_drawdown; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.current_drawdown IS 'Current drawdown from peak';


--
-- Name: COLUMN model_performance.volatility; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.volatility IS 'Return volatility (standard deviation)';


--
-- Name: COLUMN model_performance.total_trades; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.total_trades IS 'Number of trades in period';


--
-- Name: COLUMN model_performance.winning_trades; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.winning_trades IS 'Number of winning trades';


--
-- Name: COLUMN model_performance.losing_trades; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.losing_trades IS 'Number of losing trades';


--
-- Name: COLUMN model_performance.win_rate; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.win_rate IS 'Win rate as decimal (0-1)';


--
-- Name: COLUMN model_performance.avg_trade_pnl; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.avg_trade_pnl IS 'Average PnL per trade';


--
-- Name: COLUMN model_performance.avg_win; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.avg_win IS 'Average winning trade PnL';


--
-- Name: COLUMN model_performance.avg_loss; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.avg_loss IS 'Average losing trade PnL';


--
-- Name: COLUMN model_performance.profit_factor; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.profit_factor IS 'Gross profit / gross loss';


--
-- Name: COLUMN model_performance.avg_position_size; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.avg_position_size IS 'Average position size (0-1)';


--
-- Name: COLUMN model_performance.hold_percentage; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.hold_percentage IS 'Percentage of time in position';


--
-- Name: COLUMN model_performance.avg_trade_duration_minutes; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.avg_trade_duration_minutes IS 'Average trade duration in minutes';


--
-- Name: COLUMN model_performance.total_inferences; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.total_inferences IS 'Total model inferences in period';


--
-- Name: COLUMN model_performance.avg_latency_ms; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.avg_latency_ms IS 'Average inference latency in milliseconds';


--
-- Name: COLUMN model_performance.total_transaction_costs; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.total_transaction_costs IS 'Total transaction costs in period';


--
-- Name: COLUMN model_performance.total_slippage; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.total_slippage IS 'Total slippage in period';


--
-- Name: COLUMN model_performance.starting_equity; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.starting_equity IS 'Equity at period start';


--
-- Name: COLUMN model_performance.ending_equity; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.ending_equity IS 'Equity at period end';


--
-- Name: COLUMN model_performance.peak_equity; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON COLUMN metrics.model_performance.peak_equity IS 'Peak equity during period';


--
-- Name: model_performance_perf_id_seq; Type: SEQUENCE; Schema: metrics; Owner: -
--

CREATE SEQUENCE metrics.model_performance_perf_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: model_performance_perf_id_seq; Type: SEQUENCE OWNED BY; Schema: metrics; Owner: -
--

ALTER SEQUENCE metrics.model_performance_perf_id_seq OWNED BY metrics.model_performance.perf_id;


--
-- Name: vw_daily_performance; Type: VIEW; Schema: metrics; Owner: -
--

CREATE VIEW metrics.vw_daily_performance AS
 SELECT p.model_id,
    m.name AS model_name,
    m.algorithm,
    m.color,
    (p.period_start)::date AS trading_date,
    p.return_pct,
    p.return_cumulative_pct,
    p.sharpe_ratio,
    p.max_drawdown,
    p.total_trades,
    p.win_rate,
    p.avg_trade_pnl,
    p.hold_percentage,
    p.ending_equity
   FROM (metrics.model_performance p
     JOIN config.models m ON (((p.model_id)::text = (m.model_id)::text)))
  WHERE ((p.aggregation_type)::text = 'daily'::text)
  ORDER BY p.period_start DESC, p.sharpe_ratio DESC;


--
-- Name: VIEW vw_daily_performance; Type: COMMENT; Schema: metrics; Owner: -
--

COMMENT ON VIEW metrics.vw_daily_performance IS 'Daily performance metrics for all models, sorted by date and Sharpe ratio';


--
-- Name: ab_permission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ab_permission (
    id integer NOT NULL,
    name character varying(100) NOT NULL
);


--
-- Name: ab_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ab_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ab_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ab_permission_id_seq OWNED BY public.ab_permission.id;


--
-- Name: ab_permission_view; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ab_permission_view (
    id integer NOT NULL,
    permission_id integer,
    view_menu_id integer
);


--
-- Name: ab_permission_view_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ab_permission_view_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ab_permission_view_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ab_permission_view_id_seq OWNED BY public.ab_permission_view.id;


--
-- Name: ab_permission_view_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ab_permission_view_role (
    id integer NOT NULL,
    permission_view_id integer,
    role_id integer
);


--
-- Name: ab_permission_view_role_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ab_permission_view_role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ab_permission_view_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ab_permission_view_role_id_seq OWNED BY public.ab_permission_view_role.id;


--
-- Name: ab_register_user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ab_register_user (
    id integer NOT NULL,
    first_name character varying(256) NOT NULL,
    last_name character varying(256) NOT NULL,
    username character varying(512) NOT NULL,
    password character varying(256),
    email character varying(512) NOT NULL,
    registration_date timestamp without time zone,
    registration_hash character varying(256)
);


--
-- Name: ab_register_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ab_register_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ab_register_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ab_register_user_id_seq OWNED BY public.ab_register_user.id;


--
-- Name: ab_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ab_role (
    id integer NOT NULL,
    name character varying(64) NOT NULL
);


--
-- Name: ab_role_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ab_role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ab_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ab_role_id_seq OWNED BY public.ab_role.id;


--
-- Name: ab_user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ab_user (
    id integer NOT NULL,
    first_name character varying(256) NOT NULL,
    last_name character varying(256) NOT NULL,
    username character varying(512) NOT NULL,
    password character varying(256),
    active boolean,
    email character varying(512) NOT NULL,
    last_login timestamp without time zone,
    login_count integer,
    fail_login_count integer,
    created_on timestamp without time zone,
    changed_on timestamp without time zone,
    created_by_fk integer,
    changed_by_fk integer
);


--
-- Name: ab_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ab_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ab_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ab_user_id_seq OWNED BY public.ab_user.id;


--
-- Name: ab_user_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ab_user_role (
    id integer NOT NULL,
    user_id integer,
    role_id integer
);


--
-- Name: ab_user_role_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ab_user_role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ab_user_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ab_user_role_id_seq OWNED BY public.ab_user_role.id;


--
-- Name: ab_view_menu; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ab_view_menu (
    id integer NOT NULL,
    name character varying(250) NOT NULL
);


--
-- Name: ab_view_menu_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ab_view_menu_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ab_view_menu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ab_view_menu_id_seq OWNED BY public.ab_view_menu.id;


--
-- Name: trading_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trading_sessions (
    id bigint NOT NULL,
    user_id integer,
    session_start timestamp with time zone NOT NULL,
    session_end timestamp with time zone,
    strategy_name text,
    initial_balance numeric(15,2),
    final_balance numeric(15,2),
    total_trades integer DEFAULT 0,
    profitable_trades integer DEFAULT 0,
    status character varying(20) DEFAULT 'active'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    first_name character varying(50),
    last_name character varying(50),
    is_active boolean DEFAULT true,
    is_admin boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_login timestamp with time zone,
    role character varying(20) DEFAULT 'user'::character varying,
    full_name character varying(100),
    avatar_url text,
    email_verified boolean DEFAULT false,
    two_factor_enabled boolean DEFAULT false,
    failed_login_attempts integer DEFAULT 0,
    locked_until timestamp with time zone,
    last_login_at timestamp with time zone
);


--
-- Name: active_sessions; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.active_sessions AS
 SELECT s.id,
    u.username,
    s.session_start,
    s.strategy_name,
    s.initial_balance,
    s.total_trades,
    s.profitable_trades,
        CASE
            WHEN (s.total_trades > 0) THEN round((((s.profitable_trades)::numeric / (s.total_trades)::numeric) * (100)::numeric), 2)
            ELSE (0)::numeric
        END AS win_rate_percent
   FROM (public.trading_sessions s
     JOIN public.users u ON ((s.user_id = u.id)))
  WHERE ((s.status)::text = 'active'::text)
  ORDER BY s.session_start DESC;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: auth_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_audit_log (
    id integer NOT NULL,
    user_id integer,
    action character varying(50) NOT NULL,
    ip_address character varying(45),
    user_agent text,
    success boolean DEFAULT true,
    error_message text,
    created_at timestamp with time zone DEFAULT now(),
    event_type character varying(50)
);


--
-- Name: auth_audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auth_audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auth_audit_log_id_seq OWNED BY public.auth_audit_log.id;


--
-- Name: callback_request; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.callback_request (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    priority_weight integer NOT NULL,
    callback_data json NOT NULL,
    callback_type character varying(20) NOT NULL,
    processor_subdir character varying(2000)
);


--
-- Name: callback_request_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.callback_request_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: callback_request_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.callback_request_id_seq OWNED BY public.callback_request.id;


--
-- Name: connection; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.connection (
    id integer NOT NULL,
    conn_id character varying(250) NOT NULL,
    conn_type character varying(500) NOT NULL,
    description text,
    host character varying(500),
    schema character varying(500),
    login text,
    password text,
    port integer,
    is_encrypted boolean,
    is_extra_encrypted boolean,
    extra text
);


--
-- Name: connection_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.connection_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: connection_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.connection_id_seq OWNED BY public.connection.id;


--
-- Name: dag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dag (
    dag_id character varying(250) NOT NULL,
    root_dag_id character varying(250),
    is_paused boolean,
    is_subdag boolean,
    is_active boolean,
    last_parsed_time timestamp with time zone,
    last_pickled timestamp with time zone,
    last_expired timestamp with time zone,
    scheduler_lock boolean,
    pickle_id integer,
    fileloc character varying(2000),
    processor_subdir character varying(2000),
    owners character varying(2000),
    description text,
    default_view character varying(25),
    schedule_interval text,
    timetable_description character varying(1000),
    max_active_tasks integer NOT NULL,
    max_active_runs integer,
    has_task_concurrency_limits boolean NOT NULL,
    has_import_errors boolean DEFAULT false,
    next_dagrun timestamp with time zone,
    next_dagrun_data_interval_start timestamp with time zone,
    next_dagrun_data_interval_end timestamp with time zone,
    next_dagrun_create_after timestamp with time zone
);


--
-- Name: dag_code; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dag_code (
    fileloc_hash bigint NOT NULL,
    fileloc character varying(2000) NOT NULL,
    last_updated timestamp with time zone NOT NULL,
    source_code text NOT NULL
);


--
-- Name: dag_owner_attributes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dag_owner_attributes (
    dag_id character varying(250) NOT NULL,
    owner character varying(500) NOT NULL,
    link character varying(500) NOT NULL
);


--
-- Name: dag_pickle; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dag_pickle (
    id integer NOT NULL,
    pickle bytea,
    created_dttm timestamp with time zone,
    pickle_hash bigint
);


--
-- Name: dag_pickle_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dag_pickle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dag_pickle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.dag_pickle_id_seq OWNED BY public.dag_pickle.id;


--
-- Name: dag_run; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dag_run (
    id integer NOT NULL,
    dag_id character varying(250) NOT NULL,
    queued_at timestamp with time zone,
    execution_date timestamp with time zone NOT NULL,
    start_date timestamp with time zone,
    end_date timestamp with time zone,
    state character varying(50),
    run_id character varying(250) NOT NULL,
    creating_job_id integer,
    external_trigger boolean,
    run_type character varying(50) NOT NULL,
    conf bytea,
    data_interval_start timestamp with time zone,
    data_interval_end timestamp with time zone,
    last_scheduling_decision timestamp with time zone,
    dag_hash character varying(32),
    log_template_id integer,
    updated_at timestamp with time zone,
    clear_number integer NOT NULL
);


--
-- Name: dag_run_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dag_run_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dag_run_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.dag_run_id_seq OWNED BY public.dag_run.id;


--
-- Name: dag_run_note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dag_run_note (
    user_id integer,
    dag_run_id integer NOT NULL,
    content character varying(1000),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: dag_schedule_dataset_reference; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dag_schedule_dataset_reference (
    dataset_id integer NOT NULL,
    dag_id character varying(250) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: dag_tag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dag_tag (
    name character varying(100) NOT NULL,
    dag_id character varying(250) NOT NULL
);


--
-- Name: dag_warning; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dag_warning (
    dag_id character varying(250) NOT NULL,
    warning_type character varying(50) NOT NULL,
    message text NOT NULL,
    "timestamp" timestamp with time zone NOT NULL
);


--
-- Name: dagrun_dataset_event; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dagrun_dataset_event (
    dag_run_id integer NOT NULL,
    event_id integer NOT NULL
);


--
-- Name: daily_ohlcv_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.daily_ohlcv_summary AS
 SELECT date(usdcop_m5_ohlcv."time") AS trading_date,
    usdcop_m5_ohlcv.symbol,
    (array_agg(usdcop_m5_ohlcv.open ORDER BY usdcop_m5_ohlcv."time"))[1] AS open_price,
    max(usdcop_m5_ohlcv.high) AS high_price,
    min(usdcop_m5_ohlcv.low) AS low_price,
    (array_agg(usdcop_m5_ohlcv.close ORDER BY usdcop_m5_ohlcv."time" DESC))[1] AS close_price,
    avg(usdcop_m5_ohlcv.close) AS avg_price,
    count(*) AS bar_count,
    sum(usdcop_m5_ohlcv.volume) AS total_volume
   FROM public.usdcop_m5_ohlcv
  GROUP BY (date(usdcop_m5_ohlcv."time")), usdcop_m5_ohlcv.symbol
  ORDER BY (date(usdcop_m5_ohlcv."time")) DESC;


--
-- Name: dataset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataset (
    id integer NOT NULL,
    uri character varying(3000) NOT NULL,
    extra json NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    is_orphaned boolean DEFAULT false NOT NULL
);


--
-- Name: dataset_dag_run_queue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataset_dag_run_queue (
    dataset_id integer NOT NULL,
    target_dag_id character varying(250) NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: dataset_event; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dataset_event (
    id integer NOT NULL,
    dataset_id integer NOT NULL,
    extra json NOT NULL,
    source_task_id character varying(250),
    source_dag_id character varying(250),
    source_run_id character varying(250),
    source_map_index integer DEFAULT '-1'::integer,
    "timestamp" timestamp with time zone NOT NULL
);


--
-- Name: dataset_event_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dataset_event_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dataset_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.dataset_event_id_seq OWNED BY public.dataset_event.id;


--
-- Name: dataset_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dataset_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dataset_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.dataset_id_seq OWNED BY public.dataset.id;


--
-- Name: equity_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.equity_snapshots (
    id integer NOT NULL,
    model_id character varying(50) NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    equity numeric(14,4) NOT NULL,
    drawdown_pct numeric(6,4),
    "position" character varying(10),
    bar_close_price numeric(12,4)
);


--
-- Name: equity_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.equity_snapshots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: equity_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.equity_snapshots_id_seq OWNED BY public.equity_snapshots.id;


--
-- Name: import_error; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_error (
    id integer NOT NULL,
    "timestamp" timestamp with time zone,
    filename character varying(1024),
    stacktrace text,
    processor_subdir character varying(2000)
);


--
-- Name: import_error_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.import_error_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: import_error_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.import_error_id_seq OWNED BY public.import_error.id;


--
-- Name: inference_features_5m; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inference_features_5m (
    "time" timestamp with time zone NOT NULL,
    log_ret_5m double precision,
    log_ret_1h double precision,
    log_ret_4h double precision,
    dxy_z double precision,
    vix_z double precision,
    embi_z double precision,
    dxy_change_1d double precision,
    brent_change_1d double precision,
    rate_spread double precision,
    rsi_9 double precision,
    atr_pct double precision,
    adx_14 double precision,
    usdmxn_change_1d double precision,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: macro_indicators_daily; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.macro_indicators_daily (
    fecha date NOT NULL,
    comm_agri_coffee_glb_d_coffee numeric(10,2),
    comm_metal_gold_glb_d_gold numeric(10,2),
    comm_oil_brent_glb_d_brent numeric(10,2),
    comm_oil_wti_glb_d_wti numeric(10,2),
    crsk_sentiment_cci_col_m_cci numeric(10,2),
    crsk_sentiment_ici_col_m_ici numeric(10,2),
    crsk_spread_embi_col_d_embi numeric(10,2),
    eqty_index_colcap_col_d_colcap numeric(12,2),
    finc_bond_yield10y_col_d_col10y numeric(6,3),
    finc_bond_yield10y_usa_d_ust10y numeric(6,3),
    finc_bond_yield2y_usa_d_dgs2 numeric(6,3),
    finc_bond_yield5y_col_d_col5y numeric(6,3),
    finc_rate_ibr_overnight_col_d_ibr numeric(6,3),
    ftrd_exports_total_col_m_expusd numeric(12,2),
    ftrd_imports_total_col_m_impusd numeric(12,2),
    ftrd_terms_trade_col_m_tot numeric(10,2),
    fxrt_index_dxy_usa_d_dxy numeric(8,4),
    fxrt_reer_bilateral_col_m_itcr numeric(10,4),
    fxrt_spot_usdclp_chl_d_usdclp numeric(10,2),
    fxrt_spot_usdmxn_mex_d_usdmxn numeric(10,4),
    gdpp_real_gdp_usa_q_gdp_q numeric(12,2),
    infl_cpi_all_usa_m_cpiaucsl numeric(10,3),
    infl_cpi_core_usa_m_cpilfesl numeric(10,3),
    infl_cpi_total_col_m_ipccol numeric(10,2),
    infl_pce_usa_m_pcepi numeric(10,3),
    labr_unemployment_usa_m_unrate numeric(6,2),
    mnys_m2_supply_usa_m_m2sl numeric(14,2),
    polr_fed_funds_usa_m_fedfunds numeric(6,3),
    polr_policy_rate_col_d_tpm numeric(6,3),
    polr_policy_rate_col_m_tpm numeric(6,3),
    polr_prime_rate_usa_d_prime numeric(6,3),
    prod_industrial_usa_m_indpro numeric(10,3),
    rsbp_current_account_col_q_cacct_q numeric(12,2),
    rsbp_fdi_inflow_col_q_fdiin_q numeric(12,2),
    rsbp_fdi_outflow_col_q_fdiout_q numeric(12,2),
    rsbp_reserves_international_col_m_resint numeric(14,2),
    sent_consumer_usa_m_umcsent numeric(8,2),
    volt_vix_usa_d_vix numeric(8,2),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    risk_embi_spread_col_d_embi double precision
);


--
-- Name: inference_macro_features; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.inference_macro_features AS
 SELECT macro_indicators_daily.fecha,
    macro_indicators_daily.fxrt_index_dxy_usa_d_dxy AS dxy,
    macro_indicators_daily.volt_vix_usa_d_vix AS vix,
    macro_indicators_daily.crsk_spread_embi_col_d_embi AS embi,
    macro_indicators_daily.fxrt_spot_usdmxn_mex_d_usdmxn AS usdmxn,
    macro_indicators_daily.comm_oil_wti_glb_d_wti AS wti,
    macro_indicators_daily.finc_bond_yield10y_usa_d_ust10y AS ust10y,
    macro_indicators_daily.polr_fed_funds_usa_m_fedfunds AS fedfunds
   FROM public.macro_indicators_daily
  ORDER BY macro_indicators_daily.fecha DESC;


--
-- Name: job; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.job (
    id integer NOT NULL,
    dag_id character varying(250),
    state character varying(20),
    job_type character varying(30),
    start_date timestamp with time zone,
    end_date timestamp with time zone,
    latest_heartbeat timestamp with time zone,
    executor_class character varying(500),
    hostname character varying(500),
    unixname character varying(1000)
);


--
-- Name: job_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.job_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: job_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.job_id_seq OWNED BY public.job.id;


--
-- Name: latest_macro; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.latest_macro AS
 SELECT macro_indicators_daily.fecha,
    macro_indicators_daily.comm_agri_coffee_glb_d_coffee,
    macro_indicators_daily.comm_metal_gold_glb_d_gold,
    macro_indicators_daily.comm_oil_brent_glb_d_brent,
    macro_indicators_daily.comm_oil_wti_glb_d_wti,
    macro_indicators_daily.crsk_sentiment_cci_col_m_cci,
    macro_indicators_daily.crsk_sentiment_ici_col_m_ici,
    macro_indicators_daily.crsk_spread_embi_col_d_embi,
    macro_indicators_daily.eqty_index_colcap_col_d_colcap,
    macro_indicators_daily.finc_bond_yield10y_col_d_col10y,
    macro_indicators_daily.finc_bond_yield10y_usa_d_ust10y,
    macro_indicators_daily.finc_bond_yield2y_usa_d_dgs2,
    macro_indicators_daily.finc_bond_yield5y_col_d_col5y,
    macro_indicators_daily.finc_rate_ibr_overnight_col_d_ibr,
    macro_indicators_daily.ftrd_exports_total_col_m_expusd,
    macro_indicators_daily.ftrd_imports_total_col_m_impusd,
    macro_indicators_daily.ftrd_terms_trade_col_m_tot,
    macro_indicators_daily.fxrt_index_dxy_usa_d_dxy,
    macro_indicators_daily.fxrt_reer_bilateral_col_m_itcr,
    macro_indicators_daily.fxrt_spot_usdclp_chl_d_usdclp,
    macro_indicators_daily.fxrt_spot_usdmxn_mex_d_usdmxn,
    macro_indicators_daily.gdpp_real_gdp_usa_q_gdp_q,
    macro_indicators_daily.infl_cpi_all_usa_m_cpiaucsl,
    macro_indicators_daily.infl_cpi_core_usa_m_cpilfesl,
    macro_indicators_daily.infl_cpi_total_col_m_ipccol,
    macro_indicators_daily.infl_pce_usa_m_pcepi,
    macro_indicators_daily.labr_unemployment_usa_m_unrate,
    macro_indicators_daily.mnys_m2_supply_usa_m_m2sl,
    macro_indicators_daily.polr_fed_funds_usa_m_fedfunds,
    macro_indicators_daily.polr_policy_rate_col_d_tpm,
    macro_indicators_daily.polr_policy_rate_col_m_tpm,
    macro_indicators_daily.polr_prime_rate_usa_d_prime,
    macro_indicators_daily.prod_industrial_usa_m_indpro,
    macro_indicators_daily.rsbp_current_account_col_q_cacct_q,
    macro_indicators_daily.rsbp_fdi_inflow_col_q_fdiin_q,
    macro_indicators_daily.rsbp_fdi_outflow_col_q_fdiout_q,
    macro_indicators_daily.rsbp_reserves_international_col_m_resint,
    macro_indicators_daily.sent_consumer_usa_m_umcsent,
    macro_indicators_daily.volt_vix_usa_d_vix,
    macro_indicators_daily.created_at,
    macro_indicators_daily.updated_at
   FROM public.macro_indicators_daily
  ORDER BY macro_indicators_daily.fecha DESC
 LIMIT 1;


--
-- Name: latest_ohlcv; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.latest_ohlcv AS
 SELECT DISTINCT ON (usdcop_m5_ohlcv.symbol) usdcop_m5_ohlcv.symbol,
    usdcop_m5_ohlcv."time" AS "timestamp",
    usdcop_m5_ohlcv.open,
    usdcop_m5_ohlcv.high,
    usdcop_m5_ohlcv.low,
    usdcop_m5_ohlcv.close,
    usdcop_m5_ohlcv.volume,
    usdcop_m5_ohlcv.source,
    usdcop_m5_ohlcv.created_at
   FROM public.usdcop_m5_ohlcv
  ORDER BY usdcop_m5_ohlcv.symbol, usdcop_m5_ohlcv."time" DESC;


--
-- Name: log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.log (
    id integer NOT NULL,
    dttm timestamp with time zone,
    dag_id character varying(250),
    task_id character varying(250),
    map_index integer,
    event character varying(30),
    execution_date timestamp with time zone,
    owner character varying(500),
    owner_display_name character varying(500),
    extra text
);


--
-- Name: log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.log_id_seq OWNED BY public.log.id;


--
-- Name: log_template; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.log_template (
    id integer NOT NULL,
    filename text NOT NULL,
    elasticsearch_id text NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: log_template_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.log_template_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: log_template_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.log_template_id_seq OWNED BY public.log_template.id;


--
-- Name: trading_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trading_metrics (
    "timestamp" timestamp with time zone NOT NULL,
    metric_name text NOT NULL,
    metric_value numeric(15,6),
    metric_type text NOT NULL,
    strategy_name text,
    model_version text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: metrics_summary; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.metrics_summary AS
 SELECT trading_metrics.strategy_name,
    trading_metrics.model_version,
    date(trading_metrics."timestamp") AS date,
    count(*) AS metric_count,
    avg(
        CASE
            WHEN (trading_metrics.metric_type = 'performance'::text) THEN trading_metrics.metric_value
            ELSE NULL::numeric
        END) AS avg_performance,
    avg(
        CASE
            WHEN (trading_metrics.metric_type = 'risk'::text) THEN trading_metrics.metric_value
            ELSE NULL::numeric
        END) AS avg_risk,
    avg(
        CASE
            WHEN (trading_metrics.metric_type = 'model_accuracy'::text) THEN trading_metrics.metric_value
            ELSE NULL::numeric
        END) AS avg_accuracy
   FROM public.trading_metrics
  WHERE (trading_metrics.strategy_name IS NOT NULL)
  GROUP BY trading_metrics.strategy_name, trading_metrics.model_version, (date(trading_metrics."timestamp"))
  ORDER BY (date(trading_metrics."timestamp")) DESC;


--
-- Name: python_features_5m; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.python_features_5m (
    "time" timestamp with time zone NOT NULL,
    rsi_9 double precision,
    atr_pct double precision,
    adx_14 double precision,
    usdmxn_ret_1h double precision,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: TABLE python_features_5m; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.python_features_5m IS 'Python-calculated features (rsi_9, atr_pct, adx_14, usdmxn_ret_1h). Updated by l1_feature_refresh DAG.';


--
-- Name: rendered_task_instance_fields; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rendered_task_instance_fields (
    dag_id character varying(250) NOT NULL,
    task_id character varying(250) NOT NULL,
    run_id character varying(250) NOT NULL,
    map_index integer DEFAULT '-1'::integer NOT NULL,
    rendered_fields json NOT NULL,
    k8s_pod_yaml json
);


--
-- Name: serialized_dag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.serialized_dag (
    dag_id character varying(250) NOT NULL,
    fileloc character varying(2000) NOT NULL,
    fileloc_hash bigint NOT NULL,
    data json,
    data_compressed bytea,
    last_updated timestamp with time zone NOT NULL,
    dag_hash character varying(32) NOT NULL,
    processor_subdir character varying(2000)
);


--
-- Name: session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session (
    id integer NOT NULL,
    session_id character varying(255),
    data bytea,
    expiry timestamp without time zone
);


--
-- Name: session_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.session_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: session_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.session_id_seq OWNED BY public.session.id;


--
-- Name: sla_miss; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sla_miss (
    task_id character varying(250) NOT NULL,
    dag_id character varying(250) NOT NULL,
    execution_date timestamp with time zone NOT NULL,
    email_sent boolean,
    "timestamp" timestamp with time zone,
    description text,
    notification_sent boolean
);


--
-- Name: slot_pool; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.slot_pool (
    id integer NOT NULL,
    pool character varying(256),
    slots integer,
    description text,
    include_deferred boolean NOT NULL
);


--
-- Name: slot_pool_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.slot_pool_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: slot_pool_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.slot_pool_id_seq OWNED BY public.slot_pool.id;


--
-- Name: task_fail; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_fail (
    id integer NOT NULL,
    task_id character varying(250) NOT NULL,
    dag_id character varying(250) NOT NULL,
    run_id character varying(250) NOT NULL,
    map_index integer DEFAULT '-1'::integer NOT NULL,
    start_date timestamp with time zone,
    end_date timestamp with time zone,
    duration integer
);


--
-- Name: task_fail_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.task_fail_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: task_fail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.task_fail_id_seq OWNED BY public.task_fail.id;


--
-- Name: task_instance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_instance (
    task_id character varying(250) NOT NULL,
    dag_id character varying(250) NOT NULL,
    run_id character varying(250) NOT NULL,
    map_index integer DEFAULT '-1'::integer NOT NULL,
    start_date timestamp with time zone,
    end_date timestamp with time zone,
    duration double precision,
    state character varying(20),
    try_number integer,
    max_tries integer DEFAULT '-1'::integer,
    hostname character varying(1000),
    unixname character varying(1000),
    job_id integer,
    pool character varying(256) NOT NULL,
    pool_slots integer NOT NULL,
    queue character varying(256),
    priority_weight integer,
    operator character varying(1000),
    custom_operator_name character varying(1000),
    queued_dttm timestamp with time zone,
    queued_by_job_id integer,
    pid integer,
    executor_config bytea,
    updated_at timestamp with time zone,
    external_executor_id character varying(250),
    trigger_id integer,
    trigger_timeout timestamp without time zone,
    next_method character varying(1000),
    next_kwargs json
);


--
-- Name: task_instance_note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_instance_note (
    user_id integer,
    task_id character varying(250) NOT NULL,
    dag_id character varying(250) NOT NULL,
    run_id character varying(250) NOT NULL,
    map_index integer NOT NULL,
    content character varying(1000),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: task_map; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_map (
    dag_id character varying(250) NOT NULL,
    task_id character varying(250) NOT NULL,
    run_id character varying(250) NOT NULL,
    map_index integer NOT NULL,
    length integer NOT NULL,
    keys json,
    CONSTRAINT ck_task_map_task_map_length_not_negative CHECK ((length >= 0))
);


--
-- Name: task_outlet_dataset_reference; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_outlet_dataset_reference (
    dataset_id integer NOT NULL,
    dag_id character varying(250) NOT NULL,
    task_id character varying(250) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: task_reschedule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_reschedule (
    id integer NOT NULL,
    task_id character varying(250) NOT NULL,
    dag_id character varying(250) NOT NULL,
    run_id character varying(250) NOT NULL,
    map_index integer DEFAULT '-1'::integer NOT NULL,
    try_number integer NOT NULL,
    start_date timestamp with time zone NOT NULL,
    end_date timestamp with time zone NOT NULL,
    duration integer NOT NULL,
    reschedule_date timestamp with time zone NOT NULL
);


--
-- Name: task_reschedule_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.task_reschedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: task_reschedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.task_reschedule_id_seq OWNED BY public.task_reschedule.id;


--
-- Name: trades_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trades_history (
    id integer NOT NULL,
    model_id character varying(50) NOT NULL,
    side character varying(10) NOT NULL,
    entry_price numeric(12,4) NOT NULL,
    exit_price numeric(12,4),
    entry_time timestamp with time zone NOT NULL,
    exit_time timestamp with time zone,
    duration_bars integer,
    pnl_usd numeric(12,4),
    pnl_pct numeric(8,4),
    exit_reason character varying(20),
    equity_at_entry numeric(14,4),
    equity_at_exit numeric(14,4),
    drawdown_at_entry numeric(6,4),
    bar_number integer,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT trades_history_side_check CHECK (((side)::text = ANY ((ARRAY['LONG'::character varying, 'SHORT'::character varying])::text[])))
);


--
-- Name: trades_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.trades_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: trades_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.trades_history_id_seq OWNED BY public.trades_history.id;


--
-- Name: trading_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.trading_sessions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: trading_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.trading_sessions_id_seq OWNED BY public.trading_sessions.id;


--
-- Name: trading_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trading_state (
    id integer NOT NULL,
    model_id character varying(50) NOT NULL,
    "position" character varying(10) DEFAULT 'FLAT'::character varying,
    entry_price numeric(12,4),
    entry_time timestamp with time zone,
    bars_in_position integer DEFAULT 0,
    unrealized_pnl numeric(12,4) DEFAULT 0,
    realized_pnl numeric(12,4) DEFAULT 0,
    equity numeric(14,4) DEFAULT 10000,
    peak_equity numeric(14,4) DEFAULT 10000,
    drawdown_pct numeric(6,4) DEFAULT 0,
    trade_count integer DEFAULT 0,
    winning_trades integer DEFAULT 0,
    losing_trades integer DEFAULT 0,
    last_signal character varying(10),
    last_updated timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT trading_state_position_check CHECK ((("position")::text = ANY ((ARRAY['LONG'::character varying, 'SHORT'::character varying, 'FLAT'::character varying])::text[])))
);


--
-- Name: trading_state_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.trading_state_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: trading_state_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.trading_state_id_seq OWNED BY public.trading_state.id;


--
-- Name: trigger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trigger (
    id integer NOT NULL,
    classpath character varying(1000) NOT NULL,
    kwargs json NOT NULL,
    created_date timestamp with time zone NOT NULL,
    triggerer_id integer
);


--
-- Name: trigger_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.trigger_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: trigger_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.trigger_id_seq OWNED BY public.trigger.id;


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: variable; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.variable (
    id integer NOT NULL,
    key character varying(250),
    val text,
    description text,
    is_encrypted boolean
);


--
-- Name: variable_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.variable_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: variable_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.variable_id_seq OWNED BY public.variable.id;


--
-- Name: xcom; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.xcom (
    dag_run_id integer NOT NULL,
    task_id character varying(250) NOT NULL,
    map_index integer DEFAULT '-1'::integer NOT NULL,
    key character varying(512) NOT NULL,
    dag_id character varying(250) NOT NULL,
    run_id character varying(250) NOT NULL,
    value bytea,
    "timestamp" timestamp with time zone NOT NULL
);


--
-- Name: model_inferences_inference_id_seq; Type: SEQUENCE; Schema: trading; Owner: -
--

CREATE SEQUENCE trading.model_inferences_inference_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: model_inferences_inference_id_seq; Type: SEQUENCE OWNED BY; Schema: trading; Owner: -
--

ALTER SEQUENCE trading.model_inferences_inference_id_seq OWNED BY trading.model_inferences.inference_id;


--
-- Name: model_states; Type: TABLE; Schema: trading; Owner: -
--

CREATE TABLE trading.model_states (
    model_id character varying(100) NOT NULL,
    "position" numeric(5,4) DEFAULT 0,
    position_bars integer DEFAULT 0,
    entry_price numeric(12,4) DEFAULT 0,
    unrealized_pnl numeric(12,6) DEFAULT 0,
    realized_pnl numeric(12,6) DEFAULT 0,
    cumulative_return numeric(12,6) DEFAULT 0,
    peak_equity numeric(15,4) DEFAULT 10000,
    current_equity numeric(15,4) DEFAULT 10000,
    current_drawdown numeric(10,6) DEFAULT 0,
    max_drawdown_session numeric(10,6) DEFAULT 0,
    trade_count_session integer DEFAULT 0,
    session_start_time timestamp with time zone,
    last_update_time timestamp with time zone DEFAULT now()
);


--
-- Name: model_trades; Type: TABLE; Schema: trading; Owner: -
--

CREATE TABLE trading.model_trades (
    trade_id bigint NOT NULL,
    model_id character varying(50) NOT NULL,
    open_time timestamp with time zone NOT NULL,
    close_time timestamp with time zone,
    signal character varying(10) NOT NULL,
    entry_price numeric(12,4) NOT NULL,
    exit_price numeric(12,4),
    position_size numeric(8,4) DEFAULT 1.0 NOT NULL,
    pnl numeric(12,4),
    pnl_pct numeric(12,6),
    gross_pnl numeric(12,4),
    duration_minutes integer,
    duration_bars integer,
    status character varying(20) DEFAULT 'open'::character varying,
    exit_reason character varying(50),
    entry_confidence numeric(4,3),
    exit_confidence numeric(4,3),
    max_adverse_excursion numeric(12,4),
    max_favorable_excursion numeric(12,4),
    transaction_costs numeric(8,4),
    spread_cost numeric(8,4),
    slippage numeric(8,4),
    entry_inference_id bigint,
    exit_inference_id bigint,
    notes text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT chk_exit_reason CHECK (((exit_reason IS NULL) OR ((exit_reason)::text = ANY ((ARRAY['signal'::character varying, 'stop_loss'::character varying, 'take_profit'::character varying, 'timeout'::character varying, 'manual'::character varying, 'system'::character varying, 'end_of_session'::character varying])::text[])))),
    CONSTRAINT chk_position_size CHECK (((position_size > (0)::numeric) AND (position_size <= (1)::numeric))),
    CONSTRAINT chk_trade_signal CHECK (((signal)::text = ANY ((ARRAY['LONG'::character varying, 'SHORT'::character varying])::text[]))),
    CONSTRAINT chk_trade_status CHECK (((status)::text = ANY ((ARRAY['open'::character varying, 'closed'::character varying, 'cancelled'::character varying, 'stopped'::character varying, 'expired'::character varying])::text[])))
);


--
-- Name: TABLE model_trades; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON TABLE trading.model_trades IS 'Completed and open trades for each model with full PnL tracking and cost accounting';


--
-- Name: COLUMN model_trades.trade_id; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_trades.trade_id IS 'Unique trade identifier';


--
-- Name: COLUMN model_trades.model_id; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_trades.model_id IS 'Reference to config.models';


--
-- Name: COLUMN model_trades.open_time; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_trades.open_time IS 'UTC timestamp when trade was opened';


--
-- Name: COLUMN model_trades.close_time; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_trades.close_time IS 'UTC timestamp when trade was closed (NULL if open)';


--
-- Name: COLUMN model_trades.signal; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_trades.signal IS 'Trade direction: LONG or SHORT';


--
-- Name: COLUMN model_trades.entry_price; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_trades.entry_price IS 'Price at trade entry';


--
-- Name: COLUMN model_trades.exit_price; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_trades.exit_price IS 'Price at trade exit (NULL if open)';


--
-- Name: COLUMN model_trades.position_size; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_trades.position_size IS 'Position size as fraction of capital (0-1)';


--
-- Name: COLUMN model_trades.pnl; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_trades.pnl IS 'Net profit/loss in USD after costs';


--
-- Name: COLUMN model_trades.pnl_pct; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_trades.pnl_pct IS 'Net profit/loss as percentage';


--
-- Name: COLUMN model_trades.gross_pnl; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_trades.gross_pnl IS 'Gross profit/loss before costs';


--
-- Name: COLUMN model_trades.duration_minutes; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_trades.duration_minutes IS 'Trade duration in minutes';


--
-- Name: COLUMN model_trades.duration_bars; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_trades.duration_bars IS 'Trade duration in 5-minute bars';


--
-- Name: COLUMN model_trades.status; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_trades.status IS 'Trade status: open, closed, cancelled, stopped, expired';


--
-- Name: COLUMN model_trades.exit_reason; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_trades.exit_reason IS 'Reason for exit: signal, stop_loss, take_profit, timeout, manual, system, end_of_session';


--
-- Name: COLUMN model_trades.entry_confidence; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_trades.entry_confidence IS 'Model confidence at entry (0-1)';


--
-- Name: COLUMN model_trades.exit_confidence; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_trades.exit_confidence IS 'Model confidence at exit (0-1)';


--
-- Name: COLUMN model_trades.max_adverse_excursion; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_trades.max_adverse_excursion IS 'Maximum adverse price movement during trade (MAE)';


--
-- Name: COLUMN model_trades.max_favorable_excursion; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_trades.max_favorable_excursion IS 'Maximum favorable price movement during trade (MFE)';


--
-- Name: COLUMN model_trades.transaction_costs; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_trades.transaction_costs IS 'Total transaction costs in pesos';


--
-- Name: COLUMN model_trades.spread_cost; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_trades.spread_cost IS 'Cost due to bid-ask spread';


--
-- Name: COLUMN model_trades.slippage; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON COLUMN trading.model_trades.slippage IS 'Cost due to slippage';


--
-- Name: model_trades_trade_id_seq; Type: SEQUENCE; Schema: trading; Owner: -
--

CREATE SEQUENCE trading.model_trades_trade_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: model_trades_trade_id_seq; Type: SEQUENCE OWNED BY; Schema: trading; Owner: -
--

ALTER SEQUENCE trading.model_trades_trade_id_seq OWNED BY trading.model_trades.trade_id;


--
-- Name: vw_latest_signals; Type: VIEW; Schema: trading; Owner: -
--

CREATE VIEW trading.vw_latest_signals AS
 SELECT DISTINCT ON (i.model_id) i.model_id,
    m.name AS model_name,
    m.algorithm,
    m.color,
    i.timestamp_utc,
    i.action_discretized AS signal,
    i.action_raw,
    i.confidence,
    i.price_at_inference,
    i.current_position,
    i.latency_ms,
    i.bar_number
   FROM (trading.model_inferences i
     JOIN config.models m ON (((i.model_id)::text = (m.model_id)::text)))
  WHERE ((m.status)::text = 'active'::text)
  ORDER BY i.model_id, i.timestamp_utc DESC;


--
-- Name: VIEW vw_latest_signals; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON VIEW trading.vw_latest_signals IS 'Latest inference signal for each active model';


--
-- Name: vw_open_trades; Type: VIEW; Schema: trading; Owner: -
--

CREATE VIEW trading.vw_open_trades AS
 SELECT t.trade_id,
    t.model_id,
    m.name AS model_name,
    t.signal,
    t.open_time,
    t.entry_price,
    t.position_size,
    t.entry_confidence,
    (EXTRACT(epoch FROM (now() - t.open_time)) / (60)::numeric) AS minutes_open,
    t.max_favorable_excursion,
    t.max_adverse_excursion
   FROM (trading.model_trades t
     JOIN config.models m ON (((t.model_id)::text = (m.model_id)::text)))
  WHERE ((t.status)::text = 'open'::text)
  ORDER BY t.open_time DESC;


--
-- Name: VIEW vw_open_trades; Type: COMMENT; Schema: trading; Owner: -
--

COMMENT ON VIEW trading.vw_open_trades IS 'Currently open trades across all models';


--
-- Name: _hyper_1_100_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_100_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_100_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_100_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_100_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_100_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_100_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_100_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_100_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_100_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_101_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_101_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_101_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_101_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_101_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_101_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_101_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_101_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_101_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_101_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_102_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_102_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_102_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_102_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_102_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_102_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_102_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_102_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_102_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_102_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_103_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_103_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_103_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_103_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_103_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_103_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_103_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_103_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_103_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_103_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_104_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_104_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_104_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_104_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_104_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_104_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_104_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_104_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_104_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_104_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_105_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_105_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_105_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_105_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_105_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_105_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_105_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_105_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_105_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_105_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_106_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_106_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_106_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_106_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_106_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_106_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_106_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_106_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_106_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_106_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_107_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_107_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_107_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_107_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_107_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_107_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_107_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_107_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_107_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_107_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_108_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_108_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_108_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_108_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_108_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_108_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_108_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_108_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_108_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_108_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_109_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_109_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_109_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_109_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_109_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_109_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_109_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_109_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_109_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_109_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_10_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_10_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_10_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_10_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_10_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_10_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_10_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_10_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_10_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_10_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_110_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_110_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_110_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_110_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_110_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_110_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_110_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_110_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_110_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_110_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_111_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_111_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_111_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_111_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_111_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_111_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_111_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_111_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_111_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_111_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_112_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_112_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_112_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_112_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_112_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_112_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_112_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_112_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_112_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_112_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_113_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_113_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_113_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_113_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_113_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_113_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_113_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_113_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_113_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_113_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_114_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_114_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_114_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_114_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_114_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_114_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_114_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_114_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_114_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_114_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_115_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_115_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_115_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_115_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_115_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_115_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_115_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_115_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_115_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_115_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_116_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_116_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_116_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_116_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_116_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_116_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_116_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_116_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_116_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_116_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_117_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_117_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_117_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_117_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_117_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_117_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_117_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_117_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_117_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_117_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_118_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_118_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_118_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_118_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_118_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_118_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_118_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_118_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_118_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_118_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_119_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_119_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_119_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_119_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_119_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_119_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_119_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_119_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_119_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_119_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_11_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_11_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_11_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_11_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_11_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_11_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_11_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_11_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_11_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_11_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_120_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_120_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_120_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_120_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_120_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_120_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_120_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_120_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_120_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_120_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_121_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_121_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_121_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_121_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_121_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_121_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_121_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_121_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_121_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_121_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_122_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_122_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_122_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_122_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_122_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_122_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_122_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_122_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_122_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_122_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_123_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_123_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_123_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_123_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_123_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_123_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_123_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_123_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_123_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_123_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_124_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_124_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_124_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_124_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_124_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_124_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_124_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_124_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_124_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_124_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_125_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_125_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_125_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_125_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_125_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_125_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_125_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_125_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_125_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_125_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_126_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_126_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_126_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_126_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_126_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_126_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_126_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_126_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_126_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_126_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_127_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_127_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_127_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_127_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_127_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_127_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_127_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_127_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_127_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_127_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_128_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_128_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_128_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_128_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_128_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_128_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_128_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_128_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_128_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_128_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_129_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_129_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_129_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_129_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_129_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_129_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_129_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_129_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_129_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_129_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_12_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_12_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_12_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_12_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_12_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_12_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_12_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_12_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_12_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_12_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_130_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_130_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_130_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_130_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_130_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_130_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_130_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_130_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_130_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_130_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_131_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_131_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_131_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_131_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_131_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_131_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_131_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_131_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_131_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_131_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_132_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_132_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_132_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_132_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_132_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_132_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_132_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_132_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_132_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_132_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_133_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_133_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_133_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_133_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_133_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_133_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_133_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_133_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_133_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_133_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_134_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_134_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_134_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_134_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_134_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_134_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_134_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_134_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_134_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_134_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_135_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_135_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_135_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_135_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_135_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_135_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_135_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_135_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_135_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_135_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_136_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_136_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_136_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_136_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_136_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_136_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_136_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_136_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_136_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_136_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_137_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_137_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_137_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_137_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_137_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_137_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_137_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_137_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_137_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_137_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_138_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_138_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_138_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_138_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_138_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_138_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_138_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_138_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_138_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_138_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_139_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_139_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_139_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_139_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_139_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_139_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_139_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_139_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_139_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_139_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_13_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_13_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_13_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_13_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_13_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_13_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_13_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_13_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_13_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_13_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_140_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_140_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_140_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_140_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_140_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_140_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_140_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_140_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_140_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_140_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_141_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_141_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_141_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_141_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_141_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_141_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_141_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_141_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_141_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_141_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_142_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_142_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_142_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_142_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_142_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_142_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_142_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_142_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_142_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_142_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_143_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_143_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_143_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_143_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_143_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_143_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_143_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_143_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_143_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_143_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_144_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_144_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_144_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_144_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_144_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_144_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_144_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_144_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_144_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_144_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_145_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_145_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_145_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_145_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_145_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_145_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_145_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_145_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_145_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_145_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_146_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_146_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_146_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_146_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_146_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_146_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_146_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_146_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_146_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_146_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_147_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_147_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_147_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_147_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_147_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_147_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_147_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_147_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_147_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_147_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_148_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_148_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_148_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_148_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_148_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_148_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_148_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_148_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_148_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_148_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_149_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_149_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_149_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_149_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_149_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_149_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_149_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_149_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_149_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_149_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_14_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_14_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_14_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_14_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_14_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_14_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_14_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_14_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_14_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_14_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_150_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_150_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_150_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_150_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_150_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_150_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_150_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_150_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_150_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_150_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_151_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_151_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_151_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_151_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_151_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_151_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_151_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_151_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_151_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_151_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_152_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_152_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_152_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_152_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_152_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_152_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_152_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_152_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_152_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_152_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_153_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_153_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_153_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_153_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_153_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_153_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_153_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_153_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_153_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_153_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_154_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_154_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_154_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_154_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_154_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_154_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_154_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_154_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_154_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_154_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_155_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_155_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_155_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_155_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_155_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_155_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_155_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_155_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_155_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_155_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_156_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_156_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_156_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_156_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_156_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_156_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_156_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_156_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_156_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_156_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_157_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_157_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_157_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_157_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_157_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_157_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_157_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_157_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_157_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_157_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_158_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_158_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_158_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_158_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_158_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_158_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_158_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_158_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_158_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_158_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_159_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_159_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_159_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_159_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_159_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_159_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_159_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_159_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_159_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_159_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_15_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_15_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_15_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_15_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_15_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_15_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_15_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_15_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_15_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_15_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_160_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_160_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_160_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_160_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_160_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_160_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_160_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_160_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_160_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_160_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_161_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_161_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_161_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_161_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_161_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_161_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_161_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_161_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_161_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_161_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_162_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_162_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_162_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_162_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_162_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_162_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_162_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_162_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_162_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_162_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_163_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_163_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_163_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_163_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_163_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_163_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_163_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_163_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_163_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_163_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_164_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_164_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_164_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_164_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_164_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_164_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_164_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_164_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_164_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_164_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_165_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_165_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_165_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_165_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_165_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_165_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_165_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_165_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_165_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_165_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_166_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_166_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_166_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_166_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_166_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_166_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_166_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_166_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_166_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_166_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_167_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_167_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_167_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_167_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_167_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_167_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_167_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_167_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_167_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_167_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_168_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_168_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_168_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_168_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_168_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_168_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_168_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_168_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_168_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_168_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_169_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_169_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_169_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_169_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_169_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_169_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_169_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_169_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_169_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_169_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_16_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_16_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_16_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_16_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_16_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_16_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_16_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_16_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_16_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_16_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_170_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_170_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_170_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_170_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_170_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_170_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_170_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_170_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_170_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_170_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_171_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_171_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_171_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_171_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_171_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_171_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_171_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_171_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_171_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_171_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_172_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_172_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_172_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_172_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_172_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_172_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_172_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_172_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_172_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_172_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_173_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_173_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_173_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_173_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_173_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_173_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_173_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_173_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_173_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_173_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_174_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_174_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_174_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_174_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_174_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_174_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_174_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_174_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_174_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_174_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_175_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_175_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_175_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_175_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_175_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_175_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_175_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_175_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_175_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_175_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_176_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_176_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_176_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_176_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_176_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_176_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_176_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_176_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_176_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_176_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_177_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_177_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_177_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_177_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_177_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_177_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_177_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_177_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_177_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_177_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_178_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_178_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_178_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_178_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_178_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_178_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_178_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_178_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_178_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_178_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_179_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_179_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_179_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_179_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_179_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_179_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_179_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_179_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_179_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_179_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_17_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_17_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_17_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_17_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_17_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_17_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_17_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_17_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_17_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_17_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_180_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_180_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_180_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_180_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_180_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_180_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_180_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_180_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_180_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_180_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_181_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_181_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_181_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_181_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_181_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_181_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_181_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_181_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_181_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_181_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_182_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_182_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_182_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_182_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_182_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_182_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_182_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_182_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_182_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_182_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_183_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_183_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_183_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_183_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_183_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_183_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_183_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_183_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_183_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_183_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_184_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_184_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_184_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_184_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_184_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_184_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_184_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_184_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_184_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_184_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_185_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_185_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_185_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_185_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_185_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_185_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_185_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_185_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_185_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_185_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_186_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_186_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_186_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_186_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_186_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_186_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_186_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_186_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_186_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_186_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_187_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_187_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_187_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_187_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_187_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_187_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_187_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_187_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_187_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_187_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_188_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_188_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_188_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_188_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_188_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_188_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_188_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_188_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_188_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_188_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_189_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_189_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_189_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_189_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_189_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_189_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_189_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_189_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_189_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_189_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_18_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_18_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_18_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_18_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_18_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_18_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_18_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_18_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_18_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_18_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_190_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_190_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_190_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_190_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_190_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_190_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_190_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_190_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_190_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_190_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_191_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_191_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_191_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_191_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_191_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_191_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_191_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_191_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_191_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_191_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_192_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_192_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_192_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_192_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_192_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_192_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_192_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_192_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_192_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_192_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_193_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_193_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_193_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_193_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_193_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_193_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_193_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_193_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_193_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_193_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_194_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_194_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_194_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_194_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_194_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_194_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_194_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_194_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_194_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_194_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_195_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_195_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_195_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_195_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_195_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_195_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_195_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_195_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_195_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_195_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_196_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_196_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_196_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_196_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_196_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_196_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_196_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_196_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_196_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_196_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_197_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_197_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_197_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_197_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_197_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_197_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_197_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_197_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_197_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_197_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_198_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_198_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_198_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_198_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_198_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_198_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_198_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_198_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_198_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_198_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_199_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_199_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_199_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_199_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_199_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_199_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_199_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_199_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_199_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_199_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_19_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_19_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_19_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_19_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_19_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_19_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_19_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_19_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_19_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_19_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_200_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_200_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_200_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_200_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_200_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_200_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_200_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_200_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_200_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_200_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_201_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_201_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_201_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_201_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_201_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_201_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_201_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_201_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_201_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_201_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_202_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_202_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_202_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_202_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_202_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_202_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_202_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_202_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_202_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_202_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_203_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_203_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_203_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_203_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_203_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_203_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_203_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_203_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_203_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_203_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_204_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_204_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_204_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_204_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_204_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_204_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_204_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_204_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_204_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_204_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_205_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_205_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_205_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_205_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_205_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_205_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_205_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_205_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_205_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_205_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_206_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_206_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_206_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_206_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_206_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_206_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_206_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_206_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_206_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_206_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_207_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_207_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_207_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_207_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_207_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_207_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_207_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_207_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_207_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_207_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_208_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_208_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_208_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_208_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_208_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_208_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_208_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_208_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_208_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_208_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_209_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_209_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_209_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_209_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_209_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_209_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_209_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_209_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_209_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_209_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_20_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_20_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_20_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_20_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_20_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_20_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_20_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_20_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_20_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_20_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_210_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_210_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_210_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_210_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_210_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_210_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_210_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_210_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_210_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_210_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_211_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_211_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_211_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_211_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_211_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_211_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_211_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_211_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_211_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_211_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_212_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_212_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_212_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_212_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_212_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_212_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_212_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_212_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_212_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_212_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_213_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_213_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_213_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_213_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_213_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_213_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_213_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_213_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_213_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_213_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_214_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_214_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_214_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_214_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_214_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_214_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_214_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_214_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_214_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_214_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_215_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_215_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_215_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_215_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_215_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_215_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_215_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_215_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_215_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_215_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_216_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_216_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_216_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_216_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_216_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_216_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_216_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_216_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_216_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_216_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_217_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_217_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_217_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_217_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_217_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_217_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_217_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_217_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_217_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_217_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_218_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_218_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_218_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_218_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_218_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_218_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_218_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_218_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_218_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_218_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_219_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_219_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_219_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_219_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_219_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_219_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_219_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_219_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_219_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_219_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_21_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_21_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_21_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_21_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_21_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_21_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_21_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_21_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_21_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_21_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_220_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_220_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_220_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_220_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_220_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_220_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_220_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_220_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_220_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_220_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_221_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_221_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_221_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_221_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_221_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_221_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_221_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_221_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_221_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_221_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_222_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_222_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_222_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_222_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_222_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_222_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_222_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_222_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_222_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_222_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_223_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_223_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_223_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_223_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_223_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_223_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_223_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_223_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_223_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_223_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_224_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_224_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_224_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_224_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_224_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_224_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_224_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_224_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_224_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_224_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_225_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_225_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_225_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_225_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_225_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_225_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_225_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_225_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_225_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_225_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_226_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_226_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_226_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_226_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_226_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_226_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_226_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_226_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_226_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_226_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_227_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_227_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_227_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_227_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_227_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_227_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_227_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_227_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_227_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_227_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_228_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_228_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_228_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_228_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_228_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_228_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_228_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_228_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_228_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_228_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_229_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_229_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_229_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_229_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_229_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_229_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_229_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_229_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_229_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_229_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_22_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_22_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_22_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_22_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_22_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_22_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_22_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_22_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_22_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_22_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_230_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_230_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_230_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_230_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_230_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_230_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_230_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_230_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_230_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_230_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_231_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_231_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_231_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_231_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_231_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_231_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_231_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_231_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_231_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_231_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_232_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_232_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_232_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_232_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_232_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_232_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_232_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_232_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_232_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_232_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_233_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_233_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_233_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_233_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_233_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_233_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_233_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_233_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_233_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_233_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_234_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_234_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_234_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_234_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_234_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_234_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_234_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_234_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_234_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_234_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_235_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_235_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_235_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_235_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_235_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_235_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_235_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_235_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_235_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_235_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_236_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_236_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_236_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_236_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_236_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_236_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_236_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_236_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_236_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_236_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_237_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_237_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_237_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_237_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_237_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_237_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_237_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_237_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_237_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_237_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_238_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_238_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_238_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_238_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_238_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_238_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_238_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_238_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_238_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_238_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_239_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_239_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_239_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_239_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_239_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_239_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_239_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_239_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_239_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_239_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_23_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_23_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_23_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_23_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_23_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_23_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_23_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_23_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_23_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_23_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_240_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_240_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_240_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_240_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_240_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_240_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_240_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_240_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_240_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_240_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_241_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_241_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_241_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_241_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_241_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_241_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_241_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_241_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_241_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_241_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_242_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_242_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_242_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_242_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_242_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_242_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_242_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_242_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_242_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_242_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_243_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_243_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_243_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_243_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_243_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_243_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_243_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_243_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_243_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_243_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_244_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_244_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_244_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_244_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_244_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_244_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_244_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_244_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_244_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_244_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_245_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_245_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_245_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_245_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_245_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_245_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_245_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_245_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_245_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_245_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_246_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_246_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_246_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_246_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_246_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_246_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_246_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_246_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_246_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_246_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_247_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_247_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_247_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_247_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_247_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_247_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_247_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_247_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_247_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_247_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_248_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_248_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_248_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_248_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_248_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_248_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_248_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_248_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_248_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_248_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_249_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_249_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_249_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_249_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_249_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_249_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_249_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_249_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_249_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_249_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_24_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_24_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_24_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_24_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_24_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_24_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_24_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_24_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_24_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_24_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_250_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_250_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_250_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_250_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_250_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_250_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_250_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_250_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_250_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_250_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_251_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_251_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_251_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_251_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_251_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_251_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_251_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_251_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_251_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_251_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_252_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_252_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_252_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_252_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_252_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_252_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_252_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_252_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_252_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_252_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_253_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_253_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_253_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_253_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_253_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_253_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_253_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_253_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_253_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_253_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_254_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_254_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_254_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_254_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_254_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_254_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_254_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_254_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_254_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_254_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_255_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_255_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_255_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_255_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_255_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_255_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_255_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_255_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_255_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_255_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_256_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_256_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_256_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_256_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_256_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_256_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_256_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_256_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_256_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_256_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_257_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_257_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_257_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_257_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_257_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_257_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_257_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_257_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_257_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_257_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_258_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_258_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_258_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_258_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_258_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_258_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_258_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_258_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_258_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_258_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_259_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_259_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_259_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_259_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_259_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_259_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_259_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_259_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_259_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_259_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_25_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_25_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_25_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_25_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_25_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_25_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_25_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_25_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_25_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_25_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_260_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_260_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_260_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_260_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_260_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_260_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_260_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_260_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_260_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_260_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_261_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_261_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_261_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_261_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_261_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_261_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_261_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_261_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_261_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_261_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_262_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_262_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_262_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_262_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_262_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_262_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_262_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_262_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_262_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_262_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_263_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_263_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_263_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_263_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_263_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_263_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_263_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_263_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_263_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_263_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_264_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_264_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_264_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_264_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_264_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_264_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_264_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_264_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_264_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_264_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_265_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_265_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_265_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_265_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_265_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_265_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_265_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_265_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_265_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_265_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_266_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_266_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_266_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_266_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_266_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_266_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_266_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_266_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_266_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_266_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_267_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_267_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_267_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_267_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_267_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_267_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_267_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_267_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_267_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_267_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_268_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_268_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_268_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_268_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_268_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_268_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_268_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_268_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_268_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_268_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_269_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_269_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_269_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_269_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_269_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_269_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_269_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_269_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_269_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_269_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_26_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_26_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_26_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_26_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_26_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_26_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_26_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_26_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_26_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_26_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_270_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_270_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_270_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_270_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_270_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_270_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_270_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_270_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_270_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_270_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_271_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_271_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_271_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_271_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_271_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_271_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_271_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_271_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_271_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_271_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_272_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_272_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_272_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_272_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_272_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_272_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_272_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_272_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_272_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_272_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_273_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_273_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_273_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_273_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_273_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_273_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_273_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_273_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_273_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_273_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_274_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_274_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_274_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_274_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_274_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_274_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_274_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_274_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_274_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_274_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_275_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_275_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_275_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_275_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_275_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_275_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_275_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_275_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_275_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_275_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_276_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_276_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_276_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_276_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_276_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_276_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_276_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_276_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_276_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_276_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_277_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_277_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_277_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_277_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_277_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_277_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_277_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_277_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_277_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_277_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_278_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_278_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_278_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_278_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_278_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_278_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_278_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_278_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_278_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_278_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_279_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_279_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_279_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_279_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_279_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_279_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_279_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_279_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_279_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_279_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_27_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_27_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_27_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_27_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_27_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_27_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_27_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_27_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_27_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_27_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_280_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_280_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_280_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_280_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_280_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_280_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_280_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_280_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_280_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_280_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_281_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_281_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_281_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_281_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_281_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_281_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_281_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_281_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_281_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_281_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_282_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_282_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_282_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_282_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_282_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_282_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_282_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_282_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_282_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_282_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_283_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_283_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_283_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_283_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_283_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_283_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_283_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_283_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_283_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_283_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_284_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_284_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_284_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_284_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_284_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_284_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_284_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_284_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_284_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_284_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_285_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_285_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_285_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_285_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_285_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_285_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_285_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_285_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_285_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_285_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_286_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_286_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_286_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_286_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_286_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_286_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_286_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_286_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_286_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_286_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_287_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_287_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_287_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_287_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_287_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_287_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_287_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_287_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_287_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_287_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_288_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_288_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_288_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_288_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_288_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_288_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_288_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_288_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_288_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_288_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_289_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_289_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_289_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_289_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_289_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_289_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_289_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_289_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_289_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_289_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_28_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_28_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_28_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_28_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_28_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_28_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_28_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_28_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_28_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_28_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_290_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_290_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_290_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_290_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_290_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_290_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_290_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_290_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_290_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_290_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_291_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_291_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_291_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_291_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_291_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_291_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_291_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_291_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_291_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_291_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_292_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_292_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_292_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_292_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_292_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_292_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_292_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_292_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_292_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_292_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_293_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_293_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_293_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_293_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_293_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_293_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_293_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_293_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_293_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_293_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_294_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_294_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_294_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_294_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_294_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_294_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_294_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_294_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_294_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_294_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_295_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_295_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_295_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_295_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_295_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_295_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_295_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_295_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_295_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_295_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_296_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_296_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_296_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_296_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_296_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_296_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_296_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_296_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_296_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_296_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_297_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_297_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_297_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_297_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_297_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_297_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_297_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_297_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_297_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_297_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_298_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_298_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_298_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_298_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_298_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_298_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_298_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_298_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_298_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_298_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_299_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_299_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_299_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_299_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_299_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_299_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_299_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_299_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_299_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_299_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_29_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_29_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_29_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_29_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_29_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_29_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_29_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_29_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_29_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_29_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_2_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_2_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_2_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_2_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_2_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_2_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_2_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_2_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_2_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_2_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_300_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_300_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_300_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_300_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_300_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_300_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_300_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_300_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_300_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_300_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_301_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_301_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_301_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_301_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_301_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_301_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_301_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_301_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_301_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_301_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_302_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_302_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_302_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_302_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_302_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_302_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_302_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_302_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_302_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_302_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_303_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_303_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_303_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_303_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_303_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_303_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_303_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_303_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_303_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_303_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_304_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_304_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_304_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_304_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_304_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_304_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_304_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_304_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_304_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_304_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_305_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_305_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_305_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_305_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_305_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_305_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_305_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_305_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_305_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_305_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_306_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_306_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_306_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_306_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_306_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_306_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_306_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_306_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_306_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_306_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_307_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_307_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_307_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_307_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_307_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_307_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_307_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_307_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_307_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_307_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_308_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_308_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_308_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_308_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_308_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_308_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_308_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_308_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_308_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_308_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_309_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_309_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_309_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_309_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_309_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_309_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_309_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_309_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_309_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_309_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_30_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_30_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_30_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_30_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_30_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_30_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_30_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_30_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_30_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_30_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_310_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_310_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_310_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_310_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_310_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_310_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_310_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_310_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_310_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_310_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_311_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_311_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_311_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_311_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_311_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_311_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_311_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_311_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_311_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_311_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_312_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_312_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_312_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_312_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_312_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_312_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_312_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_312_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_312_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_312_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_313_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_313_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_313_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_313_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_313_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_313_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_313_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_313_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_313_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_313_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_314_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_314_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_314_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_314_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_314_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_314_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_314_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_314_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_314_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_314_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_315_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_315_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_315_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_315_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_315_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_315_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_315_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_315_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_315_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_315_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_316_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_316_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_316_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_316_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_316_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_316_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_316_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_316_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_316_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_316_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_31_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_31_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_31_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_31_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_31_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_31_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_31_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_31_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_31_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_31_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_32_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_32_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_32_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_32_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_32_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_32_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_32_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_32_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_32_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_32_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_33_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_33_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_33_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_33_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_33_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_33_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_33_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_33_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_33_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_33_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_34_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_34_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_34_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_34_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_34_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_34_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_34_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_34_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_34_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_34_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_35_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_35_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_35_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_35_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_35_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_35_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_35_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_35_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_35_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_35_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_36_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_36_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_36_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_36_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_36_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_36_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_36_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_36_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_36_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_36_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_37_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_37_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_37_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_37_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_37_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_37_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_37_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_37_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_37_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_37_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_38_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_38_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_38_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_38_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_38_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_38_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_38_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_38_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_38_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_38_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_39_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_39_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_39_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_39_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_39_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_39_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_39_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_39_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_39_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_39_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_3_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_3_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_3_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_3_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_3_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_3_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_3_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_3_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_3_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_3_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_40_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_40_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_40_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_40_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_40_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_40_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_40_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_40_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_40_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_40_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_41_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_41_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_41_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_41_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_41_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_41_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_41_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_41_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_41_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_41_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_42_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_42_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_42_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_42_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_42_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_42_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_42_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_42_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_42_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_42_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_43_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_43_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_43_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_43_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_43_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_43_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_43_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_43_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_43_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_43_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_44_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_44_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_44_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_44_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_44_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_44_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_44_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_44_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_44_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_44_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_45_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_45_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_45_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_45_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_45_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_45_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_45_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_45_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_45_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_45_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_46_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_46_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_46_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_46_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_46_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_46_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_46_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_46_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_46_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_46_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_47_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_47_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_47_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_47_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_47_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_47_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_47_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_47_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_47_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_47_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_48_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_48_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_48_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_48_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_48_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_48_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_48_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_48_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_48_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_48_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_49_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_49_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_49_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_49_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_49_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_49_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_49_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_49_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_49_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_49_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_4_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_4_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_4_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_4_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_4_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_4_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_4_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_4_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_4_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_4_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_50_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_50_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_50_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_50_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_50_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_50_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_50_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_50_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_50_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_50_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_51_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_51_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_51_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_51_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_51_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_51_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_51_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_51_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_51_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_51_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_52_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_52_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_52_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_52_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_52_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_52_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_52_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_52_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_52_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_52_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_53_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_53_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_53_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_53_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_53_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_53_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_53_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_53_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_53_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_53_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_54_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_54_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_54_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_54_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_54_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_54_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_54_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_54_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_54_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_54_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_55_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_55_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_55_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_55_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_55_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_55_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_55_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_55_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_55_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_55_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_56_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_56_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_56_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_56_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_56_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_56_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_56_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_56_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_56_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_56_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_57_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_57_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_57_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_57_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_57_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_57_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_57_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_57_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_57_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_57_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_58_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_58_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_58_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_58_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_58_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_58_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_58_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_58_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_58_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_58_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_59_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_59_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_59_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_59_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_59_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_59_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_59_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_59_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_59_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_59_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_5_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_5_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_5_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_5_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_5_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_5_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_5_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_5_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_5_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_5_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_60_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_60_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_60_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_60_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_60_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_60_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_60_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_60_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_60_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_60_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_61_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_61_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_61_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_61_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_61_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_61_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_61_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_61_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_61_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_61_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_62_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_62_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_62_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_62_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_62_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_62_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_62_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_62_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_62_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_62_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_63_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_63_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_63_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_63_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_63_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_63_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_63_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_63_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_63_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_63_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_64_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_64_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_64_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_64_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_64_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_64_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_64_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_64_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_64_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_64_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_65_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_65_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_65_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_65_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_65_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_65_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_65_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_65_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_65_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_65_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_66_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_66_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_66_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_66_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_66_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_66_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_66_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_66_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_66_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_66_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_67_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_67_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_67_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_67_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_67_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_67_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_67_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_67_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_67_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_67_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_68_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_68_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_68_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_68_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_68_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_68_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_68_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_68_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_68_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_68_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_69_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_69_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_69_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_69_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_69_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_69_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_69_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_69_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_69_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_69_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_6_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_6_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_6_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_6_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_6_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_6_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_6_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_6_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_6_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_6_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_70_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_70_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_70_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_70_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_70_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_70_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_70_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_70_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_70_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_70_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_71_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_71_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_71_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_71_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_71_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_71_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_71_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_71_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_71_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_71_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_72_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_72_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_72_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_72_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_72_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_72_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_72_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_72_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_72_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_72_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_73_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_73_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_73_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_73_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_73_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_73_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_73_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_73_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_73_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_73_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_74_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_74_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_74_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_74_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_74_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_74_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_74_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_74_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_74_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_74_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_75_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_75_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_75_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_75_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_75_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_75_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_75_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_75_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_75_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_75_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_76_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_76_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_76_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_76_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_76_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_76_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_76_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_76_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_76_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_76_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_77_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_77_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_77_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_77_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_77_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_77_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_77_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_77_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_77_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_77_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_78_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_78_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_78_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_78_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_78_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_78_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_78_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_78_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_78_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_78_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_79_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_79_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_79_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_79_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_79_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_79_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_79_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_79_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_79_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_79_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_7_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_7_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_7_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_7_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_7_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_7_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_7_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_7_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_7_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_7_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_80_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_80_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_80_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_80_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_80_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_80_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_80_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_80_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_80_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_80_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_81_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_81_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_81_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_81_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_81_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_81_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_81_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_81_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_81_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_81_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_82_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_82_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_82_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_82_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_82_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_82_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_82_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_82_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_82_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_82_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_83_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_83_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_83_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_83_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_83_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_83_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_83_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_83_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_83_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_83_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_84_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_84_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_84_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_84_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_84_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_84_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_84_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_84_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_84_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_84_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_85_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_85_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_85_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_85_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_85_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_85_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_85_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_85_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_85_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_85_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_86_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_86_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_86_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_86_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_86_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_86_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_86_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_86_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_86_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_86_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_87_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_87_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_87_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_87_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_87_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_87_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_87_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_87_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_87_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_87_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_88_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_88_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_88_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_88_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_88_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_88_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_88_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_88_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_88_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_88_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_89_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_89_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_89_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_89_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_89_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_89_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_89_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_89_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_89_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_89_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_8_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_8_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_8_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_8_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_8_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_8_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_8_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_8_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_8_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_8_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_90_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_90_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_90_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_90_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_90_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_90_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_90_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_90_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_90_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_90_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_91_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_91_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_91_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_91_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_91_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_91_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_91_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_91_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_91_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_91_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_92_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_92_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_92_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_92_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_92_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_92_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_92_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_92_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_92_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_92_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_93_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_93_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_93_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_93_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_93_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_93_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_93_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_93_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_93_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_93_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_94_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_94_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_94_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_94_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_94_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_94_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_94_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_94_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_94_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_94_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_95_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_95_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_95_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_95_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_95_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_95_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_95_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_95_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_95_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_95_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_96_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_96_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_96_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_96_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_96_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_96_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_96_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_96_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_96_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_96_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_97_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_97_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_97_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_97_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_97_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_97_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_97_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_97_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_97_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_97_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_98_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_98_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_98_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_98_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_98_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_98_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_98_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_98_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_98_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_98_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_99_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_99_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_99_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_99_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_99_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_99_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_99_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_99_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_99_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_99_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: _hyper_1_9_chunk symbol; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_9_chunk ALTER COLUMN symbol SET DEFAULT 'USD/COP'::text;


--
-- Name: _hyper_1_9_chunk volume; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_9_chunk ALTER COLUMN volume SET DEFAULT 0;


--
-- Name: _hyper_1_9_chunk source; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_9_chunk ALTER COLUMN source SET DEFAULT 'twelvedata'::text;


--
-- Name: _hyper_1_9_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_9_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Name: _hyper_1_9_chunk updated_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_9_chunk ALTER COLUMN updated_at SET DEFAULT now();


--
-- Name: feature_definitions feature_id; Type: DEFAULT; Schema: config; Owner: -
--

ALTER TABLE ONLY config.feature_definitions ALTER COLUMN feature_id SET DEFAULT nextval('config.feature_definitions_feature_id_seq'::regclass);


--
-- Name: fact_agent_actions id; Type: DEFAULT; Schema: dw; Owner: -
--

ALTER TABLE ONLY dw.fact_agent_actions ALTER COLUMN id SET DEFAULT nextval('dw.fact_agent_actions_id_seq'::regclass);


--
-- Name: fact_equity_curve_realtime id; Type: DEFAULT; Schema: dw; Owner: -
--

ALTER TABLE ONLY dw.fact_equity_curve_realtime ALTER COLUMN id SET DEFAULT nextval('dw.fact_equity_curve_realtime_id_seq'::regclass);


--
-- Name: fact_inference_alerts alert_id; Type: DEFAULT; Schema: dw; Owner: -
--

ALTER TABLE ONLY dw.fact_inference_alerts ALTER COLUMN alert_id SET DEFAULT nextval('dw.fact_inference_alerts_alert_id_seq'::regclass);


--
-- Name: fact_rl_inference id; Type: DEFAULT; Schema: dw; Owner: -
--

ALTER TABLE ONLY dw.fact_rl_inference ALTER COLUMN id SET DEFAULT nextval('dw.fact_rl_inference_id_seq'::regclass);


--
-- Name: fact_strategy_performance id; Type: DEFAULT; Schema: dw; Owner: -
--

ALTER TABLE ONLY dw.fact_strategy_performance ALTER COLUMN id SET DEFAULT nextval('dw.fact_strategy_performance_id_seq'::regclass);


--
-- Name: fact_strategy_positions id; Type: DEFAULT; Schema: dw; Owner: -
--

ALTER TABLE ONLY dw.fact_strategy_positions ALTER COLUMN id SET DEFAULT nextval('dw.fact_strategy_positions_id_seq'::regclass);


--
-- Name: signals_stream stream_id; Type: DEFAULT; Schema: events; Owner: -
--

ALTER TABLE ONLY events.signals_stream ALTER COLUMN stream_id SET DEFAULT nextval('events.signals_stream_stream_id_seq'::regclass);


--
-- Name: model_performance perf_id; Type: DEFAULT; Schema: metrics; Owner: -
--

ALTER TABLE ONLY metrics.model_performance ALTER COLUMN perf_id SET DEFAULT nextval('metrics.model_performance_perf_id_seq'::regclass);


--
-- Name: ab_permission id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_permission ALTER COLUMN id SET DEFAULT nextval('public.ab_permission_id_seq'::regclass);


--
-- Name: ab_permission_view id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_permission_view ALTER COLUMN id SET DEFAULT nextval('public.ab_permission_view_id_seq'::regclass);


--
-- Name: ab_permission_view_role id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_permission_view_role ALTER COLUMN id SET DEFAULT nextval('public.ab_permission_view_role_id_seq'::regclass);


--
-- Name: ab_register_user id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_register_user ALTER COLUMN id SET DEFAULT nextval('public.ab_register_user_id_seq'::regclass);


--
-- Name: ab_role id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_role ALTER COLUMN id SET DEFAULT nextval('public.ab_role_id_seq'::regclass);


--
-- Name: ab_user id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_user ALTER COLUMN id SET DEFAULT nextval('public.ab_user_id_seq'::regclass);


--
-- Name: ab_user_role id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_user_role ALTER COLUMN id SET DEFAULT nextval('public.ab_user_role_id_seq'::regclass);


--
-- Name: ab_view_menu id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_view_menu ALTER COLUMN id SET DEFAULT nextval('public.ab_view_menu_id_seq'::regclass);


--
-- Name: auth_audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_audit_log ALTER COLUMN id SET DEFAULT nextval('public.auth_audit_log_id_seq'::regclass);


--
-- Name: callback_request id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.callback_request ALTER COLUMN id SET DEFAULT nextval('public.callback_request_id_seq'::regclass);


--
-- Name: connection id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connection ALTER COLUMN id SET DEFAULT nextval('public.connection_id_seq'::regclass);


--
-- Name: dag_pickle id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dag_pickle ALTER COLUMN id SET DEFAULT nextval('public.dag_pickle_id_seq'::regclass);


--
-- Name: dag_run id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dag_run ALTER COLUMN id SET DEFAULT nextval('public.dag_run_id_seq'::regclass);


--
-- Name: dataset id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset ALTER COLUMN id SET DEFAULT nextval('public.dataset_id_seq'::regclass);


--
-- Name: dataset_event id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset_event ALTER COLUMN id SET DEFAULT nextval('public.dataset_event_id_seq'::regclass);


--
-- Name: equity_snapshots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equity_snapshots ALTER COLUMN id SET DEFAULT nextval('public.equity_snapshots_id_seq'::regclass);


--
-- Name: import_error id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_error ALTER COLUMN id SET DEFAULT nextval('public.import_error_id_seq'::regclass);


--
-- Name: job id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job ALTER COLUMN id SET DEFAULT nextval('public.job_id_seq'::regclass);


--
-- Name: log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log ALTER COLUMN id SET DEFAULT nextval('public.log_id_seq'::regclass);


--
-- Name: log_template id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_template ALTER COLUMN id SET DEFAULT nextval('public.log_template_id_seq'::regclass);


--
-- Name: session id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session ALTER COLUMN id SET DEFAULT nextval('public.session_id_seq'::regclass);


--
-- Name: slot_pool id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slot_pool ALTER COLUMN id SET DEFAULT nextval('public.slot_pool_id_seq'::regclass);


--
-- Name: task_fail id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_fail ALTER COLUMN id SET DEFAULT nextval('public.task_fail_id_seq'::regclass);


--
-- Name: task_reschedule id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_reschedule ALTER COLUMN id SET DEFAULT nextval('public.task_reschedule_id_seq'::regclass);


--
-- Name: trades_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trades_history ALTER COLUMN id SET DEFAULT nextval('public.trades_history_id_seq'::regclass);


--
-- Name: trading_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trading_sessions ALTER COLUMN id SET DEFAULT nextval('public.trading_sessions_id_seq'::regclass);


--
-- Name: trading_state id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trading_state ALTER COLUMN id SET DEFAULT nextval('public.trading_state_id_seq'::regclass);


--
-- Name: trigger id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trigger ALTER COLUMN id SET DEFAULT nextval('public.trigger_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: variable id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.variable ALTER COLUMN id SET DEFAULT nextval('public.variable_id_seq'::regclass);


--
-- Name: model_inferences inference_id; Type: DEFAULT; Schema: trading; Owner: -
--

ALTER TABLE ONLY trading.model_inferences ALTER COLUMN inference_id SET DEFAULT nextval('trading.model_inferences_inference_id_seq'::regclass);


--
-- Name: model_trades trade_id; Type: DEFAULT; Schema: trading; Owner: -
--

ALTER TABLE ONLY trading.model_trades ALTER COLUMN trade_id SET DEFAULT nextval('trading.model_trades_trade_id_seq'::regclass);


--
-- Name: _hyper_1_100_chunk 100_100_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_100_chunk
    ADD CONSTRAINT "100_100_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_101_chunk 101_101_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_101_chunk
    ADD CONSTRAINT "101_101_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_102_chunk 102_102_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_102_chunk
    ADD CONSTRAINT "102_102_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_103_chunk 103_103_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_103_chunk
    ADD CONSTRAINT "103_103_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_104_chunk 104_104_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_104_chunk
    ADD CONSTRAINT "104_104_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_105_chunk 105_105_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_105_chunk
    ADD CONSTRAINT "105_105_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_106_chunk 106_106_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_106_chunk
    ADD CONSTRAINT "106_106_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_107_chunk 107_107_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_107_chunk
    ADD CONSTRAINT "107_107_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_108_chunk 108_108_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_108_chunk
    ADD CONSTRAINT "108_108_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_109_chunk 109_109_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_109_chunk
    ADD CONSTRAINT "109_109_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_10_chunk 10_10_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_10_chunk
    ADD CONSTRAINT "10_10_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_110_chunk 110_110_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_110_chunk
    ADD CONSTRAINT "110_110_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_111_chunk 111_111_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_111_chunk
    ADD CONSTRAINT "111_111_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_112_chunk 112_112_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_112_chunk
    ADD CONSTRAINT "112_112_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_113_chunk 113_113_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_113_chunk
    ADD CONSTRAINT "113_113_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_114_chunk 114_114_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_114_chunk
    ADD CONSTRAINT "114_114_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_115_chunk 115_115_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_115_chunk
    ADD CONSTRAINT "115_115_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_116_chunk 116_116_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_116_chunk
    ADD CONSTRAINT "116_116_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_117_chunk 117_117_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_117_chunk
    ADD CONSTRAINT "117_117_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_118_chunk 118_118_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_118_chunk
    ADD CONSTRAINT "118_118_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_119_chunk 119_119_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_119_chunk
    ADD CONSTRAINT "119_119_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_11_chunk 11_11_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_11_chunk
    ADD CONSTRAINT "11_11_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_120_chunk 120_120_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_120_chunk
    ADD CONSTRAINT "120_120_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_121_chunk 121_121_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_121_chunk
    ADD CONSTRAINT "121_121_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_122_chunk 122_122_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_122_chunk
    ADD CONSTRAINT "122_122_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_123_chunk 123_123_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_123_chunk
    ADD CONSTRAINT "123_123_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_124_chunk 124_124_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_124_chunk
    ADD CONSTRAINT "124_124_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_125_chunk 125_125_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_125_chunk
    ADD CONSTRAINT "125_125_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_126_chunk 126_126_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_126_chunk
    ADD CONSTRAINT "126_126_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_127_chunk 127_127_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_127_chunk
    ADD CONSTRAINT "127_127_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_128_chunk 128_128_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_128_chunk
    ADD CONSTRAINT "128_128_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_129_chunk 129_129_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_129_chunk
    ADD CONSTRAINT "129_129_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_12_chunk 12_12_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_12_chunk
    ADD CONSTRAINT "12_12_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_130_chunk 130_130_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_130_chunk
    ADD CONSTRAINT "130_130_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_131_chunk 131_131_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_131_chunk
    ADD CONSTRAINT "131_131_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_132_chunk 132_132_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_132_chunk
    ADD CONSTRAINT "132_132_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_133_chunk 133_133_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_133_chunk
    ADD CONSTRAINT "133_133_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_134_chunk 134_134_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_134_chunk
    ADD CONSTRAINT "134_134_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_135_chunk 135_135_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_135_chunk
    ADD CONSTRAINT "135_135_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_136_chunk 136_136_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_136_chunk
    ADD CONSTRAINT "136_136_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_137_chunk 137_137_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_137_chunk
    ADD CONSTRAINT "137_137_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_138_chunk 138_138_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_138_chunk
    ADD CONSTRAINT "138_138_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_139_chunk 139_139_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_139_chunk
    ADD CONSTRAINT "139_139_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_13_chunk 13_13_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_13_chunk
    ADD CONSTRAINT "13_13_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_140_chunk 140_140_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_140_chunk
    ADD CONSTRAINT "140_140_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_141_chunk 141_141_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_141_chunk
    ADD CONSTRAINT "141_141_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_142_chunk 142_142_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_142_chunk
    ADD CONSTRAINT "142_142_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_143_chunk 143_143_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_143_chunk
    ADD CONSTRAINT "143_143_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_144_chunk 144_144_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_144_chunk
    ADD CONSTRAINT "144_144_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_145_chunk 145_145_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_145_chunk
    ADD CONSTRAINT "145_145_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_146_chunk 146_146_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_146_chunk
    ADD CONSTRAINT "146_146_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_147_chunk 147_147_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_147_chunk
    ADD CONSTRAINT "147_147_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_148_chunk 148_148_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_148_chunk
    ADD CONSTRAINT "148_148_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_149_chunk 149_149_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_149_chunk
    ADD CONSTRAINT "149_149_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_14_chunk 14_14_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_14_chunk
    ADD CONSTRAINT "14_14_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_150_chunk 150_150_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_150_chunk
    ADD CONSTRAINT "150_150_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_151_chunk 151_151_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_151_chunk
    ADD CONSTRAINT "151_151_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_152_chunk 152_152_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_152_chunk
    ADD CONSTRAINT "152_152_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_153_chunk 153_153_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_153_chunk
    ADD CONSTRAINT "153_153_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_154_chunk 154_154_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_154_chunk
    ADD CONSTRAINT "154_154_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_155_chunk 155_155_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_155_chunk
    ADD CONSTRAINT "155_155_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_156_chunk 156_156_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_156_chunk
    ADD CONSTRAINT "156_156_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_157_chunk 157_157_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_157_chunk
    ADD CONSTRAINT "157_157_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_158_chunk 158_158_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_158_chunk
    ADD CONSTRAINT "158_158_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_159_chunk 159_159_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_159_chunk
    ADD CONSTRAINT "159_159_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_15_chunk 15_15_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_15_chunk
    ADD CONSTRAINT "15_15_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_160_chunk 160_160_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_160_chunk
    ADD CONSTRAINT "160_160_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_161_chunk 161_161_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_161_chunk
    ADD CONSTRAINT "161_161_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_162_chunk 162_162_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_162_chunk
    ADD CONSTRAINT "162_162_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_163_chunk 163_163_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_163_chunk
    ADD CONSTRAINT "163_163_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_164_chunk 164_164_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_164_chunk
    ADD CONSTRAINT "164_164_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_165_chunk 165_165_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_165_chunk
    ADD CONSTRAINT "165_165_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_166_chunk 166_166_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_166_chunk
    ADD CONSTRAINT "166_166_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_167_chunk 167_167_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_167_chunk
    ADD CONSTRAINT "167_167_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_168_chunk 168_168_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_168_chunk
    ADD CONSTRAINT "168_168_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_169_chunk 169_169_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_169_chunk
    ADD CONSTRAINT "169_169_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_16_chunk 16_16_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_16_chunk
    ADD CONSTRAINT "16_16_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_170_chunk 170_170_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_170_chunk
    ADD CONSTRAINT "170_170_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_171_chunk 171_171_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_171_chunk
    ADD CONSTRAINT "171_171_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_172_chunk 172_172_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_172_chunk
    ADD CONSTRAINT "172_172_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_173_chunk 173_173_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_173_chunk
    ADD CONSTRAINT "173_173_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_174_chunk 174_174_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_174_chunk
    ADD CONSTRAINT "174_174_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_175_chunk 175_175_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_175_chunk
    ADD CONSTRAINT "175_175_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_176_chunk 176_176_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_176_chunk
    ADD CONSTRAINT "176_176_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_177_chunk 177_177_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_177_chunk
    ADD CONSTRAINT "177_177_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_178_chunk 178_178_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_178_chunk
    ADD CONSTRAINT "178_178_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_179_chunk 179_179_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_179_chunk
    ADD CONSTRAINT "179_179_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_17_chunk 17_17_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_17_chunk
    ADD CONSTRAINT "17_17_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_180_chunk 180_180_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_180_chunk
    ADD CONSTRAINT "180_180_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_181_chunk 181_181_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_181_chunk
    ADD CONSTRAINT "181_181_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_182_chunk 182_182_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_182_chunk
    ADD CONSTRAINT "182_182_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_183_chunk 183_183_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_183_chunk
    ADD CONSTRAINT "183_183_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_184_chunk 184_184_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_184_chunk
    ADD CONSTRAINT "184_184_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_185_chunk 185_185_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_185_chunk
    ADD CONSTRAINT "185_185_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_186_chunk 186_186_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_186_chunk
    ADD CONSTRAINT "186_186_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_187_chunk 187_187_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_187_chunk
    ADD CONSTRAINT "187_187_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_188_chunk 188_188_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_188_chunk
    ADD CONSTRAINT "188_188_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_189_chunk 189_189_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_189_chunk
    ADD CONSTRAINT "189_189_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_18_chunk 18_18_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_18_chunk
    ADD CONSTRAINT "18_18_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_190_chunk 190_190_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_190_chunk
    ADD CONSTRAINT "190_190_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_191_chunk 191_191_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_191_chunk
    ADD CONSTRAINT "191_191_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_192_chunk 192_192_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_192_chunk
    ADD CONSTRAINT "192_192_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_193_chunk 193_193_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_193_chunk
    ADD CONSTRAINT "193_193_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_194_chunk 194_194_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_194_chunk
    ADD CONSTRAINT "194_194_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_195_chunk 195_195_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_195_chunk
    ADD CONSTRAINT "195_195_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_196_chunk 196_196_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_196_chunk
    ADD CONSTRAINT "196_196_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_197_chunk 197_197_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_197_chunk
    ADD CONSTRAINT "197_197_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_198_chunk 198_198_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_198_chunk
    ADD CONSTRAINT "198_198_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_199_chunk 199_199_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_199_chunk
    ADD CONSTRAINT "199_199_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_19_chunk 19_19_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_19_chunk
    ADD CONSTRAINT "19_19_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_200_chunk 200_200_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_200_chunk
    ADD CONSTRAINT "200_200_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_201_chunk 201_201_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_201_chunk
    ADD CONSTRAINT "201_201_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_202_chunk 202_202_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_202_chunk
    ADD CONSTRAINT "202_202_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_203_chunk 203_203_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_203_chunk
    ADD CONSTRAINT "203_203_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_204_chunk 204_204_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_204_chunk
    ADD CONSTRAINT "204_204_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_205_chunk 205_205_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_205_chunk
    ADD CONSTRAINT "205_205_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_206_chunk 206_206_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_206_chunk
    ADD CONSTRAINT "206_206_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_207_chunk 207_207_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_207_chunk
    ADD CONSTRAINT "207_207_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_208_chunk 208_208_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_208_chunk
    ADD CONSTRAINT "208_208_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_209_chunk 209_209_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_209_chunk
    ADD CONSTRAINT "209_209_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_20_chunk 20_20_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_20_chunk
    ADD CONSTRAINT "20_20_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_210_chunk 210_210_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_210_chunk
    ADD CONSTRAINT "210_210_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_211_chunk 211_211_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_211_chunk
    ADD CONSTRAINT "211_211_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_212_chunk 212_212_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_212_chunk
    ADD CONSTRAINT "212_212_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_213_chunk 213_213_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_213_chunk
    ADD CONSTRAINT "213_213_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_214_chunk 214_214_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_214_chunk
    ADD CONSTRAINT "214_214_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_215_chunk 215_215_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_215_chunk
    ADD CONSTRAINT "215_215_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_216_chunk 216_216_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_216_chunk
    ADD CONSTRAINT "216_216_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_217_chunk 217_217_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_217_chunk
    ADD CONSTRAINT "217_217_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_218_chunk 218_218_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_218_chunk
    ADD CONSTRAINT "218_218_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_219_chunk 219_219_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_219_chunk
    ADD CONSTRAINT "219_219_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_21_chunk 21_21_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_21_chunk
    ADD CONSTRAINT "21_21_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_220_chunk 220_220_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_220_chunk
    ADD CONSTRAINT "220_220_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_221_chunk 221_221_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_221_chunk
    ADD CONSTRAINT "221_221_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_222_chunk 222_222_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_222_chunk
    ADD CONSTRAINT "222_222_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_223_chunk 223_223_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_223_chunk
    ADD CONSTRAINT "223_223_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_224_chunk 224_224_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_224_chunk
    ADD CONSTRAINT "224_224_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_225_chunk 225_225_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_225_chunk
    ADD CONSTRAINT "225_225_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_226_chunk 226_226_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_226_chunk
    ADD CONSTRAINT "226_226_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_227_chunk 227_227_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_227_chunk
    ADD CONSTRAINT "227_227_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_228_chunk 228_228_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_228_chunk
    ADD CONSTRAINT "228_228_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_229_chunk 229_229_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_229_chunk
    ADD CONSTRAINT "229_229_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_22_chunk 22_22_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_22_chunk
    ADD CONSTRAINT "22_22_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_230_chunk 230_230_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_230_chunk
    ADD CONSTRAINT "230_230_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_231_chunk 231_231_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_231_chunk
    ADD CONSTRAINT "231_231_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_232_chunk 232_232_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_232_chunk
    ADD CONSTRAINT "232_232_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_233_chunk 233_233_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_233_chunk
    ADD CONSTRAINT "233_233_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_234_chunk 234_234_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_234_chunk
    ADD CONSTRAINT "234_234_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_235_chunk 235_235_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_235_chunk
    ADD CONSTRAINT "235_235_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_236_chunk 236_236_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_236_chunk
    ADD CONSTRAINT "236_236_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_237_chunk 237_237_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_237_chunk
    ADD CONSTRAINT "237_237_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_238_chunk 238_238_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_238_chunk
    ADD CONSTRAINT "238_238_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_239_chunk 239_239_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_239_chunk
    ADD CONSTRAINT "239_239_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_23_chunk 23_23_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_23_chunk
    ADD CONSTRAINT "23_23_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_240_chunk 240_240_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_240_chunk
    ADD CONSTRAINT "240_240_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_241_chunk 241_241_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_241_chunk
    ADD CONSTRAINT "241_241_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_242_chunk 242_242_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_242_chunk
    ADD CONSTRAINT "242_242_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_243_chunk 243_243_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_243_chunk
    ADD CONSTRAINT "243_243_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_244_chunk 244_244_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_244_chunk
    ADD CONSTRAINT "244_244_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_245_chunk 245_245_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_245_chunk
    ADD CONSTRAINT "245_245_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_246_chunk 246_246_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_246_chunk
    ADD CONSTRAINT "246_246_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_247_chunk 247_247_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_247_chunk
    ADD CONSTRAINT "247_247_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_248_chunk 248_248_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_248_chunk
    ADD CONSTRAINT "248_248_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_249_chunk 249_249_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_249_chunk
    ADD CONSTRAINT "249_249_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_24_chunk 24_24_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_24_chunk
    ADD CONSTRAINT "24_24_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_250_chunk 250_250_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_250_chunk
    ADD CONSTRAINT "250_250_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_251_chunk 251_251_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_251_chunk
    ADD CONSTRAINT "251_251_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_252_chunk 252_252_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_252_chunk
    ADD CONSTRAINT "252_252_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_253_chunk 253_253_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_253_chunk
    ADD CONSTRAINT "253_253_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_254_chunk 254_254_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_254_chunk
    ADD CONSTRAINT "254_254_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_255_chunk 255_255_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_255_chunk
    ADD CONSTRAINT "255_255_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_256_chunk 256_256_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_256_chunk
    ADD CONSTRAINT "256_256_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_257_chunk 257_257_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_257_chunk
    ADD CONSTRAINT "257_257_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_258_chunk 258_258_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_258_chunk
    ADD CONSTRAINT "258_258_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_259_chunk 259_259_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_259_chunk
    ADD CONSTRAINT "259_259_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_25_chunk 25_25_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_25_chunk
    ADD CONSTRAINT "25_25_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_260_chunk 260_260_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_260_chunk
    ADD CONSTRAINT "260_260_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_261_chunk 261_261_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_261_chunk
    ADD CONSTRAINT "261_261_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_262_chunk 262_262_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_262_chunk
    ADD CONSTRAINT "262_262_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_263_chunk 263_263_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_263_chunk
    ADD CONSTRAINT "263_263_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_264_chunk 264_264_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_264_chunk
    ADD CONSTRAINT "264_264_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_265_chunk 265_265_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_265_chunk
    ADD CONSTRAINT "265_265_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_266_chunk 266_266_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_266_chunk
    ADD CONSTRAINT "266_266_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_267_chunk 267_267_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_267_chunk
    ADD CONSTRAINT "267_267_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_268_chunk 268_268_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_268_chunk
    ADD CONSTRAINT "268_268_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_269_chunk 269_269_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_269_chunk
    ADD CONSTRAINT "269_269_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_26_chunk 26_26_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_26_chunk
    ADD CONSTRAINT "26_26_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_270_chunk 270_270_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_270_chunk
    ADD CONSTRAINT "270_270_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_271_chunk 271_271_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_271_chunk
    ADD CONSTRAINT "271_271_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_272_chunk 272_272_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_272_chunk
    ADD CONSTRAINT "272_272_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_273_chunk 273_273_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_273_chunk
    ADD CONSTRAINT "273_273_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_274_chunk 274_274_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_274_chunk
    ADD CONSTRAINT "274_274_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_275_chunk 275_275_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_275_chunk
    ADD CONSTRAINT "275_275_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_276_chunk 276_276_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_276_chunk
    ADD CONSTRAINT "276_276_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_277_chunk 277_277_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_277_chunk
    ADD CONSTRAINT "277_277_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_278_chunk 278_278_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_278_chunk
    ADD CONSTRAINT "278_278_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_279_chunk 279_279_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_279_chunk
    ADD CONSTRAINT "279_279_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_27_chunk 27_27_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_27_chunk
    ADD CONSTRAINT "27_27_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_280_chunk 280_280_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_280_chunk
    ADD CONSTRAINT "280_280_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_281_chunk 281_281_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_281_chunk
    ADD CONSTRAINT "281_281_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_282_chunk 282_282_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_282_chunk
    ADD CONSTRAINT "282_282_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_283_chunk 283_283_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_283_chunk
    ADD CONSTRAINT "283_283_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_284_chunk 284_284_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_284_chunk
    ADD CONSTRAINT "284_284_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_285_chunk 285_285_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_285_chunk
    ADD CONSTRAINT "285_285_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_286_chunk 286_286_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_286_chunk
    ADD CONSTRAINT "286_286_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_287_chunk 287_287_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_287_chunk
    ADD CONSTRAINT "287_287_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_288_chunk 288_288_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_288_chunk
    ADD CONSTRAINT "288_288_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_289_chunk 289_289_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_289_chunk
    ADD CONSTRAINT "289_289_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_28_chunk 28_28_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_28_chunk
    ADD CONSTRAINT "28_28_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_290_chunk 290_290_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_290_chunk
    ADD CONSTRAINT "290_290_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_291_chunk 291_291_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_291_chunk
    ADD CONSTRAINT "291_291_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_292_chunk 292_292_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_292_chunk
    ADD CONSTRAINT "292_292_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_293_chunk 293_293_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_293_chunk
    ADD CONSTRAINT "293_293_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_294_chunk 294_294_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_294_chunk
    ADD CONSTRAINT "294_294_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_295_chunk 295_295_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_295_chunk
    ADD CONSTRAINT "295_295_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_296_chunk 296_296_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_296_chunk
    ADD CONSTRAINT "296_296_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_297_chunk 297_297_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_297_chunk
    ADD CONSTRAINT "297_297_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_298_chunk 298_298_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_298_chunk
    ADD CONSTRAINT "298_298_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_299_chunk 299_299_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_299_chunk
    ADD CONSTRAINT "299_299_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_29_chunk 29_29_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_29_chunk
    ADD CONSTRAINT "29_29_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_2_chunk 2_2_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_2_chunk
    ADD CONSTRAINT "2_2_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_300_chunk 300_300_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_300_chunk
    ADD CONSTRAINT "300_300_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_301_chunk 301_301_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_301_chunk
    ADD CONSTRAINT "301_301_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_302_chunk 302_302_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_302_chunk
    ADD CONSTRAINT "302_302_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_303_chunk 303_303_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_303_chunk
    ADD CONSTRAINT "303_303_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_304_chunk 304_304_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_304_chunk
    ADD CONSTRAINT "304_304_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_305_chunk 305_305_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_305_chunk
    ADD CONSTRAINT "305_305_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_306_chunk 306_306_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_306_chunk
    ADD CONSTRAINT "306_306_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_307_chunk 307_307_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_307_chunk
    ADD CONSTRAINT "307_307_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_308_chunk 308_308_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_308_chunk
    ADD CONSTRAINT "308_308_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_309_chunk 309_309_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_309_chunk
    ADD CONSTRAINT "309_309_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_30_chunk 30_30_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_30_chunk
    ADD CONSTRAINT "30_30_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_310_chunk 310_310_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_310_chunk
    ADD CONSTRAINT "310_310_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_311_chunk 311_311_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_311_chunk
    ADD CONSTRAINT "311_311_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_312_chunk 312_312_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_312_chunk
    ADD CONSTRAINT "312_312_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_313_chunk 313_313_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_313_chunk
    ADD CONSTRAINT "313_313_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_314_chunk 314_314_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_314_chunk
    ADD CONSTRAINT "314_314_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_315_chunk 315_315_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_315_chunk
    ADD CONSTRAINT "315_315_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_316_chunk 316_316_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_316_chunk
    ADD CONSTRAINT "316_316_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_31_chunk 31_31_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_31_chunk
    ADD CONSTRAINT "31_31_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_32_chunk 32_32_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_32_chunk
    ADD CONSTRAINT "32_32_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_33_chunk 33_33_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_33_chunk
    ADD CONSTRAINT "33_33_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_34_chunk 34_34_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_34_chunk
    ADD CONSTRAINT "34_34_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_35_chunk 35_35_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_35_chunk
    ADD CONSTRAINT "35_35_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_36_chunk 36_36_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_36_chunk
    ADD CONSTRAINT "36_36_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_37_chunk 37_37_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_37_chunk
    ADD CONSTRAINT "37_37_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_38_chunk 38_38_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_38_chunk
    ADD CONSTRAINT "38_38_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_39_chunk 39_39_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_39_chunk
    ADD CONSTRAINT "39_39_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_3_chunk 3_3_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_3_chunk
    ADD CONSTRAINT "3_3_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_40_chunk 40_40_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_40_chunk
    ADD CONSTRAINT "40_40_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_41_chunk 41_41_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_41_chunk
    ADD CONSTRAINT "41_41_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_42_chunk 42_42_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_42_chunk
    ADD CONSTRAINT "42_42_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_43_chunk 43_43_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_43_chunk
    ADD CONSTRAINT "43_43_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_44_chunk 44_44_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_44_chunk
    ADD CONSTRAINT "44_44_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_45_chunk 45_45_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_45_chunk
    ADD CONSTRAINT "45_45_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_46_chunk 46_46_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_46_chunk
    ADD CONSTRAINT "46_46_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_47_chunk 47_47_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_47_chunk
    ADD CONSTRAINT "47_47_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_48_chunk 48_48_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_48_chunk
    ADD CONSTRAINT "48_48_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_49_chunk 49_49_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_49_chunk
    ADD CONSTRAINT "49_49_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_4_chunk 4_4_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_4_chunk
    ADD CONSTRAINT "4_4_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_50_chunk 50_50_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_50_chunk
    ADD CONSTRAINT "50_50_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_51_chunk 51_51_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_51_chunk
    ADD CONSTRAINT "51_51_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_52_chunk 52_52_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_52_chunk
    ADD CONSTRAINT "52_52_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_53_chunk 53_53_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_53_chunk
    ADD CONSTRAINT "53_53_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_54_chunk 54_54_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_54_chunk
    ADD CONSTRAINT "54_54_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_55_chunk 55_55_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_55_chunk
    ADD CONSTRAINT "55_55_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_56_chunk 56_56_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_56_chunk
    ADD CONSTRAINT "56_56_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_57_chunk 57_57_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_57_chunk
    ADD CONSTRAINT "57_57_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_58_chunk 58_58_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_58_chunk
    ADD CONSTRAINT "58_58_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_59_chunk 59_59_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_59_chunk
    ADD CONSTRAINT "59_59_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_5_chunk 5_5_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_5_chunk
    ADD CONSTRAINT "5_5_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_60_chunk 60_60_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_60_chunk
    ADD CONSTRAINT "60_60_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_61_chunk 61_61_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_61_chunk
    ADD CONSTRAINT "61_61_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_62_chunk 62_62_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_62_chunk
    ADD CONSTRAINT "62_62_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_63_chunk 63_63_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_63_chunk
    ADD CONSTRAINT "63_63_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_64_chunk 64_64_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_64_chunk
    ADD CONSTRAINT "64_64_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_65_chunk 65_65_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_65_chunk
    ADD CONSTRAINT "65_65_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_66_chunk 66_66_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_66_chunk
    ADD CONSTRAINT "66_66_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_67_chunk 67_67_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_67_chunk
    ADD CONSTRAINT "67_67_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_68_chunk 68_68_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_68_chunk
    ADD CONSTRAINT "68_68_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_69_chunk 69_69_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_69_chunk
    ADD CONSTRAINT "69_69_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_6_chunk 6_6_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_6_chunk
    ADD CONSTRAINT "6_6_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_70_chunk 70_70_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_70_chunk
    ADD CONSTRAINT "70_70_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_71_chunk 71_71_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_71_chunk
    ADD CONSTRAINT "71_71_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_72_chunk 72_72_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_72_chunk
    ADD CONSTRAINT "72_72_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_73_chunk 73_73_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_73_chunk
    ADD CONSTRAINT "73_73_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_74_chunk 74_74_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_74_chunk
    ADD CONSTRAINT "74_74_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_75_chunk 75_75_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_75_chunk
    ADD CONSTRAINT "75_75_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_76_chunk 76_76_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_76_chunk
    ADD CONSTRAINT "76_76_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_77_chunk 77_77_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_77_chunk
    ADD CONSTRAINT "77_77_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_78_chunk 78_78_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_78_chunk
    ADD CONSTRAINT "78_78_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_79_chunk 79_79_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_79_chunk
    ADD CONSTRAINT "79_79_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_7_chunk 7_7_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_7_chunk
    ADD CONSTRAINT "7_7_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_80_chunk 80_80_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_80_chunk
    ADD CONSTRAINT "80_80_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_81_chunk 81_81_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_81_chunk
    ADD CONSTRAINT "81_81_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_82_chunk 82_82_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_82_chunk
    ADD CONSTRAINT "82_82_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_83_chunk 83_83_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_83_chunk
    ADD CONSTRAINT "83_83_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_84_chunk 84_84_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_84_chunk
    ADD CONSTRAINT "84_84_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_85_chunk 85_85_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_85_chunk
    ADD CONSTRAINT "85_85_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_86_chunk 86_86_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_86_chunk
    ADD CONSTRAINT "86_86_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_87_chunk 87_87_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_87_chunk
    ADD CONSTRAINT "87_87_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_88_chunk 88_88_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_88_chunk
    ADD CONSTRAINT "88_88_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_89_chunk 89_89_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_89_chunk
    ADD CONSTRAINT "89_89_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_8_chunk 8_8_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_8_chunk
    ADD CONSTRAINT "8_8_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_90_chunk 90_90_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_90_chunk
    ADD CONSTRAINT "90_90_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_91_chunk 91_91_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_91_chunk
    ADD CONSTRAINT "91_91_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_92_chunk 92_92_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_92_chunk
    ADD CONSTRAINT "92_92_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_93_chunk 93_93_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_93_chunk
    ADD CONSTRAINT "93_93_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_94_chunk 94_94_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_94_chunk
    ADD CONSTRAINT "94_94_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_95_chunk 95_95_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_95_chunk
    ADD CONSTRAINT "95_95_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_96_chunk 96_96_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_96_chunk
    ADD CONSTRAINT "96_96_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_97_chunk 97_97_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_97_chunk
    ADD CONSTRAINT "97_97_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_98_chunk 98_98_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_98_chunk
    ADD CONSTRAINT "98_98_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_99_chunk 99_99_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_99_chunk
    ADD CONSTRAINT "99_99_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: _hyper_1_9_chunk 9_9_usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: -
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_9_chunk
    ADD CONSTRAINT "9_9_usdcop_m5_ohlcv_pkey" PRIMARY KEY ("time", symbol);


--
-- Name: feature_definitions chk_observation_order_unique; Type: CONSTRAINT; Schema: config; Owner: -
--

ALTER TABLE ONLY config.feature_definitions
    ADD CONSTRAINT chk_observation_order_unique UNIQUE (observation_order) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: feature_definitions feature_definitions_feature_name_key; Type: CONSTRAINT; Schema: config; Owner: -
--

ALTER TABLE ONLY config.feature_definitions
    ADD CONSTRAINT feature_definitions_feature_name_key UNIQUE (feature_name);


--
-- Name: feature_definitions feature_definitions_pkey; Type: CONSTRAINT; Schema: config; Owner: -
--

ALTER TABLE ONLY config.feature_definitions
    ADD CONSTRAINT feature_definitions_pkey PRIMARY KEY (feature_id);


--
-- Name: models models_pkey; Type: CONSTRAINT; Schema: config; Owner: -
--

ALTER TABLE ONLY config.models
    ADD CONSTRAINT models_pkey PRIMARY KEY (model_id);


--
-- Name: fact_agent_actions fact_agent_actions_pkey; Type: CONSTRAINT; Schema: dw; Owner: -
--

ALTER TABLE ONLY dw.fact_agent_actions
    ADD CONSTRAINT fact_agent_actions_pkey PRIMARY KEY (id);


--
-- Name: fact_equity_curve_realtime fact_equity_curve_realtime_pkey; Type: CONSTRAINT; Schema: dw; Owner: -
--

ALTER TABLE ONLY dw.fact_equity_curve_realtime
    ADD CONSTRAINT fact_equity_curve_realtime_pkey PRIMARY KEY (id);


--
-- Name: fact_equity_curve_realtime fact_equity_curve_realtime_session_date_bar_number_key; Type: CONSTRAINT; Schema: dw; Owner: -
--

ALTER TABLE ONLY dw.fact_equity_curve_realtime
    ADD CONSTRAINT fact_equity_curve_realtime_session_date_bar_number_key UNIQUE (session_date, bar_number);


--
-- Name: fact_inference_alerts fact_inference_alerts_pkey; Type: CONSTRAINT; Schema: dw; Owner: -
--

ALTER TABLE ONLY dw.fact_inference_alerts
    ADD CONSTRAINT fact_inference_alerts_pkey PRIMARY KEY (alert_id);


--
-- Name: fact_rl_inference fact_rl_inference_pkey; Type: CONSTRAINT; Schema: dw; Owner: -
--

ALTER TABLE ONLY dw.fact_rl_inference
    ADD CONSTRAINT fact_rl_inference_pkey PRIMARY KEY (id);


--
-- Name: fact_session_performance fact_session_performance_pkey; Type: CONSTRAINT; Schema: dw; Owner: -
--

ALTER TABLE ONLY dw.fact_session_performance
    ADD CONSTRAINT fact_session_performance_pkey PRIMARY KEY (session_date);


--
-- Name: fact_strategy_performance fact_strategy_performance_pkey; Type: CONSTRAINT; Schema: dw; Owner: -
--

ALTER TABLE ONLY dw.fact_strategy_performance
    ADD CONSTRAINT fact_strategy_performance_pkey PRIMARY KEY (id);


--
-- Name: fact_strategy_positions fact_strategy_positions_pkey; Type: CONSTRAINT; Schema: dw; Owner: -
--

ALTER TABLE ONLY dw.fact_strategy_positions
    ADD CONSTRAINT fact_strategy_positions_pkey PRIMARY KEY (id);


--
-- Name: signals_stream signals_stream_pkey; Type: CONSTRAINT; Schema: events; Owner: -
--

ALTER TABLE ONLY events.signals_stream
    ADD CONSTRAINT signals_stream_pkey PRIMARY KEY (timestamp_utc, stream_id);


--
-- Name: model_performance model_performance_pkey; Type: CONSTRAINT; Schema: metrics; Owner: -
--

ALTER TABLE ONLY metrics.model_performance
    ADD CONSTRAINT model_performance_pkey PRIMARY KEY (period_start, model_id, aggregation_type);


--
-- Name: ab_permission ab_permission_name_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_permission
    ADD CONSTRAINT ab_permission_name_uq UNIQUE (name);


--
-- Name: ab_permission ab_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_permission
    ADD CONSTRAINT ab_permission_pkey PRIMARY KEY (id);


--
-- Name: ab_permission_view ab_permission_view_permission_id_view_menu_id_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_permission_view
    ADD CONSTRAINT ab_permission_view_permission_id_view_menu_id_uq UNIQUE (permission_id, view_menu_id);


--
-- Name: ab_permission_view ab_permission_view_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_permission_view
    ADD CONSTRAINT ab_permission_view_pkey PRIMARY KEY (id);


--
-- Name: ab_permission_view_role ab_permission_view_role_permission_view_id_role_id_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_permission_view_role
    ADD CONSTRAINT ab_permission_view_role_permission_view_id_role_id_uq UNIQUE (permission_view_id, role_id);


--
-- Name: ab_permission_view_role ab_permission_view_role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_permission_view_role
    ADD CONSTRAINT ab_permission_view_role_pkey PRIMARY KEY (id);


--
-- Name: ab_register_user ab_register_user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_register_user
    ADD CONSTRAINT ab_register_user_pkey PRIMARY KEY (id);


--
-- Name: ab_register_user ab_register_user_username_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_register_user
    ADD CONSTRAINT ab_register_user_username_uq UNIQUE (username);


--
-- Name: ab_role ab_role_name_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_role
    ADD CONSTRAINT ab_role_name_uq UNIQUE (name);


--
-- Name: ab_role ab_role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_role
    ADD CONSTRAINT ab_role_pkey PRIMARY KEY (id);


--
-- Name: ab_user ab_user_email_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_user
    ADD CONSTRAINT ab_user_email_uq UNIQUE (email);


--
-- Name: ab_user ab_user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_user
    ADD CONSTRAINT ab_user_pkey PRIMARY KEY (id);


--
-- Name: ab_user_role ab_user_role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_user_role
    ADD CONSTRAINT ab_user_role_pkey PRIMARY KEY (id);


--
-- Name: ab_user_role ab_user_role_user_id_role_id_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_user_role
    ADD CONSTRAINT ab_user_role_user_id_role_id_uq UNIQUE (user_id, role_id);


--
-- Name: ab_user ab_user_username_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_user
    ADD CONSTRAINT ab_user_username_uq UNIQUE (username);


--
-- Name: ab_view_menu ab_view_menu_name_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_view_menu
    ADD CONSTRAINT ab_view_menu_name_uq UNIQUE (name);


--
-- Name: ab_view_menu ab_view_menu_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_view_menu
    ADD CONSTRAINT ab_view_menu_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: auth_audit_log auth_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_audit_log
    ADD CONSTRAINT auth_audit_log_pkey PRIMARY KEY (id);


--
-- Name: callback_request callback_request_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.callback_request
    ADD CONSTRAINT callback_request_pkey PRIMARY KEY (id);


--
-- Name: connection connection_conn_id_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connection
    ADD CONSTRAINT connection_conn_id_uq UNIQUE (conn_id);


--
-- Name: connection connection_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connection
    ADD CONSTRAINT connection_pkey PRIMARY KEY (id);


--
-- Name: dag_code dag_code_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dag_code
    ADD CONSTRAINT dag_code_pkey PRIMARY KEY (fileloc_hash);


--
-- Name: dag_owner_attributes dag_owner_attributes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dag_owner_attributes
    ADD CONSTRAINT dag_owner_attributes_pkey PRIMARY KEY (dag_id, owner);


--
-- Name: dag_pickle dag_pickle_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dag_pickle
    ADD CONSTRAINT dag_pickle_pkey PRIMARY KEY (id);


--
-- Name: dag dag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dag
    ADD CONSTRAINT dag_pkey PRIMARY KEY (dag_id);


--
-- Name: dag_run dag_run_dag_id_execution_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dag_run
    ADD CONSTRAINT dag_run_dag_id_execution_date_key UNIQUE (dag_id, execution_date);


--
-- Name: dag_run dag_run_dag_id_run_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dag_run
    ADD CONSTRAINT dag_run_dag_id_run_id_key UNIQUE (dag_id, run_id);


--
-- Name: dag_run_note dag_run_note_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dag_run_note
    ADD CONSTRAINT dag_run_note_pkey PRIMARY KEY (dag_run_id);


--
-- Name: dag_run dag_run_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dag_run
    ADD CONSTRAINT dag_run_pkey PRIMARY KEY (id);


--
-- Name: dag_tag dag_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dag_tag
    ADD CONSTRAINT dag_tag_pkey PRIMARY KEY (name, dag_id);


--
-- Name: dag_warning dag_warning_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dag_warning
    ADD CONSTRAINT dag_warning_pkey PRIMARY KEY (dag_id, warning_type);


--
-- Name: dagrun_dataset_event dagrun_dataset_event_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dagrun_dataset_event
    ADD CONSTRAINT dagrun_dataset_event_pkey PRIMARY KEY (dag_run_id, event_id);


--
-- Name: dataset_event dataset_event_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset_event
    ADD CONSTRAINT dataset_event_pkey PRIMARY KEY (id);


--
-- Name: dataset dataset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset
    ADD CONSTRAINT dataset_pkey PRIMARY KEY (id);


--
-- Name: dataset_dag_run_queue datasetdagrunqueue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset_dag_run_queue
    ADD CONSTRAINT datasetdagrunqueue_pkey PRIMARY KEY (dataset_id, target_dag_id);


--
-- Name: dag_schedule_dataset_reference dsdr_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dag_schedule_dataset_reference
    ADD CONSTRAINT dsdr_pkey PRIMARY KEY (dataset_id, dag_id);


--
-- Name: equity_snapshots equity_snapshots_model_id_timestamp_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equity_snapshots
    ADD CONSTRAINT equity_snapshots_model_id_timestamp_key UNIQUE (model_id, "timestamp");


--
-- Name: equity_snapshots equity_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equity_snapshots
    ADD CONSTRAINT equity_snapshots_pkey PRIMARY KEY (id);


--
-- Name: import_error import_error_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_error
    ADD CONSTRAINT import_error_pkey PRIMARY KEY (id);


--
-- Name: inference_features_5m inference_features_5m_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inference_features_5m
    ADD CONSTRAINT inference_features_5m_pkey PRIMARY KEY ("time");


--
-- Name: job job_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job
    ADD CONSTRAINT job_pkey PRIMARY KEY (id);


--
-- Name: log log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log
    ADD CONSTRAINT log_pkey PRIMARY KEY (id);


--
-- Name: log_template log_template_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.log_template
    ADD CONSTRAINT log_template_pkey PRIMARY KEY (id);


--
-- Name: macro_indicators_daily macro_indicators_daily_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.macro_indicators_daily
    ADD CONSTRAINT macro_indicators_daily_pkey PRIMARY KEY (fecha);


--
-- Name: python_features_5m python_features_5m_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.python_features_5m
    ADD CONSTRAINT python_features_5m_pkey PRIMARY KEY ("time");


--
-- Name: rendered_task_instance_fields rendered_task_instance_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rendered_task_instance_fields
    ADD CONSTRAINT rendered_task_instance_fields_pkey PRIMARY KEY (dag_id, task_id, run_id, map_index);


--
-- Name: serialized_dag serialized_dag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.serialized_dag
    ADD CONSTRAINT serialized_dag_pkey PRIMARY KEY (dag_id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (id);


--
-- Name: session session_session_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_session_id_key UNIQUE (session_id);


--
-- Name: sla_miss sla_miss_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sla_miss
    ADD CONSTRAINT sla_miss_pkey PRIMARY KEY (task_id, dag_id, execution_date);


--
-- Name: slot_pool slot_pool_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slot_pool
    ADD CONSTRAINT slot_pool_pkey PRIMARY KEY (id);


--
-- Name: slot_pool slot_pool_pool_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.slot_pool
    ADD CONSTRAINT slot_pool_pool_uq UNIQUE (pool);


--
-- Name: task_fail task_fail_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_fail
    ADD CONSTRAINT task_fail_pkey PRIMARY KEY (id);


--
-- Name: task_instance_note task_instance_note_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_instance_note
    ADD CONSTRAINT task_instance_note_pkey PRIMARY KEY (task_id, dag_id, run_id, map_index);


--
-- Name: task_instance task_instance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_instance
    ADD CONSTRAINT task_instance_pkey PRIMARY KEY (dag_id, task_id, run_id, map_index);


--
-- Name: task_map task_map_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_map
    ADD CONSTRAINT task_map_pkey PRIMARY KEY (dag_id, task_id, run_id, map_index);


--
-- Name: task_reschedule task_reschedule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_reschedule
    ADD CONSTRAINT task_reschedule_pkey PRIMARY KEY (id);


--
-- Name: task_outlet_dataset_reference todr_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_outlet_dataset_reference
    ADD CONSTRAINT todr_pkey PRIMARY KEY (dataset_id, dag_id, task_id);


--
-- Name: trades_history trades_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trades_history
    ADD CONSTRAINT trades_history_pkey PRIMARY KEY (id);


--
-- Name: trading_metrics trading_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trading_metrics
    ADD CONSTRAINT trading_metrics_pkey PRIMARY KEY ("timestamp", metric_name, metric_type);


--
-- Name: trading_sessions trading_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trading_sessions
    ADD CONSTRAINT trading_sessions_pkey PRIMARY KEY (id);


--
-- Name: trading_state trading_state_model_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trading_state
    ADD CONSTRAINT trading_state_model_id_key UNIQUE (model_id);


--
-- Name: trading_state trading_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trading_state
    ADD CONSTRAINT trading_state_pkey PRIMARY KEY (id);


--
-- Name: trigger trigger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trigger
    ADD CONSTRAINT trigger_pkey PRIMARY KEY (id);


--
-- Name: usdcop_m5_ohlcv usdcop_m5_ohlcv_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usdcop_m5_ohlcv
    ADD CONSTRAINT usdcop_m5_ohlcv_pkey PRIMARY KEY ("time", symbol);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: variable variable_key_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.variable
    ADD CONSTRAINT variable_key_uq UNIQUE (key);


--
-- Name: variable variable_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.variable
    ADD CONSTRAINT variable_pkey PRIMARY KEY (id);


--
-- Name: xcom xcom_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.xcom
    ADD CONSTRAINT xcom_pkey PRIMARY KEY (dag_run_id, task_id, map_index, key);


--
-- Name: model_inferences model_inferences_pkey; Type: CONSTRAINT; Schema: trading; Owner: -
--

ALTER TABLE ONLY trading.model_inferences
    ADD CONSTRAINT model_inferences_pkey PRIMARY KEY (timestamp_utc, inference_id);


--
-- Name: model_states model_states_pkey; Type: CONSTRAINT; Schema: trading; Owner: -
--

ALTER TABLE ONLY trading.model_states
    ADD CONSTRAINT model_states_pkey PRIMARY KEY (model_id);


--
-- Name: model_trades model_trades_pkey; Type: CONSTRAINT; Schema: trading; Owner: -
--

ALTER TABLE ONLY trading.model_trades
    ADD CONSTRAINT model_trades_pkey PRIMARY KEY (trade_id);


--
-- Name: _hyper_1_100_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_100_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_100_chunk USING btree (close);


--
-- Name: _hyper_1_100_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_100_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_100_chunk USING btree (source);


--
-- Name: _hyper_1_100_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_100_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_100_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_100_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_100_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_100_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_101_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_101_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_101_chunk USING btree (close);


--
-- Name: _hyper_1_101_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_101_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_101_chunk USING btree (source);


--
-- Name: _hyper_1_101_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_101_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_101_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_101_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_101_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_101_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_102_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_102_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_102_chunk USING btree (close);


--
-- Name: _hyper_1_102_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_102_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_102_chunk USING btree (source);


--
-- Name: _hyper_1_102_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_102_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_102_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_102_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_102_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_102_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_103_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_103_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_103_chunk USING btree (close);


--
-- Name: _hyper_1_103_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_103_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_103_chunk USING btree (source);


--
-- Name: _hyper_1_103_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_103_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_103_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_103_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_103_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_103_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_104_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_104_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_104_chunk USING btree (close);


--
-- Name: _hyper_1_104_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_104_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_104_chunk USING btree (source);


--
-- Name: _hyper_1_104_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_104_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_104_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_104_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_104_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_104_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_105_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_105_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_105_chunk USING btree (close);


--
-- Name: _hyper_1_105_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_105_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_105_chunk USING btree (source);


--
-- Name: _hyper_1_105_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_105_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_105_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_105_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_105_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_105_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_106_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_106_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_106_chunk USING btree (close);


--
-- Name: _hyper_1_106_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_106_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_106_chunk USING btree (source);


--
-- Name: _hyper_1_106_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_106_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_106_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_106_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_106_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_106_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_107_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_107_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_107_chunk USING btree (close);


--
-- Name: _hyper_1_107_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_107_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_107_chunk USING btree (source);


--
-- Name: _hyper_1_107_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_107_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_107_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_107_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_107_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_107_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_108_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_108_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_108_chunk USING btree (close);


--
-- Name: _hyper_1_108_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_108_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_108_chunk USING btree (source);


--
-- Name: _hyper_1_108_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_108_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_108_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_108_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_108_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_108_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_109_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_109_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_109_chunk USING btree (close);


--
-- Name: _hyper_1_109_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_109_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_109_chunk USING btree (source);


--
-- Name: _hyper_1_109_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_109_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_109_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_109_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_109_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_109_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_10_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_10_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_10_chunk USING btree (close);


--
-- Name: _hyper_1_10_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_10_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_10_chunk USING btree (source);


--
-- Name: _hyper_1_10_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_10_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_10_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_10_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_10_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_10_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_110_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_110_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_110_chunk USING btree (close);


--
-- Name: _hyper_1_110_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_110_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_110_chunk USING btree (source);


--
-- Name: _hyper_1_110_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_110_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_110_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_110_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_110_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_110_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_111_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_111_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_111_chunk USING btree (close);


--
-- Name: _hyper_1_111_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_111_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_111_chunk USING btree (source);


--
-- Name: _hyper_1_111_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_111_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_111_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_111_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_111_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_111_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_112_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_112_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_112_chunk USING btree (close);


--
-- Name: _hyper_1_112_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_112_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_112_chunk USING btree (source);


--
-- Name: _hyper_1_112_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_112_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_112_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_112_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_112_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_112_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_113_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_113_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_113_chunk USING btree (close);


--
-- Name: _hyper_1_113_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_113_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_113_chunk USING btree (source);


--
-- Name: _hyper_1_113_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_113_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_113_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_113_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_113_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_113_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_114_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_114_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_114_chunk USING btree (close);


--
-- Name: _hyper_1_114_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_114_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_114_chunk USING btree (source);


--
-- Name: _hyper_1_114_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_114_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_114_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_114_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_114_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_114_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_115_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_115_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_115_chunk USING btree (close);


--
-- Name: _hyper_1_115_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_115_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_115_chunk USING btree (source);


--
-- Name: _hyper_1_115_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_115_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_115_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_115_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_115_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_115_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_116_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_116_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_116_chunk USING btree (close);


--
-- Name: _hyper_1_116_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_116_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_116_chunk USING btree (source);


--
-- Name: _hyper_1_116_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_116_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_116_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_116_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_116_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_116_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_117_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_117_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_117_chunk USING btree (close);


--
-- Name: _hyper_1_117_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_117_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_117_chunk USING btree (source);


--
-- Name: _hyper_1_117_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_117_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_117_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_117_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_117_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_117_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_118_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_118_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_118_chunk USING btree (close);


--
-- Name: _hyper_1_118_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_118_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_118_chunk USING btree (source);


--
-- Name: _hyper_1_118_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_118_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_118_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_118_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_118_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_118_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_119_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_119_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_119_chunk USING btree (close);


--
-- Name: _hyper_1_119_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_119_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_119_chunk USING btree (source);


--
-- Name: _hyper_1_119_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_119_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_119_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_119_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_119_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_119_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_11_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_11_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_11_chunk USING btree (close);


--
-- Name: _hyper_1_11_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_11_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_11_chunk USING btree (source);


--
-- Name: _hyper_1_11_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_11_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_11_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_11_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_11_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_11_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_120_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_120_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_120_chunk USING btree (close);


--
-- Name: _hyper_1_120_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_120_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_120_chunk USING btree (source);


--
-- Name: _hyper_1_120_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_120_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_120_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_120_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_120_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_120_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_121_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_121_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_121_chunk USING btree (close);


--
-- Name: _hyper_1_121_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_121_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_121_chunk USING btree (source);


--
-- Name: _hyper_1_121_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_121_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_121_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_121_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_121_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_121_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_122_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_122_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_122_chunk USING btree (close);


--
-- Name: _hyper_1_122_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_122_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_122_chunk USING btree (source);


--
-- Name: _hyper_1_122_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_122_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_122_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_122_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_122_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_122_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_123_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_123_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_123_chunk USING btree (close);


--
-- Name: _hyper_1_123_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_123_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_123_chunk USING btree (source);


--
-- Name: _hyper_1_123_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_123_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_123_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_123_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_123_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_123_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_124_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_124_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_124_chunk USING btree (close);


--
-- Name: _hyper_1_124_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_124_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_124_chunk USING btree (source);


--
-- Name: _hyper_1_124_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_124_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_124_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_124_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_124_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_124_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_125_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_125_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_125_chunk USING btree (close);


--
-- Name: _hyper_1_125_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_125_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_125_chunk USING btree (source);


--
-- Name: _hyper_1_125_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_125_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_125_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_125_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_125_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_125_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_126_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_126_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_126_chunk USING btree (close);


--
-- Name: _hyper_1_126_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_126_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_126_chunk USING btree (source);


--
-- Name: _hyper_1_126_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_126_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_126_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_126_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_126_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_126_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_127_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_127_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_127_chunk USING btree (close);


--
-- Name: _hyper_1_127_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_127_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_127_chunk USING btree (source);


--
-- Name: _hyper_1_127_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_127_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_127_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_127_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_127_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_127_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_128_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_128_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_128_chunk USING btree (close);


--
-- Name: _hyper_1_128_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_128_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_128_chunk USING btree (source);


--
-- Name: _hyper_1_128_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_128_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_128_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_128_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_128_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_128_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_129_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_129_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_129_chunk USING btree (close);


--
-- Name: _hyper_1_129_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_129_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_129_chunk USING btree (source);


--
-- Name: _hyper_1_129_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_129_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_129_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_129_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_129_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_129_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_12_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_12_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_12_chunk USING btree (close);


--
-- Name: _hyper_1_12_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_12_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_12_chunk USING btree (source);


--
-- Name: _hyper_1_12_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_12_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_12_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_12_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_12_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_12_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_130_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_130_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_130_chunk USING btree (close);


--
-- Name: _hyper_1_130_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_130_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_130_chunk USING btree (source);


--
-- Name: _hyper_1_130_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_130_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_130_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_130_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_130_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_130_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_131_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_131_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_131_chunk USING btree (close);


--
-- Name: _hyper_1_131_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_131_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_131_chunk USING btree (source);


--
-- Name: _hyper_1_131_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_131_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_131_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_131_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_131_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_131_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_132_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_132_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_132_chunk USING btree (close);


--
-- Name: _hyper_1_132_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_132_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_132_chunk USING btree (source);


--
-- Name: _hyper_1_132_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_132_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_132_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_132_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_132_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_132_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_133_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_133_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_133_chunk USING btree (close);


--
-- Name: _hyper_1_133_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_133_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_133_chunk USING btree (source);


--
-- Name: _hyper_1_133_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_133_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_133_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_133_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_133_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_133_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_134_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_134_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_134_chunk USING btree (close);


--
-- Name: _hyper_1_134_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_134_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_134_chunk USING btree (source);


--
-- Name: _hyper_1_134_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_134_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_134_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_134_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_134_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_134_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_135_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_135_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_135_chunk USING btree (close);


--
-- Name: _hyper_1_135_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_135_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_135_chunk USING btree (source);


--
-- Name: _hyper_1_135_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_135_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_135_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_135_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_135_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_135_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_136_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_136_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_136_chunk USING btree (close);


--
-- Name: _hyper_1_136_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_136_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_136_chunk USING btree (source);


--
-- Name: _hyper_1_136_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_136_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_136_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_136_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_136_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_136_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_137_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_137_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_137_chunk USING btree (close);


--
-- Name: _hyper_1_137_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_137_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_137_chunk USING btree (source);


--
-- Name: _hyper_1_137_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_137_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_137_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_137_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_137_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_137_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_138_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_138_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_138_chunk USING btree (close);


--
-- Name: _hyper_1_138_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_138_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_138_chunk USING btree (source);


--
-- Name: _hyper_1_138_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_138_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_138_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_138_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_138_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_138_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_139_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_139_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_139_chunk USING btree (close);


--
-- Name: _hyper_1_139_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_139_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_139_chunk USING btree (source);


--
-- Name: _hyper_1_139_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_139_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_139_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_139_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_139_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_139_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_13_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_13_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_13_chunk USING btree (close);


--
-- Name: _hyper_1_13_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_13_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_13_chunk USING btree (source);


--
-- Name: _hyper_1_13_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_13_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_13_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_13_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_13_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_13_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_140_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_140_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_140_chunk USING btree (close);


--
-- Name: _hyper_1_140_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_140_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_140_chunk USING btree (source);


--
-- Name: _hyper_1_140_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_140_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_140_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_140_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_140_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_140_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_141_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_141_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_141_chunk USING btree (close);


--
-- Name: _hyper_1_141_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_141_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_141_chunk USING btree (source);


--
-- Name: _hyper_1_141_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_141_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_141_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_141_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_141_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_141_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_142_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_142_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_142_chunk USING btree (close);


--
-- Name: _hyper_1_142_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_142_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_142_chunk USING btree (source);


--
-- Name: _hyper_1_142_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_142_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_142_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_142_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_142_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_142_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_143_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_143_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_143_chunk USING btree (close);


--
-- Name: _hyper_1_143_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_143_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_143_chunk USING btree (source);


--
-- Name: _hyper_1_143_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_143_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_143_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_143_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_143_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_143_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_144_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_144_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_144_chunk USING btree (close);


--
-- Name: _hyper_1_144_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_144_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_144_chunk USING btree (source);


--
-- Name: _hyper_1_144_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_144_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_144_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_144_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_144_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_144_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_145_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_145_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_145_chunk USING btree (close);


--
-- Name: _hyper_1_145_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_145_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_145_chunk USING btree (source);


--
-- Name: _hyper_1_145_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_145_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_145_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_145_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_145_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_145_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_146_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_146_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_146_chunk USING btree (close);


--
-- Name: _hyper_1_146_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_146_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_146_chunk USING btree (source);


--
-- Name: _hyper_1_146_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_146_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_146_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_146_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_146_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_146_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_147_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_147_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_147_chunk USING btree (close);


--
-- Name: _hyper_1_147_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_147_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_147_chunk USING btree (source);


--
-- Name: _hyper_1_147_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_147_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_147_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_147_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_147_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_147_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_148_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_148_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_148_chunk USING btree (close);


--
-- Name: _hyper_1_148_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_148_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_148_chunk USING btree (source);


--
-- Name: _hyper_1_148_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_148_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_148_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_148_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_148_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_148_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_149_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_149_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_149_chunk USING btree (close);


--
-- Name: _hyper_1_149_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_149_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_149_chunk USING btree (source);


--
-- Name: _hyper_1_149_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_149_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_149_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_149_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_149_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_149_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_14_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_14_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_14_chunk USING btree (close);


--
-- Name: _hyper_1_14_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_14_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_14_chunk USING btree (source);


--
-- Name: _hyper_1_14_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_14_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_14_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_14_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_14_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_14_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_150_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_150_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_150_chunk USING btree (close);


--
-- Name: _hyper_1_150_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_150_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_150_chunk USING btree (source);


--
-- Name: _hyper_1_150_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_150_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_150_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_150_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_150_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_150_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_151_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_151_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_151_chunk USING btree (close);


--
-- Name: _hyper_1_151_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_151_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_151_chunk USING btree (source);


--
-- Name: _hyper_1_151_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_151_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_151_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_151_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_151_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_151_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_152_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_152_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_152_chunk USING btree (close);


--
-- Name: _hyper_1_152_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_152_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_152_chunk USING btree (source);


--
-- Name: _hyper_1_152_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_152_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_152_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_152_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_152_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_152_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_153_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_153_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_153_chunk USING btree (close);


--
-- Name: _hyper_1_153_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_153_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_153_chunk USING btree (source);


--
-- Name: _hyper_1_153_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_153_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_153_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_153_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_153_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_153_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_154_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_154_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_154_chunk USING btree (close);


--
-- Name: _hyper_1_154_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_154_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_154_chunk USING btree (source);


--
-- Name: _hyper_1_154_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_154_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_154_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_154_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_154_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_154_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_155_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_155_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_155_chunk USING btree (close);


--
-- Name: _hyper_1_155_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_155_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_155_chunk USING btree (source);


--
-- Name: _hyper_1_155_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_155_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_155_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_155_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_155_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_155_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_156_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_156_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_156_chunk USING btree (close);


--
-- Name: _hyper_1_156_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_156_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_156_chunk USING btree (source);


--
-- Name: _hyper_1_156_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_156_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_156_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_156_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_156_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_156_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_157_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_157_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_157_chunk USING btree (close);


--
-- Name: _hyper_1_157_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_157_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_157_chunk USING btree (source);


--
-- Name: _hyper_1_157_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_157_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_157_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_157_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_157_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_157_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_158_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_158_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_158_chunk USING btree (close);


--
-- Name: _hyper_1_158_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_158_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_158_chunk USING btree (source);


--
-- Name: _hyper_1_158_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_158_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_158_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_158_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_158_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_158_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_159_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_159_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_159_chunk USING btree (close);


--
-- Name: _hyper_1_159_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_159_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_159_chunk USING btree (source);


--
-- Name: _hyper_1_159_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_159_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_159_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_159_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_159_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_159_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_15_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_15_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_15_chunk USING btree (close);


--
-- Name: _hyper_1_15_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_15_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_15_chunk USING btree (source);


--
-- Name: _hyper_1_15_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_15_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_15_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_15_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_15_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_15_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_160_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_160_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_160_chunk USING btree (close);


--
-- Name: _hyper_1_160_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_160_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_160_chunk USING btree (source);


--
-- Name: _hyper_1_160_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_160_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_160_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_160_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_160_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_160_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_161_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_161_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_161_chunk USING btree (close);


--
-- Name: _hyper_1_161_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_161_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_161_chunk USING btree (source);


--
-- Name: _hyper_1_161_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_161_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_161_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_161_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_161_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_161_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_162_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_162_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_162_chunk USING btree (close);


--
-- Name: _hyper_1_162_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_162_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_162_chunk USING btree (source);


--
-- Name: _hyper_1_162_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_162_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_162_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_162_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_162_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_162_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_163_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_163_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_163_chunk USING btree (close);


--
-- Name: _hyper_1_163_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_163_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_163_chunk USING btree (source);


--
-- Name: _hyper_1_163_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_163_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_163_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_163_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_163_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_163_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_164_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_164_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_164_chunk USING btree (close);


--
-- Name: _hyper_1_164_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_164_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_164_chunk USING btree (source);


--
-- Name: _hyper_1_164_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_164_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_164_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_164_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_164_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_164_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_165_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_165_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_165_chunk USING btree (close);


--
-- Name: _hyper_1_165_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_165_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_165_chunk USING btree (source);


--
-- Name: _hyper_1_165_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_165_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_165_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_165_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_165_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_165_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_166_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_166_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_166_chunk USING btree (close);


--
-- Name: _hyper_1_166_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_166_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_166_chunk USING btree (source);


--
-- Name: _hyper_1_166_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_166_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_166_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_166_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_166_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_166_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_167_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_167_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_167_chunk USING btree (close);


--
-- Name: _hyper_1_167_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_167_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_167_chunk USING btree (source);


--
-- Name: _hyper_1_167_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_167_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_167_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_167_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_167_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_167_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_168_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_168_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_168_chunk USING btree (close);


--
-- Name: _hyper_1_168_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_168_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_168_chunk USING btree (source);


--
-- Name: _hyper_1_168_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_168_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_168_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_168_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_168_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_168_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_169_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_169_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_169_chunk USING btree (close);


--
-- Name: _hyper_1_169_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_169_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_169_chunk USING btree (source);


--
-- Name: _hyper_1_169_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_169_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_169_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_169_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_169_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_169_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_16_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_16_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_16_chunk USING btree (close);


--
-- Name: _hyper_1_16_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_16_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_16_chunk USING btree (source);


--
-- Name: _hyper_1_16_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_16_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_16_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_16_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_16_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_16_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_170_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_170_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_170_chunk USING btree (close);


--
-- Name: _hyper_1_170_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_170_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_170_chunk USING btree (source);


--
-- Name: _hyper_1_170_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_170_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_170_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_170_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_170_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_170_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_171_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_171_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_171_chunk USING btree (close);


--
-- Name: _hyper_1_171_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_171_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_171_chunk USING btree (source);


--
-- Name: _hyper_1_171_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_171_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_171_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_171_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_171_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_171_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_172_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_172_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_172_chunk USING btree (close);


--
-- Name: _hyper_1_172_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_172_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_172_chunk USING btree (source);


--
-- Name: _hyper_1_172_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_172_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_172_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_172_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_172_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_172_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_173_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_173_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_173_chunk USING btree (close);


--
-- Name: _hyper_1_173_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_173_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_173_chunk USING btree (source);


--
-- Name: _hyper_1_173_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_173_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_173_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_173_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_173_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_173_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_174_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_174_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_174_chunk USING btree (close);


--
-- Name: _hyper_1_174_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_174_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_174_chunk USING btree (source);


--
-- Name: _hyper_1_174_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_174_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_174_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_174_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_174_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_174_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_175_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_175_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_175_chunk USING btree (close);


--
-- Name: _hyper_1_175_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_175_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_175_chunk USING btree (source);


--
-- Name: _hyper_1_175_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_175_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_175_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_175_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_175_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_175_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_176_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_176_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_176_chunk USING btree (close);


--
-- Name: _hyper_1_176_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_176_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_176_chunk USING btree (source);


--
-- Name: _hyper_1_176_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_176_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_176_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_176_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_176_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_176_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_177_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_177_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_177_chunk USING btree (close);


--
-- Name: _hyper_1_177_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_177_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_177_chunk USING btree (source);


--
-- Name: _hyper_1_177_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_177_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_177_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_177_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_177_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_177_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_178_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_178_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_178_chunk USING btree (close);


--
-- Name: _hyper_1_178_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_178_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_178_chunk USING btree (source);


--
-- Name: _hyper_1_178_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_178_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_178_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_178_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_178_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_178_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_179_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_179_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_179_chunk USING btree (close);


--
-- Name: _hyper_1_179_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_179_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_179_chunk USING btree (source);


--
-- Name: _hyper_1_179_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_179_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_179_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_179_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_179_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_179_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_17_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_17_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_17_chunk USING btree (close);


--
-- Name: _hyper_1_17_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_17_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_17_chunk USING btree (source);


--
-- Name: _hyper_1_17_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_17_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_17_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_17_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_17_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_17_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_180_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_180_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_180_chunk USING btree (close);


--
-- Name: _hyper_1_180_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_180_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_180_chunk USING btree (source);


--
-- Name: _hyper_1_180_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_180_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_180_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_180_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_180_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_180_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_181_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_181_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_181_chunk USING btree (close);


--
-- Name: _hyper_1_181_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_181_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_181_chunk USING btree (source);


--
-- Name: _hyper_1_181_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_181_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_181_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_181_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_181_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_181_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_182_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_182_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_182_chunk USING btree (close);


--
-- Name: _hyper_1_182_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_182_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_182_chunk USING btree (source);


--
-- Name: _hyper_1_182_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_182_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_182_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_182_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_182_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_182_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_183_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_183_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_183_chunk USING btree (close);


--
-- Name: _hyper_1_183_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_183_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_183_chunk USING btree (source);


--
-- Name: _hyper_1_183_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_183_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_183_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_183_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_183_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_183_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_184_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_184_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_184_chunk USING btree (close);


--
-- Name: _hyper_1_184_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_184_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_184_chunk USING btree (source);


--
-- Name: _hyper_1_184_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_184_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_184_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_184_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_184_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_184_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_185_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_185_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_185_chunk USING btree (close);


--
-- Name: _hyper_1_185_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_185_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_185_chunk USING btree (source);


--
-- Name: _hyper_1_185_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_185_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_185_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_185_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_185_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_185_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_186_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_186_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_186_chunk USING btree (close);


--
-- Name: _hyper_1_186_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_186_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_186_chunk USING btree (source);


--
-- Name: _hyper_1_186_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_186_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_186_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_186_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_186_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_186_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_187_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_187_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_187_chunk USING btree (close);


--
-- Name: _hyper_1_187_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_187_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_187_chunk USING btree (source);


--
-- Name: _hyper_1_187_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_187_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_187_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_187_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_187_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_187_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_188_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_188_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_188_chunk USING btree (close);


--
-- Name: _hyper_1_188_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_188_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_188_chunk USING btree (source);


--
-- Name: _hyper_1_188_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_188_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_188_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_188_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_188_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_188_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_189_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_189_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_189_chunk USING btree (close);


--
-- Name: _hyper_1_189_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_189_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_189_chunk USING btree (source);


--
-- Name: _hyper_1_189_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_189_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_189_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_189_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_189_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_189_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_18_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_18_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_18_chunk USING btree (close);


--
-- Name: _hyper_1_18_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_18_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_18_chunk USING btree (source);


--
-- Name: _hyper_1_18_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_18_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_18_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_18_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_18_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_18_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_190_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_190_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_190_chunk USING btree (close);


--
-- Name: _hyper_1_190_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_190_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_190_chunk USING btree (source);


--
-- Name: _hyper_1_190_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_190_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_190_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_190_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_190_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_190_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_191_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_191_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_191_chunk USING btree (close);


--
-- Name: _hyper_1_191_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_191_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_191_chunk USING btree (source);


--
-- Name: _hyper_1_191_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_191_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_191_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_191_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_191_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_191_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_192_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_192_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_192_chunk USING btree (close);


--
-- Name: _hyper_1_192_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_192_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_192_chunk USING btree (source);


--
-- Name: _hyper_1_192_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_192_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_192_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_192_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_192_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_192_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_193_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_193_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_193_chunk USING btree (close);


--
-- Name: _hyper_1_193_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_193_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_193_chunk USING btree (source);


--
-- Name: _hyper_1_193_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_193_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_193_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_193_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_193_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_193_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_194_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_194_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_194_chunk USING btree (close);


--
-- Name: _hyper_1_194_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_194_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_194_chunk USING btree (source);


--
-- Name: _hyper_1_194_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_194_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_194_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_194_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_194_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_194_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_195_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_195_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_195_chunk USING btree (close);


--
-- Name: _hyper_1_195_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_195_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_195_chunk USING btree (source);


--
-- Name: _hyper_1_195_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_195_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_195_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_195_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_195_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_195_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_196_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_196_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_196_chunk USING btree (close);


--
-- Name: _hyper_1_196_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_196_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_196_chunk USING btree (source);


--
-- Name: _hyper_1_196_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_196_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_196_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_196_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_196_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_196_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_197_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_197_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_197_chunk USING btree (close);


--
-- Name: _hyper_1_197_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_197_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_197_chunk USING btree (source);


--
-- Name: _hyper_1_197_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_197_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_197_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_197_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_197_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_197_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_198_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_198_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_198_chunk USING btree (close);


--
-- Name: _hyper_1_198_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_198_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_198_chunk USING btree (source);


--
-- Name: _hyper_1_198_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_198_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_198_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_198_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_198_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_198_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_199_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_199_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_199_chunk USING btree (close);


--
-- Name: _hyper_1_199_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_199_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_199_chunk USING btree (source);


--
-- Name: _hyper_1_199_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_199_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_199_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_199_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_199_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_199_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_19_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_19_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_19_chunk USING btree (close);


--
-- Name: _hyper_1_19_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_19_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_19_chunk USING btree (source);


--
-- Name: _hyper_1_19_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_19_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_19_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_19_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_19_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_19_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_200_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_200_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_200_chunk USING btree (close);


--
-- Name: _hyper_1_200_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_200_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_200_chunk USING btree (source);


--
-- Name: _hyper_1_200_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_200_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_200_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_200_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_200_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_200_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_201_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_201_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_201_chunk USING btree (close);


--
-- Name: _hyper_1_201_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_201_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_201_chunk USING btree (source);


--
-- Name: _hyper_1_201_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_201_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_201_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_201_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_201_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_201_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_202_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_202_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_202_chunk USING btree (close);


--
-- Name: _hyper_1_202_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_202_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_202_chunk USING btree (source);


--
-- Name: _hyper_1_202_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_202_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_202_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_202_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_202_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_202_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_203_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_203_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_203_chunk USING btree (close);


--
-- Name: _hyper_1_203_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_203_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_203_chunk USING btree (source);


--
-- Name: _hyper_1_203_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_203_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_203_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_203_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_203_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_203_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_204_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_204_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_204_chunk USING btree (close);


--
-- Name: _hyper_1_204_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_204_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_204_chunk USING btree (source);


--
-- Name: _hyper_1_204_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_204_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_204_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_204_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_204_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_204_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_205_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_205_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_205_chunk USING btree (close);


--
-- Name: _hyper_1_205_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_205_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_205_chunk USING btree (source);


--
-- Name: _hyper_1_205_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_205_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_205_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_205_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_205_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_205_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_206_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_206_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_206_chunk USING btree (close);


--
-- Name: _hyper_1_206_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_206_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_206_chunk USING btree (source);


--
-- Name: _hyper_1_206_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_206_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_206_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_206_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_206_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_206_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_207_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_207_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_207_chunk USING btree (close);


--
-- Name: _hyper_1_207_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_207_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_207_chunk USING btree (source);


--
-- Name: _hyper_1_207_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_207_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_207_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_207_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_207_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_207_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_208_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_208_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_208_chunk USING btree (close);


--
-- Name: _hyper_1_208_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_208_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_208_chunk USING btree (source);


--
-- Name: _hyper_1_208_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_208_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_208_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_208_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_208_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_208_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_209_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_209_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_209_chunk USING btree (close);


--
-- Name: _hyper_1_209_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_209_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_209_chunk USING btree (source);


--
-- Name: _hyper_1_209_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_209_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_209_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_209_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_209_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_209_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_20_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_20_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_20_chunk USING btree (close);


--
-- Name: _hyper_1_20_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_20_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_20_chunk USING btree (source);


--
-- Name: _hyper_1_20_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_20_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_20_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_20_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_20_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_20_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_210_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_210_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_210_chunk USING btree (close);


--
-- Name: _hyper_1_210_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_210_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_210_chunk USING btree (source);


--
-- Name: _hyper_1_210_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_210_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_210_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_210_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_210_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_210_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_211_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_211_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_211_chunk USING btree (close);


--
-- Name: _hyper_1_211_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_211_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_211_chunk USING btree (source);


--
-- Name: _hyper_1_211_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_211_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_211_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_211_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_211_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_211_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_212_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_212_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_212_chunk USING btree (close);


--
-- Name: _hyper_1_212_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_212_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_212_chunk USING btree (source);


--
-- Name: _hyper_1_212_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_212_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_212_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_212_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_212_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_212_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_213_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_213_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_213_chunk USING btree (close);


--
-- Name: _hyper_1_213_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_213_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_213_chunk USING btree (source);


--
-- Name: _hyper_1_213_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_213_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_213_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_213_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_213_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_213_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_214_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_214_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_214_chunk USING btree (close);


--
-- Name: _hyper_1_214_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_214_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_214_chunk USING btree (source);


--
-- Name: _hyper_1_214_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_214_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_214_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_214_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_214_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_214_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_215_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_215_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_215_chunk USING btree (close);


--
-- Name: _hyper_1_215_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_215_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_215_chunk USING btree (source);


--
-- Name: _hyper_1_215_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_215_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_215_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_215_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_215_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_215_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_216_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_216_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_216_chunk USING btree (close);


--
-- Name: _hyper_1_216_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_216_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_216_chunk USING btree (source);


--
-- Name: _hyper_1_216_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_216_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_216_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_216_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_216_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_216_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_217_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_217_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_217_chunk USING btree (close);


--
-- Name: _hyper_1_217_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_217_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_217_chunk USING btree (source);


--
-- Name: _hyper_1_217_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_217_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_217_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_217_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_217_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_217_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_218_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_218_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_218_chunk USING btree (close);


--
-- Name: _hyper_1_218_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_218_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_218_chunk USING btree (source);


--
-- Name: _hyper_1_218_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_218_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_218_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_218_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_218_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_218_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_219_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_219_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_219_chunk USING btree (close);


--
-- Name: _hyper_1_219_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_219_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_219_chunk USING btree (source);


--
-- Name: _hyper_1_219_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_219_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_219_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_219_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_219_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_219_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_21_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_21_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_21_chunk USING btree (close);


--
-- Name: _hyper_1_21_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_21_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_21_chunk USING btree (source);


--
-- Name: _hyper_1_21_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_21_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_21_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_21_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_21_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_21_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_220_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_220_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_220_chunk USING btree (close);


--
-- Name: _hyper_1_220_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_220_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_220_chunk USING btree (source);


--
-- Name: _hyper_1_220_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_220_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_220_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_220_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_220_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_220_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_221_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_221_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_221_chunk USING btree (close);


--
-- Name: _hyper_1_221_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_221_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_221_chunk USING btree (source);


--
-- Name: _hyper_1_221_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_221_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_221_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_221_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_221_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_221_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_222_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_222_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_222_chunk USING btree (close);


--
-- Name: _hyper_1_222_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_222_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_222_chunk USING btree (source);


--
-- Name: _hyper_1_222_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_222_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_222_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_222_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_222_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_222_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_223_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_223_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_223_chunk USING btree (close);


--
-- Name: _hyper_1_223_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_223_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_223_chunk USING btree (source);


--
-- Name: _hyper_1_223_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_223_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_223_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_223_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_223_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_223_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_224_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_224_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_224_chunk USING btree (close);


--
-- Name: _hyper_1_224_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_224_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_224_chunk USING btree (source);


--
-- Name: _hyper_1_224_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_224_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_224_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_224_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_224_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_224_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_225_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_225_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_225_chunk USING btree (close);


--
-- Name: _hyper_1_225_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_225_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_225_chunk USING btree (source);


--
-- Name: _hyper_1_225_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_225_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_225_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_225_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_225_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_225_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_226_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_226_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_226_chunk USING btree (close);


--
-- Name: _hyper_1_226_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_226_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_226_chunk USING btree (source);


--
-- Name: _hyper_1_226_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_226_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_226_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_226_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_226_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_226_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_227_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_227_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_227_chunk USING btree (close);


--
-- Name: _hyper_1_227_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_227_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_227_chunk USING btree (source);


--
-- Name: _hyper_1_227_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_227_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_227_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_227_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_227_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_227_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_228_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_228_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_228_chunk USING btree (close);


--
-- Name: _hyper_1_228_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_228_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_228_chunk USING btree (source);


--
-- Name: _hyper_1_228_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_228_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_228_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_228_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_228_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_228_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_229_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_229_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_229_chunk USING btree (close);


--
-- Name: _hyper_1_229_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_229_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_229_chunk USING btree (source);


--
-- Name: _hyper_1_229_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_229_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_229_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_229_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_229_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_229_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_22_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_22_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_22_chunk USING btree (close);


--
-- Name: _hyper_1_22_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_22_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_22_chunk USING btree (source);


--
-- Name: _hyper_1_22_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_22_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_22_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_22_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_22_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_22_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_230_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_230_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_230_chunk USING btree (close);


--
-- Name: _hyper_1_230_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_230_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_230_chunk USING btree (source);


--
-- Name: _hyper_1_230_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_230_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_230_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_230_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_230_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_230_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_231_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_231_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_231_chunk USING btree (close);


--
-- Name: _hyper_1_231_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_231_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_231_chunk USING btree (source);


--
-- Name: _hyper_1_231_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_231_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_231_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_231_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_231_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_231_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_232_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_232_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_232_chunk USING btree (close);


--
-- Name: _hyper_1_232_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_232_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_232_chunk USING btree (source);


--
-- Name: _hyper_1_232_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_232_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_232_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_232_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_232_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_232_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_233_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_233_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_233_chunk USING btree (close);


--
-- Name: _hyper_1_233_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_233_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_233_chunk USING btree (source);


--
-- Name: _hyper_1_233_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_233_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_233_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_233_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_233_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_233_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_234_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_234_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_234_chunk USING btree (close);


--
-- Name: _hyper_1_234_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_234_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_234_chunk USING btree (source);


--
-- Name: _hyper_1_234_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_234_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_234_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_234_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_234_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_234_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_235_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_235_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_235_chunk USING btree (close);


--
-- Name: _hyper_1_235_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_235_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_235_chunk USING btree (source);


--
-- Name: _hyper_1_235_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_235_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_235_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_235_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_235_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_235_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_236_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_236_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_236_chunk USING btree (close);


--
-- Name: _hyper_1_236_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_236_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_236_chunk USING btree (source);


--
-- Name: _hyper_1_236_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_236_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_236_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_236_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_236_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_236_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_237_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_237_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_237_chunk USING btree (close);


--
-- Name: _hyper_1_237_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_237_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_237_chunk USING btree (source);


--
-- Name: _hyper_1_237_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_237_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_237_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_237_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_237_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_237_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_238_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_238_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_238_chunk USING btree (close);


--
-- Name: _hyper_1_238_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_238_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_238_chunk USING btree (source);


--
-- Name: _hyper_1_238_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_238_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_238_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_238_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_238_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_238_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_239_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_239_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_239_chunk USING btree (close);


--
-- Name: _hyper_1_239_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_239_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_239_chunk USING btree (source);


--
-- Name: _hyper_1_239_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_239_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_239_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_239_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_239_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_239_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_23_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_23_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_23_chunk USING btree (close);


--
-- Name: _hyper_1_23_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_23_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_23_chunk USING btree (source);


--
-- Name: _hyper_1_23_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_23_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_23_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_23_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_23_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_23_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_240_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_240_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_240_chunk USING btree (close);


--
-- Name: _hyper_1_240_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_240_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_240_chunk USING btree (source);


--
-- Name: _hyper_1_240_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_240_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_240_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_240_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_240_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_240_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_241_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_241_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_241_chunk USING btree (close);


--
-- Name: _hyper_1_241_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_241_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_241_chunk USING btree (source);


--
-- Name: _hyper_1_241_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_241_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_241_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_241_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_241_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_241_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_242_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_242_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_242_chunk USING btree (close);


--
-- Name: _hyper_1_242_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_242_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_242_chunk USING btree (source);


--
-- Name: _hyper_1_242_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_242_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_242_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_242_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_242_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_242_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_243_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_243_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_243_chunk USING btree (close);


--
-- Name: _hyper_1_243_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_243_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_243_chunk USING btree (source);


--
-- Name: _hyper_1_243_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_243_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_243_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_243_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_243_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_243_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_244_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_244_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_244_chunk USING btree (close);


--
-- Name: _hyper_1_244_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_244_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_244_chunk USING btree (source);


--
-- Name: _hyper_1_244_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_244_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_244_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_244_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_244_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_244_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_245_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_245_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_245_chunk USING btree (close);


--
-- Name: _hyper_1_245_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_245_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_245_chunk USING btree (source);


--
-- Name: _hyper_1_245_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_245_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_245_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_245_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_245_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_245_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_246_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_246_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_246_chunk USING btree (close);


--
-- Name: _hyper_1_246_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_246_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_246_chunk USING btree (source);


--
-- Name: _hyper_1_246_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_246_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_246_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_246_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_246_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_246_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_247_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_247_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_247_chunk USING btree (close);


--
-- Name: _hyper_1_247_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_247_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_247_chunk USING btree (source);


--
-- Name: _hyper_1_247_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_247_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_247_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_247_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_247_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_247_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_248_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_248_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_248_chunk USING btree (close);


--
-- Name: _hyper_1_248_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_248_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_248_chunk USING btree (source);


--
-- Name: _hyper_1_248_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_248_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_248_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_248_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_248_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_248_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_249_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_249_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_249_chunk USING btree (close);


--
-- Name: _hyper_1_249_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_249_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_249_chunk USING btree (source);


--
-- Name: _hyper_1_249_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_249_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_249_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_249_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_249_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_249_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_24_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_24_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_24_chunk USING btree (close);


--
-- Name: _hyper_1_24_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_24_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_24_chunk USING btree (source);


--
-- Name: _hyper_1_24_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_24_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_24_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_24_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_24_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_24_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_250_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_250_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_250_chunk USING btree (close);


--
-- Name: _hyper_1_250_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_250_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_250_chunk USING btree (source);


--
-- Name: _hyper_1_250_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_250_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_250_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_250_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_250_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_250_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_251_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_251_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_251_chunk USING btree (close);


--
-- Name: _hyper_1_251_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_251_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_251_chunk USING btree (source);


--
-- Name: _hyper_1_251_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_251_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_251_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_251_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_251_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_251_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_252_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_252_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_252_chunk USING btree (close);


--
-- Name: _hyper_1_252_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_252_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_252_chunk USING btree (source);


--
-- Name: _hyper_1_252_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_252_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_252_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_252_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_252_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_252_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_253_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_253_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_253_chunk USING btree (close);


--
-- Name: _hyper_1_253_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_253_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_253_chunk USING btree (source);


--
-- Name: _hyper_1_253_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_253_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_253_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_253_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_253_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_253_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_254_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_254_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_254_chunk USING btree (close);


--
-- Name: _hyper_1_254_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_254_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_254_chunk USING btree (source);


--
-- Name: _hyper_1_254_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_254_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_254_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_254_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_254_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_254_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_255_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_255_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_255_chunk USING btree (close);


--
-- Name: _hyper_1_255_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_255_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_255_chunk USING btree (source);


--
-- Name: _hyper_1_255_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_255_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_255_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_255_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_255_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_255_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_256_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_256_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_256_chunk USING btree (close);


--
-- Name: _hyper_1_256_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_256_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_256_chunk USING btree (source);


--
-- Name: _hyper_1_256_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_256_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_256_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_256_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_256_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_256_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_257_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_257_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_257_chunk USING btree (close);


--
-- Name: _hyper_1_257_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_257_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_257_chunk USING btree (source);


--
-- Name: _hyper_1_257_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_257_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_257_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_257_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_257_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_257_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_258_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_258_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_258_chunk USING btree (close);


--
-- Name: _hyper_1_258_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_258_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_258_chunk USING btree (source);


--
-- Name: _hyper_1_258_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_258_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_258_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_258_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_258_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_258_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_259_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_259_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_259_chunk USING btree (close);


--
-- Name: _hyper_1_259_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_259_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_259_chunk USING btree (source);


--
-- Name: _hyper_1_259_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_259_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_259_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_259_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_259_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_259_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_25_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_25_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_25_chunk USING btree (close);


--
-- Name: _hyper_1_25_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_25_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_25_chunk USING btree (source);


--
-- Name: _hyper_1_25_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_25_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_25_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_25_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_25_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_25_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_260_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_260_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_260_chunk USING btree (close);


--
-- Name: _hyper_1_260_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_260_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_260_chunk USING btree (source);


--
-- Name: _hyper_1_260_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_260_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_260_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_260_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_260_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_260_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_261_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_261_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_261_chunk USING btree (close);


--
-- Name: _hyper_1_261_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_261_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_261_chunk USING btree (source);


--
-- Name: _hyper_1_261_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_261_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_261_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_261_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_261_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_261_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_262_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_262_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_262_chunk USING btree (close);


--
-- Name: _hyper_1_262_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_262_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_262_chunk USING btree (source);


--
-- Name: _hyper_1_262_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_262_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_262_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_262_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_262_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_262_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_263_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_263_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_263_chunk USING btree (close);


--
-- Name: _hyper_1_263_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_263_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_263_chunk USING btree (source);


--
-- Name: _hyper_1_263_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_263_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_263_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_263_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_263_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_263_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_264_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_264_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_264_chunk USING btree (close);


--
-- Name: _hyper_1_264_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_264_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_264_chunk USING btree (source);


--
-- Name: _hyper_1_264_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_264_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_264_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_264_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_264_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_264_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_265_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_265_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_265_chunk USING btree (close);


--
-- Name: _hyper_1_265_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_265_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_265_chunk USING btree (source);


--
-- Name: _hyper_1_265_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_265_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_265_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_265_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_265_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_265_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_266_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_266_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_266_chunk USING btree (close);


--
-- Name: _hyper_1_266_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_266_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_266_chunk USING btree (source);


--
-- Name: _hyper_1_266_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_266_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_266_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_266_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_266_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_266_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_267_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_267_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_267_chunk USING btree (close);


--
-- Name: _hyper_1_267_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_267_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_267_chunk USING btree (source);


--
-- Name: _hyper_1_267_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_267_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_267_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_267_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_267_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_267_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_268_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_268_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_268_chunk USING btree (close);


--
-- Name: _hyper_1_268_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_268_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_268_chunk USING btree (source);


--
-- Name: _hyper_1_268_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_268_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_268_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_268_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_268_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_268_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_269_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_269_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_269_chunk USING btree (close);


--
-- Name: _hyper_1_269_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_269_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_269_chunk USING btree (source);


--
-- Name: _hyper_1_269_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_269_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_269_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_269_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_269_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_269_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_26_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_26_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_26_chunk USING btree (close);


--
-- Name: _hyper_1_26_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_26_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_26_chunk USING btree (source);


--
-- Name: _hyper_1_26_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_26_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_26_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_26_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_26_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_26_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_270_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_270_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_270_chunk USING btree (close);


--
-- Name: _hyper_1_270_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_270_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_270_chunk USING btree (source);


--
-- Name: _hyper_1_270_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_270_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_270_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_270_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_270_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_270_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_271_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_271_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_271_chunk USING btree (close);


--
-- Name: _hyper_1_271_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_271_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_271_chunk USING btree (source);


--
-- Name: _hyper_1_271_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_271_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_271_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_271_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_271_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_271_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_272_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_272_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_272_chunk USING btree (close);


--
-- Name: _hyper_1_272_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_272_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_272_chunk USING btree (source);


--
-- Name: _hyper_1_272_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_272_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_272_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_272_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_272_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_272_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_273_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_273_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_273_chunk USING btree (close);


--
-- Name: _hyper_1_273_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_273_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_273_chunk USING btree (source);


--
-- Name: _hyper_1_273_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_273_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_273_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_273_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_273_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_273_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_274_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_274_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_274_chunk USING btree (close);


--
-- Name: _hyper_1_274_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_274_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_274_chunk USING btree (source);


--
-- Name: _hyper_1_274_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_274_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_274_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_274_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_274_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_274_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_275_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_275_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_275_chunk USING btree (close);


--
-- Name: _hyper_1_275_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_275_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_275_chunk USING btree (source);


--
-- Name: _hyper_1_275_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_275_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_275_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_275_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_275_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_275_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_276_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_276_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_276_chunk USING btree (close);


--
-- Name: _hyper_1_276_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_276_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_276_chunk USING btree (source);


--
-- Name: _hyper_1_276_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_276_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_276_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_276_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_276_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_276_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_277_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_277_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_277_chunk USING btree (close);


--
-- Name: _hyper_1_277_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_277_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_277_chunk USING btree (source);


--
-- Name: _hyper_1_277_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_277_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_277_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_277_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_277_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_277_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_278_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_278_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_278_chunk USING btree (close);


--
-- Name: _hyper_1_278_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_278_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_278_chunk USING btree (source);


--
-- Name: _hyper_1_278_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_278_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_278_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_278_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_278_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_278_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_279_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_279_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_279_chunk USING btree (close);


--
-- Name: _hyper_1_279_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_279_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_279_chunk USING btree (source);


--
-- Name: _hyper_1_279_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_279_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_279_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_279_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_279_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_279_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_27_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_27_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_27_chunk USING btree (close);


--
-- Name: _hyper_1_27_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_27_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_27_chunk USING btree (source);


--
-- Name: _hyper_1_27_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_27_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_27_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_27_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_27_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_27_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_280_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_280_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_280_chunk USING btree (close);


--
-- Name: _hyper_1_280_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_280_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_280_chunk USING btree (source);


--
-- Name: _hyper_1_280_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_280_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_280_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_280_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_280_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_280_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_281_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_281_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_281_chunk USING btree (close);


--
-- Name: _hyper_1_281_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_281_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_281_chunk USING btree (source);


--
-- Name: _hyper_1_281_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_281_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_281_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_281_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_281_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_281_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_282_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_282_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_282_chunk USING btree (close);


--
-- Name: _hyper_1_282_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_282_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_282_chunk USING btree (source);


--
-- Name: _hyper_1_282_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_282_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_282_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_282_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_282_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_282_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_283_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_283_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_283_chunk USING btree (close);


--
-- Name: _hyper_1_283_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_283_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_283_chunk USING btree (source);


--
-- Name: _hyper_1_283_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_283_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_283_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_283_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_283_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_283_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_284_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_284_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_284_chunk USING btree (close);


--
-- Name: _hyper_1_284_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_284_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_284_chunk USING btree (source);


--
-- Name: _hyper_1_284_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_284_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_284_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_284_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_284_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_284_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_285_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_285_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_285_chunk USING btree (close);


--
-- Name: _hyper_1_285_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_285_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_285_chunk USING btree (source);


--
-- Name: _hyper_1_285_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_285_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_285_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_285_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_285_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_285_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_286_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_286_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_286_chunk USING btree (close);


--
-- Name: _hyper_1_286_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_286_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_286_chunk USING btree (source);


--
-- Name: _hyper_1_286_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_286_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_286_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_286_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_286_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_286_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_287_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_287_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_287_chunk USING btree (close);


--
-- Name: _hyper_1_287_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_287_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_287_chunk USING btree (source);


--
-- Name: _hyper_1_287_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_287_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_287_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_287_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_287_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_287_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_288_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_288_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_288_chunk USING btree (close);


--
-- Name: _hyper_1_288_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_288_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_288_chunk USING btree (source);


--
-- Name: _hyper_1_288_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_288_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_288_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_288_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_288_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_288_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_289_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_289_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_289_chunk USING btree (close);


--
-- Name: _hyper_1_289_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_289_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_289_chunk USING btree (source);


--
-- Name: _hyper_1_289_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_289_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_289_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_289_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_289_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_289_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_28_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_28_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_28_chunk USING btree (close);


--
-- Name: _hyper_1_28_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_28_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_28_chunk USING btree (source);


--
-- Name: _hyper_1_28_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_28_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_28_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_28_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_28_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_28_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_290_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_290_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_290_chunk USING btree (close);


--
-- Name: _hyper_1_290_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_290_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_290_chunk USING btree (source);


--
-- Name: _hyper_1_290_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_290_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_290_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_290_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_290_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_290_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_291_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_291_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_291_chunk USING btree (close);


--
-- Name: _hyper_1_291_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_291_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_291_chunk USING btree (source);


--
-- Name: _hyper_1_291_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_291_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_291_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_291_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_291_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_291_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_292_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_292_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_292_chunk USING btree (close);


--
-- Name: _hyper_1_292_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_292_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_292_chunk USING btree (source);


--
-- Name: _hyper_1_292_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_292_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_292_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_292_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_292_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_292_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_293_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_293_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_293_chunk USING btree (close);


--
-- Name: _hyper_1_293_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_293_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_293_chunk USING btree (source);


--
-- Name: _hyper_1_293_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_293_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_293_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_293_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_293_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_293_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_294_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_294_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_294_chunk USING btree (close);


--
-- Name: _hyper_1_294_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_294_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_294_chunk USING btree (source);


--
-- Name: _hyper_1_294_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_294_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_294_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_294_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_294_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_294_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_295_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_295_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_295_chunk USING btree (close);


--
-- Name: _hyper_1_295_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_295_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_295_chunk USING btree (source);


--
-- Name: _hyper_1_295_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_295_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_295_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_295_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_295_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_295_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_296_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_296_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_296_chunk USING btree (close);


--
-- Name: _hyper_1_296_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_296_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_296_chunk USING btree (source);


--
-- Name: _hyper_1_296_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_296_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_296_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_296_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_296_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_296_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_297_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_297_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_297_chunk USING btree (close);


--
-- Name: _hyper_1_297_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_297_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_297_chunk USING btree (source);


--
-- Name: _hyper_1_297_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_297_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_297_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_297_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_297_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_297_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_298_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_298_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_298_chunk USING btree (close);


--
-- Name: _hyper_1_298_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_298_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_298_chunk USING btree (source);


--
-- Name: _hyper_1_298_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_298_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_298_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_298_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_298_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_298_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_299_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_299_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_299_chunk USING btree (close);


--
-- Name: _hyper_1_299_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_299_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_299_chunk USING btree (source);


--
-- Name: _hyper_1_299_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_299_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_299_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_299_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_299_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_299_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_29_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_29_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_29_chunk USING btree (close);


--
-- Name: _hyper_1_29_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_29_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_29_chunk USING btree (source);


--
-- Name: _hyper_1_29_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_29_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_29_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_29_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_29_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_29_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_2_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_2_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_2_chunk USING btree (close);


--
-- Name: _hyper_1_2_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_2_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_2_chunk USING btree (source);


--
-- Name: _hyper_1_2_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_2_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_2_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_2_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_2_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_2_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_300_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_300_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_300_chunk USING btree (close);


--
-- Name: _hyper_1_300_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_300_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_300_chunk USING btree (source);


--
-- Name: _hyper_1_300_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_300_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_300_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_300_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_300_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_300_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_301_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_301_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_301_chunk USING btree (close);


--
-- Name: _hyper_1_301_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_301_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_301_chunk USING btree (source);


--
-- Name: _hyper_1_301_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_301_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_301_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_301_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_301_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_301_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_302_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_302_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_302_chunk USING btree (close);


--
-- Name: _hyper_1_302_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_302_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_302_chunk USING btree (source);


--
-- Name: _hyper_1_302_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_302_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_302_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_302_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_302_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_302_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_303_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_303_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_303_chunk USING btree (close);


--
-- Name: _hyper_1_303_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_303_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_303_chunk USING btree (source);


--
-- Name: _hyper_1_303_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_303_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_303_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_303_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_303_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_303_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_304_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_304_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_304_chunk USING btree (close);


--
-- Name: _hyper_1_304_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_304_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_304_chunk USING btree (source);


--
-- Name: _hyper_1_304_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_304_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_304_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_304_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_304_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_304_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_305_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_305_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_305_chunk USING btree (close);


--
-- Name: _hyper_1_305_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_305_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_305_chunk USING btree (source);


--
-- Name: _hyper_1_305_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_305_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_305_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_305_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_305_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_305_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_306_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_306_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_306_chunk USING btree (close);


--
-- Name: _hyper_1_306_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_306_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_306_chunk USING btree (source);


--
-- Name: _hyper_1_306_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_306_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_306_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_306_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_306_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_306_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_307_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_307_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_307_chunk USING btree (close);


--
-- Name: _hyper_1_307_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_307_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_307_chunk USING btree (source);


--
-- Name: _hyper_1_307_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_307_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_307_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_307_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_307_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_307_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_308_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_308_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_308_chunk USING btree (close);


--
-- Name: _hyper_1_308_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_308_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_308_chunk USING btree (source);


--
-- Name: _hyper_1_308_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_308_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_308_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_308_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_308_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_308_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_309_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_309_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_309_chunk USING btree (close);


--
-- Name: _hyper_1_309_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_309_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_309_chunk USING btree (source);


--
-- Name: _hyper_1_309_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_309_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_309_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_309_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_309_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_309_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_30_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_30_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_30_chunk USING btree (close);


--
-- Name: _hyper_1_30_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_30_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_30_chunk USING btree (source);


--
-- Name: _hyper_1_30_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_30_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_30_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_30_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_30_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_30_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_310_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_310_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_310_chunk USING btree (close);


--
-- Name: _hyper_1_310_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_310_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_310_chunk USING btree (source);


--
-- Name: _hyper_1_310_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_310_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_310_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_310_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_310_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_310_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_311_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_311_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_311_chunk USING btree (close);


--
-- Name: _hyper_1_311_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_311_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_311_chunk USING btree (source);


--
-- Name: _hyper_1_311_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_311_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_311_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_311_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_311_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_311_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_312_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_312_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_312_chunk USING btree (close);


--
-- Name: _hyper_1_312_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_312_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_312_chunk USING btree (source);


--
-- Name: _hyper_1_312_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_312_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_312_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_312_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_312_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_312_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_313_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_313_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_313_chunk USING btree (close);


--
-- Name: _hyper_1_313_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_313_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_313_chunk USING btree (source);


--
-- Name: _hyper_1_313_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_313_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_313_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_313_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_313_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_313_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_314_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_314_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_314_chunk USING btree (close);


--
-- Name: _hyper_1_314_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_314_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_314_chunk USING btree (source);


--
-- Name: _hyper_1_314_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_314_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_314_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_314_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_314_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_314_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_315_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_315_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_315_chunk USING btree (close);


--
-- Name: _hyper_1_315_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_315_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_315_chunk USING btree (source);


--
-- Name: _hyper_1_315_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_315_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_315_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_315_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_315_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_315_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_316_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_316_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_316_chunk USING btree (close);


--
-- Name: _hyper_1_316_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_316_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_316_chunk USING btree (source);


--
-- Name: _hyper_1_316_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_316_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_316_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_316_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_316_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_316_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_31_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_31_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_31_chunk USING btree (close);


--
-- Name: _hyper_1_31_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_31_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_31_chunk USING btree (source);


--
-- Name: _hyper_1_31_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_31_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_31_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_31_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_31_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_31_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_32_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_32_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_32_chunk USING btree (close);


--
-- Name: _hyper_1_32_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_32_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_32_chunk USING btree (source);


--
-- Name: _hyper_1_32_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_32_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_32_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_32_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_32_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_32_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_33_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_33_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_33_chunk USING btree (close);


--
-- Name: _hyper_1_33_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_33_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_33_chunk USING btree (source);


--
-- Name: _hyper_1_33_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_33_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_33_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_33_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_33_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_33_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_34_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_34_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_34_chunk USING btree (close);


--
-- Name: _hyper_1_34_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_34_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_34_chunk USING btree (source);


--
-- Name: _hyper_1_34_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_34_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_34_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_34_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_34_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_34_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_35_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_35_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_35_chunk USING btree (close);


--
-- Name: _hyper_1_35_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_35_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_35_chunk USING btree (source);


--
-- Name: _hyper_1_35_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_35_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_35_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_35_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_35_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_35_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_36_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_36_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_36_chunk USING btree (close);


--
-- Name: _hyper_1_36_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_36_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_36_chunk USING btree (source);


--
-- Name: _hyper_1_36_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_36_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_36_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_36_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_36_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_36_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_37_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_37_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_37_chunk USING btree (close);


--
-- Name: _hyper_1_37_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_37_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_37_chunk USING btree (source);


--
-- Name: _hyper_1_37_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_37_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_37_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_37_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_37_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_37_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_38_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_38_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_38_chunk USING btree (close);


--
-- Name: _hyper_1_38_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_38_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_38_chunk USING btree (source);


--
-- Name: _hyper_1_38_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_38_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_38_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_38_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_38_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_38_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_39_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_39_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_39_chunk USING btree (close);


--
-- Name: _hyper_1_39_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_39_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_39_chunk USING btree (source);


--
-- Name: _hyper_1_39_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_39_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_39_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_39_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_39_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_39_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_3_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_3_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_3_chunk USING btree (close);


--
-- Name: _hyper_1_3_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_3_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_3_chunk USING btree (source);


--
-- Name: _hyper_1_3_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_3_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_3_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_3_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_3_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_3_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_40_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_40_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_40_chunk USING btree (close);


--
-- Name: _hyper_1_40_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_40_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_40_chunk USING btree (source);


--
-- Name: _hyper_1_40_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_40_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_40_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_40_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_40_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_40_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_41_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_41_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_41_chunk USING btree (close);


--
-- Name: _hyper_1_41_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_41_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_41_chunk USING btree (source);


--
-- Name: _hyper_1_41_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_41_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_41_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_41_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_41_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_41_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_42_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_42_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_42_chunk USING btree (close);


--
-- Name: _hyper_1_42_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_42_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_42_chunk USING btree (source);


--
-- Name: _hyper_1_42_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_42_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_42_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_42_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_42_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_42_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_43_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_43_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_43_chunk USING btree (close);


--
-- Name: _hyper_1_43_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_43_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_43_chunk USING btree (source);


--
-- Name: _hyper_1_43_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_43_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_43_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_43_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_43_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_43_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_44_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_44_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_44_chunk USING btree (close);


--
-- Name: _hyper_1_44_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_44_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_44_chunk USING btree (source);


--
-- Name: _hyper_1_44_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_44_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_44_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_44_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_44_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_44_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_45_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_45_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_45_chunk USING btree (close);


--
-- Name: _hyper_1_45_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_45_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_45_chunk USING btree (source);


--
-- Name: _hyper_1_45_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_45_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_45_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_45_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_45_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_45_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_46_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_46_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_46_chunk USING btree (close);


--
-- Name: _hyper_1_46_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_46_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_46_chunk USING btree (source);


--
-- Name: _hyper_1_46_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_46_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_46_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_46_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_46_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_46_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_47_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_47_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_47_chunk USING btree (close);


--
-- Name: _hyper_1_47_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_47_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_47_chunk USING btree (source);


--
-- Name: _hyper_1_47_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_47_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_47_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_47_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_47_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_47_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_48_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_48_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_48_chunk USING btree (close);


--
-- Name: _hyper_1_48_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_48_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_48_chunk USING btree (source);


--
-- Name: _hyper_1_48_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_48_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_48_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_48_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_48_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_48_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_49_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_49_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_49_chunk USING btree (close);


--
-- Name: _hyper_1_49_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_49_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_49_chunk USING btree (source);


--
-- Name: _hyper_1_49_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_49_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_49_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_49_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_49_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_49_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_4_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_4_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_4_chunk USING btree (close);


--
-- Name: _hyper_1_4_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_4_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_4_chunk USING btree (source);


--
-- Name: _hyper_1_4_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_4_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_4_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_4_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_4_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_4_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_50_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_50_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_50_chunk USING btree (close);


--
-- Name: _hyper_1_50_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_50_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_50_chunk USING btree (source);


--
-- Name: _hyper_1_50_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_50_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_50_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_50_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_50_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_50_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_51_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_51_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_51_chunk USING btree (close);


--
-- Name: _hyper_1_51_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_51_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_51_chunk USING btree (source);


--
-- Name: _hyper_1_51_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_51_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_51_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_51_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_51_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_51_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_52_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_52_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_52_chunk USING btree (close);


--
-- Name: _hyper_1_52_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_52_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_52_chunk USING btree (source);


--
-- Name: _hyper_1_52_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_52_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_52_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_52_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_52_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_52_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_53_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_53_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_53_chunk USING btree (close);


--
-- Name: _hyper_1_53_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_53_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_53_chunk USING btree (source);


--
-- Name: _hyper_1_53_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_53_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_53_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_53_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_53_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_53_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_54_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_54_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_54_chunk USING btree (close);


--
-- Name: _hyper_1_54_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_54_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_54_chunk USING btree (source);


--
-- Name: _hyper_1_54_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_54_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_54_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_54_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_54_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_54_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_55_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_55_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_55_chunk USING btree (close);


--
-- Name: _hyper_1_55_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_55_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_55_chunk USING btree (source);


--
-- Name: _hyper_1_55_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_55_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_55_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_55_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_55_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_55_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_56_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_56_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_56_chunk USING btree (close);


--
-- Name: _hyper_1_56_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_56_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_56_chunk USING btree (source);


--
-- Name: _hyper_1_56_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_56_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_56_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_56_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_56_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_56_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_57_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_57_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_57_chunk USING btree (close);


--
-- Name: _hyper_1_57_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_57_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_57_chunk USING btree (source);


--
-- Name: _hyper_1_57_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_57_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_57_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_57_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_57_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_57_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_58_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_58_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_58_chunk USING btree (close);


--
-- Name: _hyper_1_58_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_58_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_58_chunk USING btree (source);


--
-- Name: _hyper_1_58_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_58_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_58_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_58_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_58_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_58_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_59_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_59_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_59_chunk USING btree (close);


--
-- Name: _hyper_1_59_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_59_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_59_chunk USING btree (source);


--
-- Name: _hyper_1_59_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_59_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_59_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_59_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_59_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_59_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_5_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_5_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_5_chunk USING btree (close);


--
-- Name: _hyper_1_5_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_5_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_5_chunk USING btree (source);


--
-- Name: _hyper_1_5_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_5_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_5_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_5_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_5_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_5_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_60_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_60_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_60_chunk USING btree (close);


--
-- Name: _hyper_1_60_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_60_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_60_chunk USING btree (source);


--
-- Name: _hyper_1_60_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_60_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_60_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_60_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_60_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_60_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_61_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_61_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_61_chunk USING btree (close);


--
-- Name: _hyper_1_61_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_61_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_61_chunk USING btree (source);


--
-- Name: _hyper_1_61_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_61_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_61_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_61_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_61_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_61_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_62_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_62_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_62_chunk USING btree (close);


--
-- Name: _hyper_1_62_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_62_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_62_chunk USING btree (source);


--
-- Name: _hyper_1_62_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_62_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_62_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_62_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_62_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_62_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_63_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_63_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_63_chunk USING btree (close);


--
-- Name: _hyper_1_63_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_63_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_63_chunk USING btree (source);


--
-- Name: _hyper_1_63_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_63_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_63_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_63_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_63_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_63_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_64_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_64_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_64_chunk USING btree (close);


--
-- Name: _hyper_1_64_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_64_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_64_chunk USING btree (source);


--
-- Name: _hyper_1_64_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_64_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_64_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_64_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_64_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_64_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_65_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_65_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_65_chunk USING btree (close);


--
-- Name: _hyper_1_65_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_65_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_65_chunk USING btree (source);


--
-- Name: _hyper_1_65_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_65_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_65_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_65_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_65_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_65_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_66_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_66_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_66_chunk USING btree (close);


--
-- Name: _hyper_1_66_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_66_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_66_chunk USING btree (source);


--
-- Name: _hyper_1_66_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_66_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_66_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_66_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_66_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_66_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_67_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_67_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_67_chunk USING btree (close);


--
-- Name: _hyper_1_67_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_67_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_67_chunk USING btree (source);


--
-- Name: _hyper_1_67_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_67_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_67_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_67_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_67_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_67_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_68_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_68_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_68_chunk USING btree (close);


--
-- Name: _hyper_1_68_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_68_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_68_chunk USING btree (source);


--
-- Name: _hyper_1_68_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_68_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_68_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_68_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_68_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_68_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_69_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_69_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_69_chunk USING btree (close);


--
-- Name: _hyper_1_69_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_69_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_69_chunk USING btree (source);


--
-- Name: _hyper_1_69_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_69_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_69_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_69_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_69_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_69_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_6_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_6_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_6_chunk USING btree (close);


--
-- Name: _hyper_1_6_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_6_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_6_chunk USING btree (source);


--
-- Name: _hyper_1_6_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_6_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_6_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_6_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_6_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_6_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_70_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_70_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_70_chunk USING btree (close);


--
-- Name: _hyper_1_70_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_70_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_70_chunk USING btree (source);


--
-- Name: _hyper_1_70_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_70_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_70_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_70_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_70_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_70_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_71_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_71_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_71_chunk USING btree (close);


--
-- Name: _hyper_1_71_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_71_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_71_chunk USING btree (source);


--
-- Name: _hyper_1_71_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_71_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_71_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_71_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_71_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_71_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_72_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_72_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_72_chunk USING btree (close);


--
-- Name: _hyper_1_72_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_72_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_72_chunk USING btree (source);


--
-- Name: _hyper_1_72_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_72_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_72_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_72_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_72_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_72_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_73_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_73_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_73_chunk USING btree (close);


--
-- Name: _hyper_1_73_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_73_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_73_chunk USING btree (source);


--
-- Name: _hyper_1_73_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_73_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_73_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_73_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_73_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_73_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_74_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_74_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_74_chunk USING btree (close);


--
-- Name: _hyper_1_74_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_74_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_74_chunk USING btree (source);


--
-- Name: _hyper_1_74_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_74_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_74_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_74_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_74_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_74_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_75_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_75_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_75_chunk USING btree (close);


--
-- Name: _hyper_1_75_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_75_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_75_chunk USING btree (source);


--
-- Name: _hyper_1_75_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_75_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_75_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_75_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_75_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_75_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_76_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_76_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_76_chunk USING btree (close);


--
-- Name: _hyper_1_76_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_76_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_76_chunk USING btree (source);


--
-- Name: _hyper_1_76_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_76_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_76_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_76_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_76_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_76_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_77_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_77_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_77_chunk USING btree (close);


--
-- Name: _hyper_1_77_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_77_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_77_chunk USING btree (source);


--
-- Name: _hyper_1_77_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_77_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_77_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_77_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_77_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_77_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_78_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_78_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_78_chunk USING btree (close);


--
-- Name: _hyper_1_78_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_78_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_78_chunk USING btree (source);


--
-- Name: _hyper_1_78_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_78_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_78_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_78_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_78_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_78_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_79_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_79_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_79_chunk USING btree (close);


--
-- Name: _hyper_1_79_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_79_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_79_chunk USING btree (source);


--
-- Name: _hyper_1_79_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_79_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_79_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_79_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_79_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_79_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_7_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_7_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_7_chunk USING btree (close);


--
-- Name: _hyper_1_7_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_7_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_7_chunk USING btree (source);


--
-- Name: _hyper_1_7_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_7_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_7_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_7_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_7_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_7_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_80_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_80_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_80_chunk USING btree (close);


--
-- Name: _hyper_1_80_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_80_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_80_chunk USING btree (source);


--
-- Name: _hyper_1_80_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_80_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_80_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_80_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_80_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_80_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_81_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_81_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_81_chunk USING btree (close);


--
-- Name: _hyper_1_81_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_81_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_81_chunk USING btree (source);


--
-- Name: _hyper_1_81_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_81_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_81_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_81_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_81_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_81_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_82_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_82_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_82_chunk USING btree (close);


--
-- Name: _hyper_1_82_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_82_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_82_chunk USING btree (source);


--
-- Name: _hyper_1_82_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_82_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_82_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_82_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_82_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_82_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_83_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_83_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_83_chunk USING btree (close);


--
-- Name: _hyper_1_83_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_83_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_83_chunk USING btree (source);


--
-- Name: _hyper_1_83_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_83_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_83_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_83_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_83_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_83_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_84_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_84_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_84_chunk USING btree (close);


--
-- Name: _hyper_1_84_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_84_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_84_chunk USING btree (source);


--
-- Name: _hyper_1_84_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_84_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_84_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_84_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_84_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_84_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_85_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_85_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_85_chunk USING btree (close);


--
-- Name: _hyper_1_85_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_85_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_85_chunk USING btree (source);


--
-- Name: _hyper_1_85_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_85_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_85_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_85_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_85_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_85_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_86_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_86_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_86_chunk USING btree (close);


--
-- Name: _hyper_1_86_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_86_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_86_chunk USING btree (source);


--
-- Name: _hyper_1_86_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_86_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_86_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_86_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_86_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_86_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_87_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_87_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_87_chunk USING btree (close);


--
-- Name: _hyper_1_87_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_87_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_87_chunk USING btree (source);


--
-- Name: _hyper_1_87_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_87_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_87_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_87_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_87_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_87_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_88_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_88_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_88_chunk USING btree (close);


--
-- Name: _hyper_1_88_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_88_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_88_chunk USING btree (source);


--
-- Name: _hyper_1_88_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_88_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_88_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_88_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_88_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_88_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_89_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_89_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_89_chunk USING btree (close);


--
-- Name: _hyper_1_89_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_89_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_89_chunk USING btree (source);


--
-- Name: _hyper_1_89_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_89_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_89_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_89_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_89_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_89_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_8_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_8_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_8_chunk USING btree (close);


--
-- Name: _hyper_1_8_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_8_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_8_chunk USING btree (source);


--
-- Name: _hyper_1_8_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_8_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_8_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_8_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_8_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_8_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_90_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_90_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_90_chunk USING btree (close);


--
-- Name: _hyper_1_90_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_90_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_90_chunk USING btree (source);


--
-- Name: _hyper_1_90_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_90_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_90_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_90_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_90_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_90_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_91_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_91_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_91_chunk USING btree (close);


--
-- Name: _hyper_1_91_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_91_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_91_chunk USING btree (source);


--
-- Name: _hyper_1_91_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_91_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_91_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_91_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_91_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_91_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_92_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_92_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_92_chunk USING btree (close);


--
-- Name: _hyper_1_92_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_92_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_92_chunk USING btree (source);


--
-- Name: _hyper_1_92_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_92_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_92_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_92_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_92_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_92_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_93_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_93_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_93_chunk USING btree (close);


--
-- Name: _hyper_1_93_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_93_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_93_chunk USING btree (source);


--
-- Name: _hyper_1_93_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_93_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_93_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_93_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_93_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_93_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_94_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_94_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_94_chunk USING btree (close);


--
-- Name: _hyper_1_94_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_94_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_94_chunk USING btree (source);


--
-- Name: _hyper_1_94_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_94_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_94_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_94_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_94_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_94_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_95_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_95_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_95_chunk USING btree (close);


--
-- Name: _hyper_1_95_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_95_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_95_chunk USING btree (source);


--
-- Name: _hyper_1_95_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_95_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_95_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_95_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_95_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_95_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_96_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_96_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_96_chunk USING btree (close);


--
-- Name: _hyper_1_96_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_96_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_96_chunk USING btree (source);


--
-- Name: _hyper_1_96_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_96_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_96_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_96_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_96_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_96_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_97_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_97_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_97_chunk USING btree (close);


--
-- Name: _hyper_1_97_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_97_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_97_chunk USING btree (source);


--
-- Name: _hyper_1_97_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_97_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_97_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_97_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_97_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_97_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_98_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_98_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_98_chunk USING btree (close);


--
-- Name: _hyper_1_98_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_98_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_98_chunk USING btree (source);


--
-- Name: _hyper_1_98_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_98_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_98_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_98_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_98_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_98_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_99_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_99_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_99_chunk USING btree (close);


--
-- Name: _hyper_1_99_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_99_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_99_chunk USING btree (source);


--
-- Name: _hyper_1_99_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_99_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_99_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_99_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_99_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_99_chunk USING btree ("time" DESC);


--
-- Name: _hyper_1_9_chunk_idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_9_chunk_idx_usdcop_m5_ohlcv_close ON _timescaledb_internal._hyper_1_9_chunk USING btree (close);


--
-- Name: _hyper_1_9_chunk_idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_9_chunk_idx_usdcop_m5_ohlcv_source ON _timescaledb_internal._hyper_1_9_chunk USING btree (source);


--
-- Name: _hyper_1_9_chunk_idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_9_chunk_idx_usdcop_m5_ohlcv_symbol_time ON _timescaledb_internal._hyper_1_9_chunk USING btree (symbol, "time" DESC);


--
-- Name: _hyper_1_9_chunk_usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: -
--

CREATE INDEX _hyper_1_9_chunk_usdcop_m5_ohlcv_time_idx ON _timescaledb_internal._hyper_1_9_chunk USING btree ("time" DESC);


--
-- Name: idx_features_active; Type: INDEX; Schema: config; Owner: -
--

CREATE INDEX idx_features_active ON config.feature_definitions USING btree (is_active) WHERE (is_active = true);


--
-- Name: idx_features_group; Type: INDEX; Schema: config; Owner: -
--

CREATE INDEX idx_features_group ON config.feature_definitions USING btree (feature_group);


--
-- Name: idx_features_order; Type: INDEX; Schema: config; Owner: -
--

CREATE INDEX idx_features_order ON config.feature_definitions USING btree (observation_order);


--
-- Name: idx_models_algorithm; Type: INDEX; Schema: config; Owner: -
--

CREATE INDEX idx_models_algorithm ON config.models USING btree (algorithm);


--
-- Name: idx_models_status; Type: INDEX; Schema: config; Owner: -
--

CREATE INDEX idx_models_status ON config.models USING btree (status);


--
-- Name: idx_models_updated; Type: INDEX; Schema: config; Owner: -
--

CREATE INDEX idx_models_updated ON config.models USING btree (updated_at DESC);


--
-- Name: idx_agent_actions_time; Type: INDEX; Schema: dw; Owner: -
--

CREATE INDEX idx_agent_actions_time ON dw.fact_agent_actions USING btree ("timestamp" DESC);


--
-- Name: idx_alerts_session; Type: INDEX; Schema: dw; Owner: -
--

CREATE INDEX idx_alerts_session ON dw.fact_inference_alerts USING btree (session_date, resolved);


--
-- Name: idx_equity_session; Type: INDEX; Schema: dw; Owner: -
--

CREATE INDEX idx_equity_session ON dw.fact_equity_curve_realtime USING btree (session_date);


--
-- Name: idx_rl_inference_time; Type: INDEX; Schema: dw; Owner: -
--

CREATE INDEX idx_rl_inference_time ON dw.fact_rl_inference USING btree ("timestamp" DESC);


--
-- Name: idx_session_perf_date; Type: INDEX; Schema: dw; Owner: -
--

CREATE INDEX idx_session_perf_date ON dw.fact_session_performance USING btree (session_date);


--
-- Name: idx_events_correlation; Type: INDEX; Schema: events; Owner: -
--

CREATE INDEX idx_events_correlation ON events.signals_stream USING btree (correlation_id) WHERE (correlation_id IS NOT NULL);


--
-- Name: idx_events_model_time; Type: INDEX; Schema: events; Owner: -
--

CREATE INDEX idx_events_model_time ON events.signals_stream USING btree (model_id, timestamp_utc DESC);


--
-- Name: idx_events_time; Type: INDEX; Schema: events; Owner: -
--

CREATE INDEX idx_events_time ON events.signals_stream USING btree (timestamp_utc DESC);


--
-- Name: idx_events_type_time; Type: INDEX; Schema: events; Owner: -
--

CREATE INDEX idx_events_type_time ON events.signals_stream USING btree (event_type, timestamp_utc DESC);


--
-- Name: idx_events_unprocessed; Type: INDEX; Schema: events; Owner: -
--

CREATE INDEX idx_events_unprocessed ON events.signals_stream USING btree (processed, timestamp_utc DESC) WHERE (processed = false);


--
-- Name: idx_perf_aggregation; Type: INDEX; Schema: metrics; Owner: -
--

CREATE INDEX idx_perf_aggregation ON metrics.model_performance USING btree (aggregation_type, period_start DESC);


--
-- Name: idx_perf_model_period; Type: INDEX; Schema: metrics; Owner: -
--

CREATE INDEX idx_perf_model_period ON metrics.model_performance USING btree (model_id, period_start DESC);


--
-- Name: idx_perf_sharpe; Type: INDEX; Schema: metrics; Owner: -
--

CREATE INDEX idx_perf_sharpe ON metrics.model_performance USING btree (sharpe_ratio DESC NULLS LAST);


--
-- Name: dag_id_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dag_id_state ON public.dag_run USING btree (dag_id, state);


--
-- Name: idx_ab_register_user_username; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_ab_register_user_username ON public.ab_register_user USING btree (lower((username)::text));


--
-- Name: idx_ab_user_username; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_ab_user_username ON public.ab_user USING btree (lower((username)::text));


--
-- Name: idx_dag_run_dag_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dag_run_dag_id ON public.dag_run USING btree (dag_id);


--
-- Name: idx_dag_run_queued_dags; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dag_run_queued_dags ON public.dag_run USING btree (state, dag_id) WHERE ((state)::text = 'queued'::text);


--
-- Name: idx_dag_run_running_dags; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dag_run_running_dags ON public.dag_run USING btree (state, dag_id) WHERE ((state)::text = 'running'::text);


--
-- Name: idx_dagrun_dataset_events_dag_run_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dagrun_dataset_events_dag_run_id ON public.dagrun_dataset_event USING btree (dag_run_id);


--
-- Name: idx_dagrun_dataset_events_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dagrun_dataset_events_event_id ON public.dagrun_dataset_event USING btree (event_id);


--
-- Name: idx_dataset_id_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dataset_id_timestamp ON public.dataset_event USING btree (dataset_id, "timestamp");


--
-- Name: idx_equity_model_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_equity_model_time ON public.equity_snapshots USING btree (model_id, "timestamp" DESC);


--
-- Name: idx_fileloc_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fileloc_hash ON public.serialized_dag USING btree (fileloc_hash);


--
-- Name: idx_job_dag_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_job_dag_id ON public.job USING btree (dag_id);


--
-- Name: idx_job_state_heartbeat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_job_state_heartbeat ON public.job USING btree (state, latest_heartbeat);


--
-- Name: idx_last_scheduling_decision; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_last_scheduling_decision ON public.dag_run USING btree (last_scheduling_decision);


--
-- Name: idx_log_dag; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_log_dag ON public.log USING btree (dag_id);


--
-- Name: idx_log_dttm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_log_dttm ON public.log USING btree (dttm);


--
-- Name: idx_log_event; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_log_event ON public.log USING btree (event);


--
-- Name: idx_macro_daily_dxy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_macro_daily_dxy ON public.macro_indicators_daily USING btree (fxrt_index_dxy_usa_d_dxy);


--
-- Name: idx_macro_daily_embi; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_macro_daily_embi ON public.macro_indicators_daily USING btree (crsk_spread_embi_col_d_embi);


--
-- Name: idx_macro_daily_fecha; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_macro_daily_fecha ON public.macro_indicators_daily USING btree (fecha DESC);


--
-- Name: idx_macro_daily_vix; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_macro_daily_vix ON public.macro_indicators_daily USING btree (volt_vix_usa_d_vix);


--
-- Name: idx_next_dagrun_create_after; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_next_dagrun_create_after ON public.dag USING btree (next_dagrun_create_after);


--
-- Name: idx_python_features_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_python_features_time ON public.python_features_5m USING btree ("time" DESC);


--
-- Name: idx_root_dag_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_root_dag_id ON public.dag USING btree (root_dag_id);


--
-- Name: idx_task_fail_task_instance; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_fail_task_instance ON public.task_fail USING btree (dag_id, task_id, run_id, map_index);


--
-- Name: idx_task_reschedule_dag_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_reschedule_dag_run ON public.task_reschedule USING btree (dag_id, run_id);


--
-- Name: idx_task_reschedule_dag_task_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_reschedule_dag_task_run ON public.task_reschedule USING btree (dag_id, task_id, run_id, map_index);


--
-- Name: idx_trades_exit; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_trades_exit ON public.trades_history USING btree (exit_time DESC);


--
-- Name: idx_trades_model; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_trades_model ON public.trades_history USING btree (model_id);


--
-- Name: idx_trades_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_trades_time ON public.trades_history USING btree (entry_time DESC);


--
-- Name: idx_trading_metrics_model; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_trading_metrics_model ON public.trading_metrics USING btree (model_version);


--
-- Name: idx_trading_metrics_name_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_trading_metrics_name_time ON public.trading_metrics USING btree (metric_name, "timestamp" DESC);


--
-- Name: idx_trading_metrics_strategy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_trading_metrics_strategy ON public.trading_metrics USING btree (strategy_name);


--
-- Name: idx_trading_metrics_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_trading_metrics_type ON public.trading_metrics USING btree (metric_type);


--
-- Name: idx_trading_sessions_start; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_trading_sessions_start ON public.trading_sessions USING btree (session_start);


--
-- Name: idx_trading_sessions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_trading_sessions_status ON public.trading_sessions USING btree (status) WHERE ((status)::text = 'active'::text);


--
-- Name: idx_trading_sessions_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_trading_sessions_user ON public.trading_sessions USING btree (user_id);


--
-- Name: idx_trading_state_model; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_trading_state_model ON public.trading_state USING btree (model_id);


--
-- Name: idx_uri_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_uri_unique ON public.dataset USING btree (uri);


--
-- Name: idx_usdcop_m5_ohlcv_close; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usdcop_m5_ohlcv_close ON public.usdcop_m5_ohlcv USING btree (close);


--
-- Name: idx_usdcop_m5_ohlcv_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usdcop_m5_ohlcv_source ON public.usdcop_m5_ohlcv USING btree (source);


--
-- Name: idx_usdcop_m5_ohlcv_symbol_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usdcop_m5_ohlcv_symbol_time ON public.usdcop_m5_ohlcv USING btree (symbol, "time" DESC);


--
-- Name: idx_usdcop_m5_ohlcv_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_usdcop_m5_ohlcv_time ON public.usdcop_m5_ohlcv USING btree ("time" DESC);


--
-- Name: idx_users_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_active ON public.users USING btree (is_active) WHERE (is_active = true);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: idx_xcom_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_xcom_key ON public.xcom USING btree (key);


--
-- Name: idx_xcom_task_instance; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_xcom_task_instance ON public.xcom USING btree (dag_id, task_id, run_id, map_index);


--
-- Name: job_type_heart; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX job_type_heart ON public.job USING btree (job_type, latest_heartbeat);


--
-- Name: sm_dag; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sm_dag ON public.sla_miss USING btree (dag_id);


--
-- Name: ti_dag_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ti_dag_run ON public.task_instance USING btree (dag_id, run_id);


--
-- Name: ti_dag_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ti_dag_state ON public.task_instance USING btree (dag_id, state);


--
-- Name: ti_job_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ti_job_id ON public.task_instance USING btree (job_id);


--
-- Name: ti_pool; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ti_pool ON public.task_instance USING btree (pool, state, priority_weight);


--
-- Name: ti_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ti_state ON public.task_instance USING btree (state);


--
-- Name: ti_state_lkp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ti_state_lkp ON public.task_instance USING btree (dag_id, task_id, run_id, state);


--
-- Name: ti_trigger_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ti_trigger_id ON public.task_instance USING btree (trigger_id);


--
-- Name: trading_metrics_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX trading_metrics_timestamp_idx ON public.trading_metrics USING btree ("timestamp" DESC);


--
-- Name: usdcop_m5_ohlcv_time_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX usdcop_m5_ohlcv_time_idx ON public.usdcop_m5_ohlcv USING btree ("time" DESC);


--
-- Name: idx_inferences_action; Type: INDEX; Schema: trading; Owner: -
--

CREATE INDEX idx_inferences_action ON trading.model_inferences USING btree (action_discretized, timestamp_utc DESC);


--
-- Name: idx_inferences_model_time; Type: INDEX; Schema: trading; Owner: -
--

CREATE INDEX idx_inferences_model_time ON trading.model_inferences USING btree (model_id, timestamp_utc DESC);


--
-- Name: idx_inferences_session; Type: INDEX; Schema: trading; Owner: -
--

CREATE INDEX idx_inferences_session ON trading.model_inferences USING btree (session_id, timestamp_utc DESC);


--
-- Name: idx_inferences_time; Type: INDEX; Schema: trading; Owner: -
--

CREATE INDEX idx_inferences_time ON trading.model_inferences USING btree (timestamp_utc DESC);


--
-- Name: idx_trades_close_time; Type: INDEX; Schema: trading; Owner: -
--

CREATE INDEX idx_trades_close_time ON trading.model_trades USING btree (close_time DESC) WHERE (close_time IS NOT NULL);


--
-- Name: idx_trades_model_time; Type: INDEX; Schema: trading; Owner: -
--

CREATE INDEX idx_trades_model_time ON trading.model_trades USING btree (model_id, open_time DESC);


--
-- Name: idx_trades_open_time; Type: INDEX; Schema: trading; Owner: -
--

CREATE INDEX idx_trades_open_time ON trading.model_trades USING btree (open_time DESC);


--
-- Name: idx_trades_signal; Type: INDEX; Schema: trading; Owner: -
--

CREATE INDEX idx_trades_signal ON trading.model_trades USING btree (signal, model_id);


--
-- Name: idx_trades_status; Type: INDEX; Schema: trading; Owner: -
--

CREATE INDEX idx_trades_status ON trading.model_trades USING btree (status, model_id);


--
-- Name: feature_definitions trigger_features_updated_at; Type: TRIGGER; Schema: config; Owner: -
--

CREATE TRIGGER trigger_features_updated_at BEFORE UPDATE ON config.feature_definitions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: models trigger_models_updated_at; Type: TRIGGER; Schema: config; Owner: -
--

CREATE TRIGGER trigger_models_updated_at BEFORE UPDATE ON config.models FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: model_trades trigger_trades_updated_at; Type: TRIGGER; Schema: trading; Owner: -
--

CREATE TRIGGER trigger_trades_updated_at BEFORE UPDATE ON trading.model_trades FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: model_performance fk_perf_model; Type: FK CONSTRAINT; Schema: metrics; Owner: -
--

ALTER TABLE ONLY metrics.model_performance
    ADD CONSTRAINT fk_perf_model FOREIGN KEY (model_id) REFERENCES config.models(model_id) ON DELETE CASCADE;


--
-- Name: ab_permission_view ab_permission_view_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_permission_view
    ADD CONSTRAINT ab_permission_view_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.ab_permission(id);


--
-- Name: ab_permission_view_role ab_permission_view_role_permission_view_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_permission_view_role
    ADD CONSTRAINT ab_permission_view_role_permission_view_id_fkey FOREIGN KEY (permission_view_id) REFERENCES public.ab_permission_view(id);


--
-- Name: ab_permission_view_role ab_permission_view_role_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_permission_view_role
    ADD CONSTRAINT ab_permission_view_role_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.ab_role(id);


--
-- Name: ab_permission_view ab_permission_view_view_menu_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_permission_view
    ADD CONSTRAINT ab_permission_view_view_menu_id_fkey FOREIGN KEY (view_menu_id) REFERENCES public.ab_view_menu(id);


--
-- Name: ab_user ab_user_changed_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_user
    ADD CONSTRAINT ab_user_changed_by_fk_fkey FOREIGN KEY (changed_by_fk) REFERENCES public.ab_user(id);


--
-- Name: ab_user ab_user_created_by_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_user
    ADD CONSTRAINT ab_user_created_by_fk_fkey FOREIGN KEY (created_by_fk) REFERENCES public.ab_user(id);


--
-- Name: ab_user_role ab_user_role_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_user_role
    ADD CONSTRAINT ab_user_role_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.ab_role(id);


--
-- Name: ab_user_role ab_user_role_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ab_user_role
    ADD CONSTRAINT ab_user_role_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.ab_user(id);


--
-- Name: auth_audit_log auth_audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_audit_log
    ADD CONSTRAINT auth_audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: dag_owner_attributes dag.dag_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dag_owner_attributes
    ADD CONSTRAINT "dag.dag_id" FOREIGN KEY (dag_id) REFERENCES public.dag(dag_id) ON DELETE CASCADE;


--
-- Name: dag_run_note dag_run_note_dr_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dag_run_note
    ADD CONSTRAINT dag_run_note_dr_fkey FOREIGN KEY (dag_run_id) REFERENCES public.dag_run(id) ON DELETE CASCADE;


--
-- Name: dag_run_note dag_run_note_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dag_run_note
    ADD CONSTRAINT dag_run_note_user_fkey FOREIGN KEY (user_id) REFERENCES public.ab_user(id);


--
-- Name: dag_tag dag_tag_dag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dag_tag
    ADD CONSTRAINT dag_tag_dag_id_fkey FOREIGN KEY (dag_id) REFERENCES public.dag(dag_id) ON DELETE CASCADE;


--
-- Name: dagrun_dataset_event dagrun_dataset_event_dag_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dagrun_dataset_event
    ADD CONSTRAINT dagrun_dataset_event_dag_run_id_fkey FOREIGN KEY (dag_run_id) REFERENCES public.dag_run(id) ON DELETE CASCADE;


--
-- Name: dagrun_dataset_event dagrun_dataset_event_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dagrun_dataset_event
    ADD CONSTRAINT dagrun_dataset_event_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.dataset_event(id) ON DELETE CASCADE;


--
-- Name: dag_warning dcw_dag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dag_warning
    ADD CONSTRAINT dcw_dag_id_fkey FOREIGN KEY (dag_id) REFERENCES public.dag(dag_id) ON DELETE CASCADE;


--
-- Name: dataset_dag_run_queue ddrq_dag_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset_dag_run_queue
    ADD CONSTRAINT ddrq_dag_fkey FOREIGN KEY (target_dag_id) REFERENCES public.dag(dag_id) ON DELETE CASCADE;


--
-- Name: dataset_dag_run_queue ddrq_dataset_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dataset_dag_run_queue
    ADD CONSTRAINT ddrq_dataset_fkey FOREIGN KEY (dataset_id) REFERENCES public.dataset(id) ON DELETE CASCADE;


--
-- Name: dag_schedule_dataset_reference dsdr_dag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dag_schedule_dataset_reference
    ADD CONSTRAINT dsdr_dag_id_fkey FOREIGN KEY (dag_id) REFERENCES public.dag(dag_id) ON DELETE CASCADE;


--
-- Name: dag_schedule_dataset_reference dsdr_dataset_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dag_schedule_dataset_reference
    ADD CONSTRAINT dsdr_dataset_fkey FOREIGN KEY (dataset_id) REFERENCES public.dataset(id) ON DELETE CASCADE;


--
-- Name: rendered_task_instance_fields rtif_ti_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rendered_task_instance_fields
    ADD CONSTRAINT rtif_ti_fkey FOREIGN KEY (dag_id, task_id, run_id, map_index) REFERENCES public.task_instance(dag_id, task_id, run_id, map_index) ON DELETE CASCADE;


--
-- Name: task_fail task_fail_ti_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_fail
    ADD CONSTRAINT task_fail_ti_fkey FOREIGN KEY (dag_id, task_id, run_id, map_index) REFERENCES public.task_instance(dag_id, task_id, run_id, map_index) ON DELETE CASCADE;


--
-- Name: task_instance task_instance_dag_run_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_instance
    ADD CONSTRAINT task_instance_dag_run_fkey FOREIGN KEY (dag_id, run_id) REFERENCES public.dag_run(dag_id, run_id) ON DELETE CASCADE;


--
-- Name: dag_run task_instance_log_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dag_run
    ADD CONSTRAINT task_instance_log_template_id_fkey FOREIGN KEY (log_template_id) REFERENCES public.log_template(id);


--
-- Name: task_instance_note task_instance_note_ti_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_instance_note
    ADD CONSTRAINT task_instance_note_ti_fkey FOREIGN KEY (dag_id, task_id, run_id, map_index) REFERENCES public.task_instance(dag_id, task_id, run_id, map_index) ON DELETE CASCADE;


--
-- Name: task_instance_note task_instance_note_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_instance_note
    ADD CONSTRAINT task_instance_note_user_fkey FOREIGN KEY (user_id) REFERENCES public.ab_user(id);


--
-- Name: task_instance task_instance_trigger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_instance
    ADD CONSTRAINT task_instance_trigger_id_fkey FOREIGN KEY (trigger_id) REFERENCES public.trigger(id) ON DELETE CASCADE;


--
-- Name: task_map task_map_task_instance_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_map
    ADD CONSTRAINT task_map_task_instance_fkey FOREIGN KEY (dag_id, task_id, run_id, map_index) REFERENCES public.task_instance(dag_id, task_id, run_id, map_index) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: task_reschedule task_reschedule_dr_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_reschedule
    ADD CONSTRAINT task_reschedule_dr_fkey FOREIGN KEY (dag_id, run_id) REFERENCES public.dag_run(dag_id, run_id) ON DELETE CASCADE;


--
-- Name: task_reschedule task_reschedule_ti_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_reschedule
    ADD CONSTRAINT task_reschedule_ti_fkey FOREIGN KEY (dag_id, task_id, run_id, map_index) REFERENCES public.task_instance(dag_id, task_id, run_id, map_index) ON DELETE CASCADE;


--
-- Name: task_outlet_dataset_reference todr_dag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_outlet_dataset_reference
    ADD CONSTRAINT todr_dag_id_fkey FOREIGN KEY (dag_id) REFERENCES public.dag(dag_id) ON DELETE CASCADE;


--
-- Name: task_outlet_dataset_reference todr_dataset_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_outlet_dataset_reference
    ADD CONSTRAINT todr_dataset_fkey FOREIGN KEY (dataset_id) REFERENCES public.dataset(id) ON DELETE CASCADE;


--
-- Name: trading_sessions trading_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trading_sessions
    ADD CONSTRAINT trading_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: xcom xcom_task_instance_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.xcom
    ADD CONSTRAINT xcom_task_instance_fkey FOREIGN KEY (dag_id, task_id, run_id, map_index) REFERENCES public.task_instance(dag_id, task_id, run_id, map_index) ON DELETE CASCADE;


--
-- Name: model_inferences fk_model_id; Type: FK CONSTRAINT; Schema: trading; Owner: -
--

ALTER TABLE ONLY trading.model_inferences
    ADD CONSTRAINT fk_model_id FOREIGN KEY (model_id) REFERENCES config.models(model_id) ON DELETE RESTRICT;


--
-- Name: model_trades fk_trade_model; Type: FK CONSTRAINT; Schema: trading; Owner: -
--

ALTER TABLE ONLY trading.model_trades
    ADD CONSTRAINT fk_trade_model FOREIGN KEY (model_id) REFERENCES config.models(model_id) ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

